// Example integration for Part 01 WorldAtlas.jsx.
// This is not meant to replace your whole map art file blindly.
// Copy the marked changes into Part 01 WorldAtlas.jsx.

import React, { useState } from 'react';
import { BookOpen, Campfire, Compass, Crosshair, MapPinned, Minus, Plus, Route, ShieldAlert } from 'lucide-react';
import { atlas } from '../data/ashmoorAtlas.js';
import { useTravelEngine } from '../hooks/useTravelEngine.js';
import { TravelHud } from './TravelHud.jsx';
import { smoothPath } from '../utils/geometry.js';

// In Part 01, keep your existing TerrainRegion, Field, Tree, Mountain, Settlement, Road, River functions.
// Then update the WorldAtlas component so route/progress/save state comes from useTravelEngine(atlas).

export function WorldAtlasPart02Example({ MapSurface, RouteCard }) {
  const engine = useTravelEngine(atlas);
  const [zoom, setZoom] = useState(0.47);
  const [offset, setOffset] = useState({ x: -190, y: -115 });
  const selectedLocation = atlas.locations.find((l) => l.id === engine.save.atlas.destinationId) ?? atlas.locations[0];

  const state = {
    atlas,
    zoom,
    offset,
    setOffset,
    selectedLocationId: engine.save.atlas.destinationId,
    setSelectedLocationId: engine.setDestination,
    activeRoutePoints: engine.activeRoutePoints,
    playerPoint: engine.playerPoint,
  };

  return (
    <main className="ll-shell">
      <header className="ll-header">
        <div className="seal"><Compass size={28}/></div>
        <div><h1>Loot <em>&</em> Legends</h1><p>Living Travel Atlas</p></div>
        <button className="square"><BookOpen size={26}/></button>
      </header>

      <section className="status-grid">
        <div className="status-card"><small>Current Location</small><strong>{atlas.locations.find(l => l.id === engine.save.atlas.locationId)?.name}</strong><span>The Silver Road</span></div>
        <div className="status-card"><small>Destination</small><strong>{selectedLocation.name}</strong><span>{selectedLocation.type}</span></div>
        <div className="status-card"><small>Route</small><strong>{engine.selectedRoute.name}</strong><span>{engine.selectedRoute.reward}</span></div>
        <div className="status-card"><small>ETA</small><strong>{engine.etaHours.toFixed(1)}h</strong><span>{engine.save.atlas.travelStatus}</span></div>
      </section>

      <section className="map-panel">
        <div className="map-tools">
          <button onClick={() => setZoom((z) => Math.min(1.05, +(z + 0.12).toFixed(2)))}><Plus/> <span>Zoom</span></button>
          <button onClick={() => setZoom((z) => Math.max(0.34, +(z - 0.12).toFixed(2)))}><Minus/> <span>Out</span></button>
          <button onClick={() => setOffset({ x: 360 - engine.playerPoint.x * zoom, y: 410 - engine.playerPoint.y * zoom })}><Crosshair/> <span>Find</span></button>
        </div>
        <MapSurface state={state} />
      </section>

      <section className="legend-bar">
        <span><i className="dot blue"/> You</span><span><i className="dot gold"/> Objective</span><span><i className="line"/> Road</span><span><i className="dot red"/> Danger</span><span><i className="dot teal"/> Merchant/NPC</span>
      </section>

      <section className="lower-grid">
        <div className="route-list">
          <h2><Route size={18}/> Available Routes</h2>
          {atlas.routeOptions.map((route) => <RouteCard key={route.id} route={route} active={route.id === engine.save.atlas.selectedRouteId} onClick={() => engine.setRoute(route.id)} />)}
        </div>
        <aside className="event-card">
          <h2><ShieldAlert size={18}/> Selected Site</h2>
          <strong>{selectedLocation.name}</strong>
          <p>{selectedLocation.description}</p>
          <button onClick={engine.startTravel}><MapPinned/> Start Travel</button>
          <button><Campfire/> Camp</button>
        </aside>
      </section>

      <TravelHud engine={engine} />
    </main>
  );
}
