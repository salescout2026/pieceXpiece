import React from "react";
import { createRoot } from "react-dom/client";
import PremiumTacticalCombat from "./components/PremiumTacticalCombat.jsx";

createRoot(document.getElementById("root")).render(<PremiumTacticalCombat />);
