import React from "react";
import { createRoot } from "react-dom/client";
import PremiumInventoryEquipment from "./components/PremiumInventoryEquipment.jsx";

createRoot(document.getElementById("root")).render(<PremiumInventoryEquipment />);
