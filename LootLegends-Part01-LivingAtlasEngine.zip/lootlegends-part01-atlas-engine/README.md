# Loot & Legends — Part 01: Living Atlas Engine

This is the first clean replacement piece for the rebuilt app. It is **not** a static image mockup. It is a working React/Vite module that renders the map from game data.

## What this part includes

- `src/data/ashmoorAtlas.js` — handcrafted terrain, rivers, roads, forests, mountains, fields, locations, routes, and current travel state.
- `src/components/WorldAtlas.jsx` — interactive map renderer.
- `src/components/WorldAtlas.css` — dark fantasy atlas styling.
- `src/hooks/useAtlasState.js` — zoom, pan, selected route, player movement, selected site, travel progress.
- `src/utils/geometry.js` — route/path math.

## How to test locally

```bash
npm install
npm run dev
```

## How to integrate into your existing app later

Copy these folders into your app:

```text
src/components/WorldAtlas.jsx
src/components/WorldAtlas.css
src/data/ashmoorAtlas.js
src/hooks/useAtlasState.js
src/utils/geometry.js
```

Then render:

```jsx
import { WorldAtlas } from './components/WorldAtlas.jsx';
import './components/WorldAtlas.css';

<WorldAtlas />
```

## Definition of this piece

This is the first piece of the new map system. It replaces the node-graph idea with terrain/world-object data. Future pieces will add:

1. Travel engine state persistence.
2. Quest objectives attached to map objects.
3. Combat entry from world position.
4. NPC/merchant movement.
5. Region transitions and expanded world map.
