import React, { useMemo, useState } from "react";
import { useCombatEncounterBridge } from "../hooks/useCombatEncounterBridge";
import "./PremiumTacticalCombat.css";

function pct(current, max) {
  return `${Math.max(0, Math.min(100, (current / Math.max(1, max)) * 100))}%`;
}

function actorKey(actor) {
  return actor.uid || actor.id;
}

function getActorIcon(actor, type) {
  const name = (actor.name || "").toLowerCase();
  if (type === "enemy") {
    if (name.includes("hound")) return "🐺";
    if (name.includes("acolyte")) return "🔔";
    if (name.includes("bow")) return "🏹";
    if (name.includes("wraith")) return "☠";
    return "⚔";
  }
  if ((actor.className || "").toLowerCase().includes("cleric")) return "✚";
  if ((actor.className || "").toLowerCase().includes("ranger")) return "➶";
  if ((actor.className || "").toLowerCase().includes("fighter")) return "⚔";
  return "◆";
}

function DiceFace({ value }) {
  return (
    <div className="ll-die" aria-label={`d20 result ${value || "pending"}`}>
      <svg viewBox="0 0 64 64" role="presentation">
        <path d="M32 3 59 18v28L32 61 5 46V18Z" />
        <path d="M32 3v58M5 18l54 28M59 18 5 46" />
      </svg>
      <span>{value || "20"}</span>
    </div>
  );
}

function InitiativeRail({ state, activeId }) {
  return (
    <div className="ll-init-rail" aria-label="Initiative order">
      {state.initiative.map((turn, index) => {
        const type = turn.type === "party" ? "party" : "enemy";
        const actor = type === "party" ? state.party.find((p) => p.id === turn.id) : state.enemies.find((e) => e.uid === turn.id);
        if (!actor) return null;
        const key = actorKey(actor);
        return (
          <div key={`${type}-${key}`} className={`ll-init-card ${activeId === key ? "active" : ""} ${actor.hp <= 0 ? "down" : ""}`}>
            <span className="ll-init-num">{index + 1}</span>
            <span className={`ll-init-icon ${type}`}>{getActorIcon(actor, type)}</span>
            <small>{actor.name}</small>
          </div>
        );
      })}
    </div>
  );
}

function CombatantPlate({ actor, type, active, selected, targetable, onSelect }) {
  const wounds = actor.maxHp - actor.hp;
  const hpClass = actor.hp <= actor.maxHp * 0.3 ? "danger" : actor.hp <= actor.maxHp * 0.6 ? "warn" : "safe";
  return (
    <button
      type="button"
      className={`ll-combatant ${type} ${active ? "active" : ""} ${selected ? "selected" : ""} ${actor.hp <= 0 ? "down" : ""}`}
      disabled={!targetable}
      onClick={onSelect}
    >
      <div className="ll-portrait-frame">
        <div className={`ll-portrait-paint ${type}`} data-role={actor.role || actor.className || "combatant"}>
          <span>{getActorIcon(actor, type)}</span>
        </div>
        {active && <i className="ll-turn-flare" />}
      </div>
      <div className="ll-combatant-body">
        <div className="ll-combatant-title">
          <strong>{actor.name}</strong>
          <em>{actor.className || actor.role || (type === "party" ? "Hero" : "Enemy")}</em>
        </div>
        <div className={`ll-hp ${hpClass}`}>
          <i style={{ width: pct(actor.hp, actor.maxHp) }} />
          <span>{actor.hp}/{actor.maxHp}</span>
        </div>
        <div className="ll-badges">
          <span>AC {actor.armor || 10}</span>
          <span>{actor.attack?.name || "Strike"}</span>
          {wounds > 0 && <span className="wounds">-{wounds} HP</span>}
        </div>
      </div>
    </button>
  );
}

function EnemyIntent({ enemy }) {
  if (!enemy || enemy.hp <= 0) return null;
  const intent = enemy.intent || enemy.attack?.intent || (enemy.role?.includes("archer") ? "Aimed Shot" : enemy.role?.includes("caster") ? "Hex" : "Strike");
  const danger = enemy.attack?.damage?.[1] || 8;
  return (
    <div className="ll-intent-row">
      <span className="intent-mark">{intent.toLowerCase().includes("hex") ? "✦" : intent.toLowerCase().includes("shot") ? "⌖" : "╱"}</span>
      <div>
        <strong>{enemy.name}</strong>
        <small>Intent: {intent} · up to {danger} dmg</small>
      </div>
    </div>
  );
}

function SceneStage({ state, selectedTarget, activeId }) {
  const livingEnemies = state.enemies.filter((e) => e.hp > 0);
  const livingParty = state.party.filter((p) => p.hp > 0);
  return (
    <div className="ll-stage">
      <div className="ll-stage-backdrop">
        <div className="ll-parallax fog-a" />
        <div className="ll-parallax fog-b" />
        <div className="ll-torch left" />
        <div className="ll-torch right" />
        <div className="ll-ground-grid" />
      </div>
      <div className="ll-stage-party">
        {livingParty.map((actor, idx) => (
          <div key={actor.id} className={`ll-standee party p${idx} ${activeId === actor.id ? "active" : ""}`}>
            <span>{getActorIcon(actor, "party")}</span>
            <small>{actor.name.split(" ")[0]}</small>
          </div>
        ))}
      </div>
      <div className="ll-stage-enemies">
        {livingEnemies.map((actor, idx) => (
          <div key={actor.uid} className={`ll-standee enemy e${idx} ${selectedTarget?.uid === actor.uid ? "targeted" : ""} ${activeId === actor.uid ? "active" : ""}`}>
            <span>{getActorIcon(actor, "enemy")}</span>
            <small>{actor.name}</small>
          </div>
        ))}
      </div>
    </div>
  );
}

function ActionCommand({ label, icon, hotkey, disabled, selected, onClick, tone = "default" }) {
  return (
    <button type="button" className={`ll-command ${tone} ${selected ? "selected" : ""}`} disabled={disabled} onClick={onClick}>
      <span className="cmd-icon">{icon}</span>
      <strong>{label}</strong>
      {hotkey && <small>{hotkey}</small>}
    </button>
  );
}

export function PremiumTacticalCombat({ encounterId = "blackreed_bandits", party, onCombatComplete }) {
  const bridge = useCombatEncounterBridge({ encounterId, party, onCombatComplete });
  const { state, currentActor, isPlayerTurn, setTarget, attack, useAbility, reset } = bridge;
  const [selectedAction, setSelectedAction] = useState("attack");
  const [lastDie, setLastDie] = useState(null);
  const activeId = currentActor ? actorKey(currentActor) : null;
  const selectedTarget = useMemo(() => state.enemies.find((e) => e.uid === state.selectedTargetId), [state.enemies, state.selectedTargetId]);
  const activePartyActor = state.party.find((p) => p.id === activeId);

  function runAttack() {
    setSelectedAction("attack");
    setLastDie(Math.floor(Math.random() * 20) + 1);
    attack();
  }

  function runAbility(ability) {
    setSelectedAction(ability);
    setLastDie(Math.floor(Math.random() * 20) + 1);
    useAbility(ability, activePartyActor?.id || state.party[0]?.id);
  }

  return (
    <section className="ll-tactical-shell">
      <header className="ll-combat-topbar">
        <div className="ll-brand-seal">⚒</div>
        <div>
          <p>{state.region}</p>
          <h1>{state.title}</h1>
          <span>Round {state.round} · {isPlayerTurn ? `Your turn: ${currentActor?.name}` : `Enemy turn: ${currentActor?.name || "..."}`}</span>
        </div>
        <button className="ll-gear" onClick={() => reset(encounterId)} aria-label="Reset encounter">⚙</button>
      </header>

      <InitiativeRail state={state} activeId={activeId} />

      <SceneStage state={state} selectedTarget={selectedTarget} activeId={activeId} />

      <div className="ll-combat-layout">
        <aside className="ll-party-panel">
          <h2>Your Party</h2>
          {state.party.map((actor) => (
            <CombatantPlate key={actor.id} actor={actor} type="party" active={activeId === actor.id} />
          ))}
        </aside>

        <main className="ll-center-panel">
          <div className="ll-scene-text">
            <h2>Battlefield</h2>
            <p>{state.scene}</p>
            <div className="ll-terrain-tags">{state.terrain.map((tag) => <span key={tag}>{tag}</span>)}</div>
          </div>

          <div className="ll-turn-board">
            <DiceFace value={lastDie} />
            <div>
              <h3>{isPlayerTurn ? "Choose an action" : "The enemy acts"}</h3>
              <p>{isPlayerTurn ? `Target ${selectedTarget?.name || "an enemy"}, then confirm your command.` : `${currentActor?.name || "Enemy"} is resolving its intent.`}</p>
            </div>
          </div>

          <div className="ll-command-grid">
            <ActionCommand label="Attack" icon="⚔" hotkey="Weapon" selected={selectedAction === "attack"} disabled={!isPlayerTurn} onClick={runAttack} tone="red" />
            <ActionCommand label="Ability" icon="✦" hotkey="Class" selected={selectedAction === "blessing"} disabled={!isPlayerTurn} onClick={() => runAbility("blessing")} tone="blue" />
            <ActionCommand label="Help Ally" icon="✚" hotkey="Support" selected={selectedAction === "field_bandage"} disabled={!isPlayerTurn} onClick={() => runAbility("field_bandage")} tone="green" />
            <ActionCommand label="Defend" icon="🛡" hotkey="Guard" disabled={!isPlayerTurn} onClick={() => runAbility("hunter_mark")} />
          </div>
        </main>

        <aside className="ll-enemy-panel">
          <h2>Enemies</h2>
          {state.enemies.map((actor) => (
            <CombatantPlate
              key={actor.uid}
              actor={actor}
              type="enemy"
              active={activeId === actor.uid}
              selected={state.selectedTargetId === actor.uid}
              targetable={isPlayerTurn && actor.hp > 0}
              onSelect={() => setTarget(actor.uid)}
            />
          ))}
          <div className="ll-intents">
            <h3>Enemy Intent</h3>
            {state.enemies.filter((e) => e.hp > 0).map((enemy) => <EnemyIntent key={enemy.uid} enemy={enemy} />)}
          </div>
        </aside>
      </div>

      <section className="ll-log-panel">
        <h2>Combat Log</h2>
        <div>
          {state.log.slice(-8).map((entry, index) => <p key={`${entry.text}-${index}`} className={entry.tone}>{entry.text}</p>)}
        </div>
      </section>

      {state.status !== "active" && (
        <div className="ll-result-card">
          <div className="result-banner">{state.status === "victory" ? "✓" : "!"}</div>
          <h2>{state.status === "victory" ? "Scene Cleared" : "Forced Retreat"}</h2>
          <p>{state.status === "victory" ? "Rewards, quest flags, and travel resume payload are ready for the host game." : "Defeat state is preserved for quest/travel failure handling."}</p>
          <button onClick={() => reset(encounterId)}>Run Encounter Again</button>
        </div>
      )}
    </section>
  );
}

export default PremiumTacticalCombat;
