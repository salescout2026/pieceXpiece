# Loot & Legends — Part 06: Inventory + Equipment System UI

This part adds the inventory/equipment module that connects loot rewards, travel supplies, combat consumables, and character stats.

## What this adds

- `ITEM_CATALOG` with slots, rarities, values, stats, lore, tags, and affixes
- `useInventoryEquipment` hook with save/load/reset
- equip / unequip / use consumable actions
- computed equipment stat totals
- premium mobile inventory screen
- equipment paper-doll layout
- item detail panel, filters, journal, and rarity styling

## Depends on

Can run standalone, but it is intended to connect after:

- Part 03 quest rewards
- Part 04 combat rewards/consumable hooks
- Part 05 combat UI

## Integration

1. Copy `src/data/items.js` into your app.
2. Copy `src/hooks/useInventoryEquipment.js` into your app.
3. Copy `src/components/PremiumInventoryEquipment.jsx` and CSS.
4. Add an Inventory tab/screen route that renders:

```jsx
<PremiumInventoryEquipment
  onStatsChanged={(stats) => updatePartyEquipmentStats(stats)}
  onClose={() => setScreen("map")}
/>
```

5. In combat, when using a potion, call `useConsumable(instanceId)` or route through your shared inventory store.
6. In quest/combat rewards, add item stacks through `addItem(itemId, qty)`.

## Save key

Uses:

`lootlegends.inventory.v1`

If your app has a central save manager, move the state shape into that manager and keep the hook as a facade.
