export const ABILITIES = ['str','dex','con','int','wis','cha'];

export const ANCESTRIES = [
  { id:'human', name:'Human', tagline:'Versatile survivor', bonuses:{str:1,dex:1,con:1,int:1,wis:1,cha:1}, traits:['Determination','Extra Training'], lore:'Humans build kingdoms over old battlefields and call it progress.' },
  { id:'elf', name:'Elf', tagline:'Ancient bloodline', bonuses:{dex:2,int:1}, traits:['Keen Senses','Fey Ancestry'], lore:'Elves remember wars that humans misname as myths.' },
  { id:'dwarf', name:'Dwarf', tagline:'Stone sworn', bonuses:{con:2,str:1}, traits:['Stonecunning','Iron Stomach'], lore:'Dwarven oaths are carved into blood, steel, and mountain.' },
  { id:'tiefling', name:'Tiefling', tagline:'Infernal spark', bonuses:{cha:2,int:1}, traits:['Hellish Resistance','Dark Bargain'], lore:'A tiefling learns early that every smile hides a verdict.' },
  { id:'halfling', name:'Halfling', tagline:'Small shadow, large luck', bonuses:{dex:2,cha:1}, traits:['Lucky','Brave'], lore:'The world overlooks halflings until the knife is already drawn.' },
  { id:'dragonborn', name:'Dragonborn', tagline:'Scaled heir', bonuses:{str:2,cha:1}, traits:['Draconic Breath','Scaled Hide'], lore:'The old fire sleeps behind every dragonborn heartbeat.' }
];

export const CLASSES = [
  { id:'fighter', name:'Fighter', role:'Frontline weapon master', hitDie:10, primary:['str','con'], saves:['str','con'], startingGold:75, proficiencies:['Athletics','Intimidation'], base:{str:15,dex:12,con:14,int:10,wis:11,cha:10}, abilities:['Power Strike','Guarded Stance'] },
  { id:'rogue', name:'Rogue', role:'Skirmisher and infiltrator', hitDie:8, primary:['dex','int'], saves:['dex','int'], startingGold:65, proficiencies:['Stealth','Deception','Sleight of Hand'], base:{str:9,dex:15,con:12,int:13,wis:11,cha:12}, abilities:['Sneak Attack','Vanish'] },
  { id:'wizard', name:'Wizard', role:'Arcane control and damage', hitDie:6, primary:['int','wis'], saves:['int','wis'], startingGold:55, proficiencies:['Arcana','History'], base:{str:8,dex:12,con:11,int:15,wis:13,cha:10}, abilities:['Arcane Bolt','Shield Rune'] },
  { id:'cleric', name:'Cleric', role:'Divine support', hitDie:8, primary:['wis','cha'], saves:['wis','cha'], startingGold:60, proficiencies:['Religion','Medicine'], base:{str:11,dex:10,con:13,int:10,wis:15,cha:13}, abilities:['Mend Wounds','Sacred Flame'] },
  { id:'ranger', name:'Ranger', role:'Explorer and hunter', hitDie:10, primary:['dex','wis'], saves:['dex','wis'], startingGold:70, proficiencies:['Survival','Nature','Perception'], base:{str:11,dex:15,con:13,int:10,wis:14,cha:9}, abilities:['Marked Shot','Trail Sense'] },
  { id:'paladin', name:'Paladin', role:'Oathbound defender', hitDie:10, primary:['str','cha'], saves:['wis','cha'], startingGold:80, proficiencies:['Persuasion','Religion'], base:{str:15,dex:10,con:13,int:9,wis:12,cha:14}, abilities:['Smite','Lay on Hands'] }
];

export const BACKGROUNDS = [
  { id:'soldier', name:'Soldier', bonuses:{str:1,con:1}, skills:['Athletics','Intimidation'], feature:'Military Rank', hook:'You deserted after seeing what your commander summoned.' },
  { id:'noble', name:'Noble', bonuses:{cha:1,int:1}, skills:['History','Persuasion'], feature:'Courtly Access', hook:'Your house crest was found at a massacre you did not commit.' },
  { id:'sage', name:'Sage', bonuses:{int:1,wis:1}, skills:['Arcana','History'], feature:'Forbidden Research', hook:'A book you translated now whispers your name at night.' },
  { id:'criminal', name:'Criminal', bonuses:{dex:1,cha:1}, skills:['Stealth','Deception'], feature:'Underworld Contact', hook:'Your old crew sold you to a cult and wants the receipt back.' },
  { id:'folkhero', name:'Folk Hero', bonuses:{con:1,wis:1}, skills:['Survival','Animal Handling'], feature:'Rustic Hospitality', hook:'The village you saved now worships something wearing your face.' },
  { id:'acolyte', name:'Acolyte', bonuses:{wis:1,cha:1}, skills:['Religion','Insight'], feature:'Temple Shelter', hook:'Your god answered once. The answer scared everyone.' }
];

export const PORTRAIT_SEEDS = [
  'iron-crown','ashen-hood','wolf-cloak','gold-scar','raven-veil','ember-eye','frost-braid','bone-charm'
];
