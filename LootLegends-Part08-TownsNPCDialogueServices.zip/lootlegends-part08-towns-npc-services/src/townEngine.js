import { TOWNS } from '../data/towns.js';

export const DEFAULT_TOWN_STATE = {
  currentTownId: null,
  metNpcIds: [],
  townReputation: {},
  unlockedRumors: [],
  completedTownServices: [],
  dialogueHistory: []
};

export function createTownState(seed = {}) {
  return { ...DEFAULT_TOWN_STATE, ...seed,
    metNpcIds: [...(seed.metNpcIds || [])],
    unlockedRumors: [...(seed.unlockedRumors || [])],
    completedTownServices: [...(seed.completedTownServices || [])],
    dialogueHistory: [...(seed.dialogueHistory || [])],
    townReputation: { ...(seed.townReputation || {}) }
  };
}

export function getTown(townId) { return TOWNS[townId] || null; }
export function listTowns() { return Object.values(TOWNS); }

export function enterTown(state, townId) {
  if (!TOWNS[townId]) throw new Error(`Unknown town: ${townId}`);
  return { ...state, currentTownId: townId };
}

export function meetNpc(state, npcId) {
  if (state.metNpcIds.includes(npcId)) return state;
  return { ...state, metNpcIds: [...state.metNpcIds, npcId] };
}

export function applyTownReputation(state, townId, delta) {
  const current = state.townReputation[townId] || 0;
  return { ...state, townReputation: { ...state.townReputation, [townId]: current + delta } };
}

export function chooseDialogueTopic(state, townId, npcId, topicId) {
  const town = getTown(townId);
  const npc = town?.npcs.find(n => n.id === npcId);
  const topic = npc?.topics.find(t => t.id === topicId);
  if (!town || !npc || !topic) return { state, result: null };

  let next = meetNpc(state, npcId);
  const entry = { townId, npcId, topicId, at: Date.now(), reply: topic.reply };
  next = { ...next, dialogueHistory: [...next.dialogueHistory.slice(-60), entry] };

  if (topic.flags) {
    const flags = topic.flags.filter(f => !next.unlockedRumors.includes(f));
    next = { ...next, unlockedRumors: [...next.unlockedRumors, ...flags] };
  }

  return { state: next, result: { npc, topic, reply: topic.reply, unlockQuest: topic.unlockQuest, open: topic.open } };
}

export function getServiceCost(service, reputation = 0) {
  const base = service.baseCost || 0;
  const discount = Math.max(0, Math.min(0.25, reputation * 0.02));
  return Math.max(0, Math.ceil(base * (1 - discount)));
}

export function useTownService(state, gameState, townId, serviceId) {
  const town = getTown(townId);
  const service = town?.services?.[serviceId];
  if (!service) return { state, gameState, result: { ok:false, message:'Service unavailable.' } };

  const rep = state.townReputation[townId] || 0;
  const cost = getServiceCost(service, rep);
  const gold = gameState.gold ?? gameState.party?.gold ?? 0;
  if (gold < cost) return { state, gameState, result:{ ok:false, message:'Not enough gold.' } };

  let nextGame = { ...gameState };
  if ('gold' in nextGame) nextGame.gold -= cost;
  if (nextGame.party) nextGame.party = { ...nextGame.party, gold: (nextGame.party.gold || 0) - cost };

  const effect = service.effect || {};
  if (effect.hpPercent && nextGame.party?.members) {
    nextGame.party = { ...nextGame.party, members: nextGame.party.members.map(m => ({ ...m, hp: Math.ceil((m.maxHp || m.hp || 1) * effect.hpPercent) })) };
  }
  if (effect.xp) nextGame.xp = (nextGame.xp || 0) + effect.xp;

  let next = { ...state, completedTownServices: [...state.completedTownServices, `${townId}:${serviceId}:${Date.now()}`] };
  if (service.type === 'rumor') {
    const pool = service.rumorPool || [];
    const unknown = pool.filter(r => !next.unlockedRumors.includes(r));
    if (unknown[0]) next = { ...next, unlockedRumors: [...next.unlockedRumors, unknown[0]] };
  }

  return { state: next, gameState: nextGame, result: { ok:true, service, cost, message:`${service.label} complete.` } };
}

export function serializeTownState(state) { return JSON.stringify(state); }
export function hydrateTownState(json) { try { return createTownState(JSON.parse(json)); } catch { return createTownState(); } }
