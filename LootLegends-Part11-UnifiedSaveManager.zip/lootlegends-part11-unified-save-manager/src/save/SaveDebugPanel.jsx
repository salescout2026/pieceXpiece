import { useMemo, useState } from "react";
import { useGameSave } from "./useGameSave";
import "../styles/save-debug.css";

export default function SaveDebugPanel() {
  const saveApi = useGameSave();
  const [open, setOpen] = useState(false);
  const [importText, setImportText] = useState("");
  const summary = useMemo(() => ({
    version: saveApi.save.version,
    savedAt: saveApi.save.savedAt,
    party: saveApi.save.party?.length || 0,
    discovered: saveApi.save.atlas?.discoveredLocationIds?.length || 0,
    activeQuests: saveApi.save.quests?.activeQuestIds?.length || 0,
  }), [saveApi.save]);

  return (
    <section className="ll-save-debug">
      <button className="ll-save-debug__toggle" onClick={() => setOpen((v) => !v)}>{open ? "Hide" : "Save"}</button>
      {open && (
        <div className="ll-save-debug__panel">
          <h3>Unified Save</h3>
          <pre>{JSON.stringify(summary, null, 2)}</pre>
          <button onClick={() => navigator.clipboard?.writeText(saveApi.exportSave())}>Copy Export</button>
          <button onClick={() => saveApi.reset()}>Reset Campaign</button>
          <textarea value={importText} onChange={(e) => setImportText(e.target.value)} placeholder="Paste exported save JSON" />
          <button onClick={() => importText && saveApi.importSave(importText)}>Import Save</button>
        </div>
      )}
    </section>
  );
}
