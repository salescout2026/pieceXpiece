const KEY = "lootlegends.combat.v1";

export function saveCombatState(state) {
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch {}
}

export function loadCombatState() {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

export function clearCombatState() {
  try { localStorage.removeItem(KEY); } catch {}
}
