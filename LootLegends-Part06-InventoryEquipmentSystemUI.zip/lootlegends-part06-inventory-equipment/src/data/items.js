export const ITEM_SLOTS = ["mainHand", "offHand", "head", "chest", "hands", "feet", "neck", "ring", "trinket"];

export const SLOT_LABELS = {
  mainHand: "Main Hand",
  offHand: "Off Hand",
  head: "Head",
  chest: "Chest",
  hands: "Hands",
  feet: "Feet",
  neck: "Neck",
  ring: "Ring",
  trinket: "Trinket",
};

export const RARITIES = {
  common: { label: "Common", rank: 1, color: "#b9a77b" },
  uncommon: { label: "Uncommon", rank: 2, color: "#71bd7c" },
  rare: { label: "Rare", rank: 3, color: "#6fb4ff" },
  epic: { label: "Epic", rank: 4, color: "#b17aff" },
  relic: { label: "Relic", rank: 5, color: "#f3b650" },
};

export const ITEM_CATALOG = {
  emberbrand: {
    id: "emberbrand", name: "Emberbrand Longsword", type: "weapon", slot: "mainHand", rarity: "rare",
    value: 180, weight: 4, icon: "blade", tags: ["fire", "melee"],
    stats: { attack: 9, might: 2 },
    affixes: ["+9 Attack", "+2 Might", "Burning edge: +10% damage vs beasts"],
    lore: "A smoke-dark blade with a live coal sealed beneath the fuller. It hums near old battlefields.",
  },
  ashwood_buckler: {
    id: "ashwood_buckler", name: "Ashwood Buckler", type: "armor", slot: "offHand", rarity: "uncommon",
    value: 75, weight: 2, icon: "shield", tags: ["block"],
    stats: { defense: 5, agility: 1 }, affixes: ["+5 Defense", "+1 Agility", "Parry: small chance to reduce incoming damage"],
    lore: "Light enough for a scout, strong enough to turn a goblin spear.",
  },
  kingsroad_coat: {
    id: "kingsroad_coat", name: "Kingsroad Brigandine", type: "armor", slot: "chest", rarity: "rare",
    value: 150, weight: 7, icon: "armor", tags: ["medium"],
    stats: { defense: 10, endurance: 2 }, affixes: ["+10 Defense", "+2 Endurance", "Travel hardened: -5% road event damage"],
    lore: "Overlapping plates hidden beneath oil-black leather. Favored by caravan wardens.",
  },
  wayfinder_boots: {
    id: "wayfinder_boots", name: "Wayfinder Boots", type: "armor", slot: "feet", rarity: "uncommon",
    value: 95, weight: 1, icon: "boots", tags: ["travel"],
    stats: { agility: 2, travelSpeed: 6 }, affixes: ["+2 Agility", "+6% Travel Speed", "Quieter on forest roads"],
    lore: "The soles are stitched with silver thread in the pattern of northern constellations.",
  },
  moonlit_hood: {
    id: "moonlit_hood", name: "Moonlit Hood", type: "armor", slot: "head", rarity: "epic",
    value: 320, weight: 1, icon: "hood", tags: ["stealth", "arcane"],
    stats: { cunning: 3, will: 1 }, affixes: ["+3 Cunning", "+1 Will", "Night veil: unlocks stealth choices after dusk"],
    lore: "It drinks torchlight and returns only a cold blue sheen.",
  },
  saint_annelis_charm: {
    id: "saint_annelis_charm", name: "Charm of Saint Annelis", type: "accessory", slot: "neck", rarity: "relic",
    value: 600, weight: 0, icon: "amulet", tags: ["holy"],
    stats: { will: 4, maxHp: 12 }, affixes: ["+4 Will", "+12 Max HP", "Mercy: once per battle, survive lethal damage at 1 HP"],
    lore: "A cracked reliquary containing ash from a martyr's funeral pyre.",
  },
  iron_ration: {
    id: "iron_ration", name: "Iron Ration", type: "consumable", slot: null, rarity: "common",
    value: 8, weight: 1, icon: "ration", tags: ["camp"],
    stats: {}, affixes: ["Restores 8 HP during travel", "Counts as camp supply"],
    lore: "Hard bread, salt pork, dried apple. Better than starving.",
  },
  healing_draught: {
    id: "healing_draught", name: "Healing Draught", type: "consumable", slot: null, rarity: "common",
    value: 25, weight: 0, icon: "potion", tags: ["healing"],
    stats: {}, affixes: ["Restores 30 HP", "Usable in combat or inventory"],
    lore: "Bitter, coppery, and blessedly effective.",
  },
};

export const STARTER_INVENTORY = [
  { instanceId: "itm_emberbrand_1", itemId: "emberbrand", qty: 1 },
  { instanceId: "itm_buckler_1", itemId: "ashwood_buckler", qty: 1 },
  { instanceId: "itm_coat_1", itemId: "kingsroad_coat", qty: 1 },
  { instanceId: "itm_boots_1", itemId: "wayfinder_boots", qty: 1 },
  { instanceId: "itm_hood_1", itemId: "moonlit_hood", qty: 1 },
  { instanceId: "itm_charm_1", itemId: "saint_annelis_charm", qty: 1 },
  { instanceId: "itm_ration_1", itemId: "iron_ration", qty: 4 },
  { instanceId: "itm_potion_1", itemId: "healing_draught", qty: 3 },
];

export const DEFAULT_EQUIPMENT = {
  mainHand: "itm_emberbrand_1",
  offHand: "itm_buckler_1",
  head: null,
  chest: "itm_coat_1",
  hands: null,
  feet: "itm_boots_1",
  neck: null,
  ring: null,
  trinket: null,
};

export function getItem(stack) {
  return ITEM_CATALOG[stack?.itemId] || null;
}

export function expandedStats(inventory, equipment) {
  const totals = { attack: 0, defense: 0, might: 0, agility: 0, cunning: 0, will: 0, endurance: 0, maxHp: 0, travelSpeed: 0 };
  Object.values(equipment || {}).forEach((instanceId) => {
    const stack = inventory.find((i) => i.instanceId === instanceId);
    const item = getItem(stack);
    if (!item) return;
    Object.entries(item.stats || {}).forEach(([key, value]) => { totals[key] = (totals[key] || 0) + value; });
  });
  return totals;
}
