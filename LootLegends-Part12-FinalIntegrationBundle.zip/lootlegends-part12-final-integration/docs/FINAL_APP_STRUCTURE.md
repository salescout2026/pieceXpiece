# Target App Structure

```text
Loot-and-legands/
  package.json
  capacitor.config.*
  www/ or dist/
  src/
    app/
      AppShell.*
      navigation.*
      screenRegistry.*
    state/
      saveManager.*
      gameStore.*
      migrations.*
    data/
      atlasData.*
      questData.*
      combatData.*
      itemData.*
      townData.*
      partyData.*
    features/
      atlas/
      travel/
      quests/
      combat/
      inventory/
      shops/
      towns/
      party/
    styles/
      tokens.*
      global.*
      fantasy-ui.*
  .github/workflows/build-apk.yml
```

Use equivalent extensions based on the current repo stack.
