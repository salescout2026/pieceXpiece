# Loot & Legends — Part 02: Travel Engine + Save State

This is the second clean module after Part 01 Living Atlas Engine.

It does **not** replace the whole game. It adds the actual travel/saving layer that makes the atlas behave like a game system instead of a pretty map screen.

## What this part adds

- Real travel state machine: `idle`, `traveling`, `paused`, `event`, `encounter`, `arrived`
- `requestAnimationFrame` travel loop
- Player movement along selected route points
- ETA calculation
- Route switching
- Destination switching
- Fog/discovery state stored in save data
- Persistent localStorage save/load/reset
- Road events triggered by progress
- Skill-check choices with success/failure outcomes
- Encounter handoff point for combat
- HUD component for travel controls and events

## Files

Copy these into your project:

```txt
src/storage/saveStore.js
src/data/travelEvents.js
src/systems/travelEngine.js
src/hooks/useTravelEngine.js
src/components/TravelHud.jsx
src/components/TravelHud.css
src/utils/geometry.js  (only if your Part 01 geometry file does not already include pathLength/pathPoint)
src/components/WorldAtlas.part02.example.jsx
```

## Integration summary

In your Part 01 `WorldAtlas.jsx`:

1. Import the travel engine and HUD:

```js
import { useTravelEngine } from '../hooks/useTravelEngine.js';
import { TravelHud } from './TravelHud.jsx';
```

2. Replace temporary progress/route state with:

```js
const engine = useTravelEngine(atlas);
```

3. Feed the map surface from engine data:

```js
activeRoutePoints: engine.activeRoutePoints,
playerPoint: engine.playerPoint,
selectedLocationId: engine.save.atlas.destinationId,
setSelectedLocationId: engine.setDestination,
```

4. Route buttons should call:

```js
engine.setRoute(route.id)
```

5. The start travel button should call:

```js
engine.startTravel()
```

6. Render the HUD at the bottom of the map screen:

```jsx
<TravelHud engine={engine} />
```

See `src/components/WorldAtlas.part02.example.jsx` for a working example of how the pieces connect.

## Combat handoff

When an event creates an encounter, save state sets:

```js
save.atlas.travelStatus === 'encounter'
save.atlas.activeEncounterId
```

Your combat launcher can read that ID, start combat, then call:

```js
engine.clearEncounter()
```

when combat ends.

## Save system

The save key is:

```txt
loot-legends-save-v2
```

The save structure is intentionally separated from React so it can later be shared with Capacitor/Android storage.

## Next part

Part 03 should be **Quest Event Engine**:

- quest chains
- branching story scenes
- NPC dialogue
- quest objectives bound to atlas locations
- rewards and journal updates
