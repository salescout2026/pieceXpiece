# Integration Checklist — Part 07

1. Copy `src/data/shopCatalog.js` into your project data folder.
2. Copy `src/systems/shopEngine.js` and `src/systems/lootEngine.js` into your systems folder.
3. Copy `src/components/ShopScreen.jsx` and `src/components/LootRewardModal.jsx` into your components folder.
4. Import `src/styles/shop-loot.css` from your main stylesheet or app entry.
5. Connect shop state to the Part 06 inventory system:
   - `inventory.gold`
   - `inventory.items`
   - `inventory.reputation`
6. When combat ends, call `rollLootReward(encounter.lootTableId, context)`.
7. Show `LootRewardModal` with the reward payload.
8. On claim, add `reward.gold` and `reward.items` to inventory.
9. From towns/merchants, open `ShopScreen` with the merchant id.
10. Save updated inventory and shop restock state through your existing save system.

Recommended next module: Part 08 — Towns, NPC Dialogue + Services.
