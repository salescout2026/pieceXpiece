import React, { useMemo, useState } from 'react';
import { ABILITIES } from '../data/characterData.js';
import { loadPartyState, savePartyState, clearPartyState, formatMod, gainXP } from '../systems/characterSystem.js';
import '../styles/character-party.css';

export default function PartySheetScreen({ initialParty, onBack, onNewGame }){
  const [party,setParty] = useState(initialParty || loadPartyState());
  const [selectedId,setSelectedId] = useState(party?.activeCharacterId || party?.members?.[0]?.id);
  const selected = useMemo(()=>party?.members?.find(m=>m.id===selectedId) || party?.members?.[0],[party,selectedId]);
  if(!party || !selected) return <main className="ll-character-root"><h1 className="ll-title">No Party Found</h1><button className="ll-button" onClick={onNewGame}>Create Character</button></main>;
  const update = (nextParty)=>{ setParty(nextParty); savePartyState(nextParty); };
  const addTestXp = () => update({...party, members:party.members.map(m=>m.id===selected.id?gainXP(m,75):m)});
  const rest = () => update({...party, members:party.members.map(m=>m.id===selected.id?{...m,hp:m.maxHp}:m), campSupplies:Math.max(0,(party.campSupplies||0)-1)});

  return <main className="ll-character-root">
    <h1 className="ll-title">Party Sheet</h1>
    <div className="ll-sub">Gold {party.partyGold ?? 0} · Supplies {party.campSupplies ?? 0}</div>
    <section className="ll-panel">
      {party.members.map(m=><button key={m.id} className={`ll-card ${m.id===selected.id?'active':''}`} style={{width:'100%',marginBottom:8}} onClick={()=>setSelectedId(m.id)}>
        <div className="ll-party-member"><div className="ll-mini"/><div><h3>{m.name}</h3><p>Lv {m.level} {m.ancestryName} {m.className} · HP {m.hp}/{m.maxHp}</p></div></div>
      </button>)}
    </section>

    <section className="ll-panel">
      <div className="ll-portrait" />
      <h2 className="ll-title" style={{fontSize:21}}>{selected.name}</h2>
      <div className="ll-sub">Level {selected.level} {selected.ancestryName} {selected.className} · {selected.backgroundName}</div>
      <div className="ll-stat-row"><span>HP</span><b>{selected.hp}/{selected.maxHp}</b></div>
      <div className="ll-stat-row"><span>Armor Class</span><b>{selected.armorClass}</b></div>
      <div className="ll-stat-row"><span>Initiative</span><b>{selected.initiative>=0?'+':''}{selected.initiative}</b></div>
      <div className="ll-stat-row"><span>XP</span><b>{selected.xp}/{selected.xpNext}</b></div>
      {ABILITIES.map(a=><div className="ll-stat-row" key={a}><span>{a.toUpperCase()}</span><b>{selected.abilities[a]} ({formatMod(selected.abilities[a])})</b></div>)}
      <div style={{marginTop:10}}>{selected.skills.map(s=><span className="ll-pill" key={s}>{s}</span>)}</div>
      <div style={{marginTop:8}}>{selected.traits.map(s=><span className="ll-pill" key={s}>{s}</span>)}</div>
    </section>

    <section className="ll-panel">
      <h2 className="ll-title" style={{fontSize:17}}>Equipment Hooks</h2>
      {['weapon','armor','accessory'].map(slot=><div className="ll-stat-row" key={slot}><span>{slot}</span><b>{selected.equipment?.[slot]?.name || 'Empty'}</b></div>)}
      <br/><button className="ll-button secondary" onClick={rest}>Long Rest</button><br/><br/>
      <button className="ll-button secondary" onClick={addTestXp}>Dev: +75 XP</button><br/><br/>
      <button className="ll-button secondary" onClick={onBack}>Back</button><br/><br/>
      <button className="ll-button" onClick={()=>{clearPartyState(); onNewGame?.();}}>Reset Party</button>
    </section>
  </main>;
}
