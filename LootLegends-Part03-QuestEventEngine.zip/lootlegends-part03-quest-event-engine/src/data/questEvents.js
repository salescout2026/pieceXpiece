export const SKILLS = {
  survival: { label: 'Survival', icon: '♧' },
  insight: { label: 'Insight', icon: '◉' },
  arcana: { label: 'Arcana', icon: '✦' },
  religion: { label: 'Religion', icon: '✚' },
  athletics: { label: 'Athletics', icon: '⚒' },
  stealth: { label: 'Stealth', icon: '◒' },
  persuasion: { label: 'Persuasion', icon: '✥' },
  perception: { label: 'Perception', icon: '⊙' }
};

export const QUEST_EVENT_CHAINS = {
  hollowBell: {
    id: 'hollowBell',
    title: 'The Hollow Bell of Ashmoor',
    chapter: 'Chapter I — Sleepwalkers of Gallowfen',
    startNode: 'ashmoorTracks',
    locationIds: ['ashmoorCross', 'chapelLastEmber', 'oldBellTower', 'hollowBelfry'],
    flags: { bellCultAlert: 0, ferrymanTrust: 0, chapelClue: false, towerAccess: false },
    nodes: {
      ashmoorTracks: {
        id: 'ashmoorTracks',
        type: 'investigation',
        sceneTitle: 'Fresh Mud Beneath the Chapel Eaves',
        locationId: 'chapelLastEmber',
        weather: 'Cold rain beads on black roof tiles.',
        portrait: 'chapel',
        body: [
          'The chapel yard is crowded with mourners, but no one looks at the bell rope. It hangs frost-white despite the rain.',
          'A line of deep boot prints crosses older mud, stops beneath the east window, then continues toward the marsh path. Something heavy was dragged beside them.'
        ],
        discoveries: [
          { id: 'frostedBellRope', label: 'Frosted Bell Rope', kind: 'clue', text: 'The bell was rung from outside the chapel. No living hand touched the rope.' },
          { id: 'dragMarks', label: 'Fresh Drag Marks', kind: 'trail', text: 'A body or crate was dragged north before being lifted away.' }
        ],
        choices: [
          {
            id: 'trackMarks', label: 'Follow the broken cart tracks', skill: 'survival', dc: 12,
            requires: [], routeHint: ['chapelLastEmber','oldBellTower'],
            success: { text: 'You find reed fibers and bell-wax pressed into the mud. The trail points to the old tower road.', xp: 35, clues: ['reedFibers'], flags: { chapelClue: true }, next: 'towerApproach' },
            failure: { text: 'Rain ruins the cleanest tracks. You still find a direction, but the cult has time to move ahead.', xp: 10, danger: 1, flags: { bellCultAlert: 1 }, next: 'towerApproach' }
          },
          {
            id: 'questionBram', label: 'Question Bram Sedge about midnight crossings', skill: 'insight', dc: 11,
            success: { text: 'Bram admits he ferried silent pilgrims toward the Old Bell Tower. He marks a hidden landing on your atlas.', xp: 25, reputation: { ferrymen: 1 }, flags: { ferrymanTrust: 1 }, unlockLocations: ['ferrymansReach'], next: 'towerApproach' },
            failure: { text: 'Bram shuts down and warns others that strangers are asking questions.', xp: 5, flags: { bellCultAlert: 1 }, next: 'towerApproach' }
          },
          {
            id: 'blessRope', label: 'Bless the frosted rope', skill: 'religion', dc: 13, partyTags: ['cleric','paladin'],
            success: { text: 'The frost melts into black water. A whisper names the tower: Gallowfen hears.', xp: 45, clues: ['blackWaterOmen'], flags: { towerAccess: true }, next: 'towerApproach' },
            failure: { text: 'The rope thrashes once, ringing the bell without sound. Something in the marsh answers.', xp: 5, danger: 2, spawnEvent: 'marshHowl', next: 'towerApproach' }
          }
        ]
      },
      towerApproach: {
        id: 'towerApproach',
        type: 'travelDecision',
        sceneTitle: 'The Road to the Old Bell Tower',
        locationId: 'oldBellTower',
        weather: 'Low fog crawls across the road like spilled wool.',
        portrait: 'tower',
        body: [
          'The old road splits at a drowned milestone. One path climbs through watchtower stones; the other cuts through the marsh where blue lanterns bob between reeds.',
          'Your atlas has enough marks now to choose a route, but every road carries a price.'
        ],
        discoveries: [
          { id: 'drownedMilestone', label: 'Drowned Milestone', kind: 'site', text: 'Old trade route marker. Its carved arrows no longer agree with the road.' }
        ],
        choices: [
          {
            id: 'silverRoad', label: 'Take the Silver Road', routeId: 'silverRoad', skill: 'perception', dc: 10,
            success: { text: 'You keep to high ground and spot a bell cult scout before he sees you.', xp: 20, danger: -1, next: 'towerGate' },
            failure: { text: 'A scout escapes into the fog. The tower will be warned.', xp: 8, flags: { bellCultAlert: 1 }, next: 'towerGate' }
          },
          {
            id: 'marshCut', label: 'Risk the Ferryman’s Cut', routeId: 'marshCut', skill: 'survival', dc: 14,
            success: { text: 'You reach the tower unseen by following half-sunk ferry poles.', xp: 40, clues: ['hiddenLanding'], next: 'towerGate' },
            failure: { text: 'The marsh takes supplies and gives back fever. A hungry thing follows.', xp: 15, supplies: -2, spawnEvent: 'marshHound', next: 'towerGate' }
          },
          {
            id: 'forceMarch', label: 'Force march before the bell rings again', skill: 'athletics', dc: 15,
            success: { text: 'You beat the storm to the tower. The cult has not sealed the lower gate.', xp: 45, flags: { towerAccess: true }, next: 'towerGate' },
            failure: { text: 'Mud slows the party. You arrive exhausted as the tower bell begins to move.', xp: 10, condition: 'weary', danger: 1, next: 'towerGate' }
          }
        ]
      },
      towerGate: {
        id: 'towerGate',
        type: 'gate',
        sceneTitle: 'The Bell Tower Gate',
        locationId: 'oldBellTower',
        weather: 'The rain stops. The silence is worse.',
        portrait: 'gate',
        body: [
          'The Old Bell Tower rises from the fen on a stone island. Rusted chains vanish into a cracked belfry above.',
          'A locked pilgrim gate bars the inner stair. Scratches around the seal suggest it has opened recently.'
        ],
        discoveries: [
          { id: 'pilgrimGate', label: 'Pilgrim Gate', kind: 'lock', text: 'An old warded gate. Bell-wax seals its hinges.' }
        ],
        choices: [
          {
            id: 'useSeal', label: 'Use the Bell-Ward Seal', requiresItem: 'bellWardSeal',
            success: { text: 'The seal warms in your hand and the gate exhales a century of dust. The inner stair is open.', xp: 60, unlockLocations: ['hollowBelfry'], next: 'belfryRevealed' },
            failure: null
          },
          {
            id: 'pickGate', label: 'Pick the rusted pilgrim lock', skill: 'stealth', dc: 15,
            success: { text: 'The lock gives without a sound.', xp: 45, unlockLocations: ['hollowBelfry'], next: 'belfryRevealed' },
            failure: { text: 'A hidden chime rings inside the lock. Hooded figures move in the stairwell.', xp: 10, combat: 'bellAcolytes', flags: { bellCultAlert: 2 }, next: 'belfryRevealed' }
          },
          {
            id: 'studyWard', label: 'Study the bell-wax warding', skill: 'arcana', dc: 13,
            success: { text: 'You identify a repeated symbol: the cult uses bells to mark sleepwalkers. The gate opens if the rope is quieted.', xp: 50, clues: ['sleepwalkerMark'], next: 'belfryRevealed' },
            failure: { text: 'The wax burns your fingers and takes a memory: for a moment, you cannot remember why you came.', xp: 8, condition: 'haunted', next: 'belfryRevealed' }
          }
        ]
      },
      belfryRevealed: {
        id: 'belfryRevealed',
        type: 'chapterUnlock',
        sceneTitle: 'The Hollow Belfry Opens',
        locationId: 'hollowBelfry',
        weather: 'A single bell note rolls over Ashmoor without sound.',
        portrait: 'belfry',
        body: [
          'Beyond the gate, stairs spiral down instead of up. Every step is carved with names of villagers who are still alive.',
          'The atlas marks a new path beneath the tower. This is no longer an investigation. It is a descent.'
        ],
        discoveries: [
          { id: 'underBelfry', label: 'Under-Belfry Stair', kind: 'dungeon', text: 'A new dungeon route is now available from the atlas.' }
        ],
        choices: [
          { id: 'enterDungeon', label: 'Descend beneath the tower', success: { text: 'You descend into bell-dark.', xp: 75, unlockLocations: ['underBelfry'], combat: 'bellKeeper', completeQuest: 'hollowBell' } },
          { id: 'returnTown', label: 'Return to Ashmoor and prepare', success: { text: 'You mark the stair on your atlas and return before the fog thickens.', xp: 25, next: 'towerGate' } }
        ]
      }
    }
  }
};
