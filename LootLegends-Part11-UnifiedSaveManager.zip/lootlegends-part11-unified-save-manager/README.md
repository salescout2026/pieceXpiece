# Loot & Legends — Part 11: Unified Save Manager

This module creates the single save spine that Parts 01–10 should share.

## Adds
- `saveSchema.js` — canonical save structure for atlas, travel, quests, combat, inventory, shops, towns, party, and UI
- `saveMigrations.js` — migration pipeline so old saves can be upgraded instead of lost
- `saveManager.js` — localStorage save/load/backup/import/export manager
- `useGameSave.js` — React hook for screens and systems
- `gameActions.js` — high-level actions for common game state changes
- `SaveDebugPanel.jsx` — optional developer panel for export/import/reset testing
- `save-debug.css` — styling for the optional debug panel

## Purpose
This prevents each module from creating its own disconnected save state. Every major system reads and writes through the same structure.

## Important
Use this before final assembly. Codex should wire every module into this manager rather than letting map, travel, quest, combat, inventory, town, and party systems save separately.
