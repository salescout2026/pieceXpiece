# Parts Manifest

## Part 01 — Living Atlas Engine
Data-driven fantasy map renderer with terrain, roads, rivers, locations, route display, zoom/pan, player marker.

## Part 02 — Travel Engine + Save State
Travel loop, route progress, ETA, travel events, persistence.

## Part 03 — Quest Event Engine
Quest chains, story nodes, skill checks, clues, journal state, location unlocks.

## Part 04 — Combat Encounter Bridge
Combat state handoff, initiative, rewards, victory/defeat payloads.

## Part 05 — Premium Tactical Combat UI
Combat screen, initiative rail, battlefield panels, command grid, log, result screen.

## Part 06 — Inventory + Equipment System UI
Item catalog, equipment slots, consumables, stats, inventory state.

## Part 07 — Shops + Loot Rewards System
Merchant catalog, buy/sell, reputation pricing, loot tables, reward chest.

## Part 08 — Towns + NPC Dialogue + Services
Town hubs, districts, NPC dialogue, services, reputation hooks.

## Part 09 — Character Creation + Party Sheet
Ancestry/class/background data, party roster, level/XP hooks.

## Part 10 — Main App Shell + Navigation
Root shell, navigation, screen registry, top/bottom bars.

## Part 11 — Unified Save Manager
Single game state, autosave, backup recovery, migrations, import/export.

## Part 12 — Final Integration Bundle
Codex assembly instructions and integration documents.
