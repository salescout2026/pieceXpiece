import React from "react";
import { createRoot } from "react-dom/client";
import { CombatEncounter } from "./components/CombatEncounter";

function Demo() {
  return <CombatEncounter encounterId="blackreed_bandits" onCombatComplete={(payload) => console.log("combat complete", payload)} />;
}

createRoot(document.getElementById("root")).render(<Demo />);
