# Part 06 Integration Checklist

- [ ] Add `src/data/items.js`.
- [ ] Add `src/hooks/useInventoryEquipment.js`.
- [ ] Add `PremiumInventoryEquipment.jsx` and CSS.
- [ ] Add an Inventory tab/screen in the main navigation.
- [ ] Wire quest rewards to `addItem(itemId, qty)`.
- [ ] Wire combat consumables to `useConsumable(instanceId)`.
- [ ] Apply `totalStats` to party/combat calculations.
- [ ] Confirm equip/unequip persists after app reload.
- [ ] Confirm Android portrait layout is usable.
- [ ] Confirm old placeholder inventory UI is removed.
