# Loot & Legends — Part 07: Shops + Loot Rewards System

This module adds a data-driven merchant, loot table, reward chest, and shop UI system designed to connect with Part 06 inventory/equipment and Part 04 combat rewards.

## Includes
- `src/data/shopCatalog.js` — merchants, shop stock, loot tables, reward crates
- `src/systems/shopEngine.js` — buy/sell/restock/price/reputation logic
- `src/systems/lootEngine.js` — loot rolls, weighted tables, quest/combat reward payloads
- `src/components/ShopScreen.jsx` — premium mobile shop UI
- `src/components/LootRewardModal.jsx` — reward/chest UI
- `src/styles/shop-loot.css` — dark fantasy shop/reward styling
- `INTEGRATION_CHECKLIST.md` — how to wire it into the app

## Integration target
Use this after Part 06. It expects an inventory state shaped roughly like:

```js
{
  gold: 120,
  items: [],
  equipment: {},
  reputation: { ironhold: 0 }
}
```

