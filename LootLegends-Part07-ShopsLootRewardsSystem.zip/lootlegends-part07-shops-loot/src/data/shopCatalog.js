export const ITEM_RARITY = {
  common: { label: 'Common', priceMult: 1, color: '#a99673' },
  uncommon: { label: 'Uncommon', priceMult: 1.55, color: '#76b96b' },
  rare: { label: 'Rare', priceMult: 2.5, color: '#5ea0ff' },
  epic: { label: 'Epic', priceMult: 4.2, color: '#b56cff' },
  relic: { label: 'Relic', priceMult: 7.5, color: '#f3b64a' }
};

export const SHOP_ITEMS = {
  iron_sword: {
    id: 'iron_sword', name: 'Iron Longsword', type: 'weapon', slot: 'mainHand', rarity: 'common', basePrice: 60,
    stats: { attack: 6 }, tags: ['blade', 'martial'],
    description: 'A dependable soldier\'s blade, scarred by practical use rather than ceremony.'
  },
  ashwood_bow: {
    id: 'ashwood_bow', name: 'Ashwood Bow', type: 'weapon', slot: 'mainHand', rarity: 'common', basePrice: 72,
    stats: { attack: 4, dexterity: 1 }, tags: ['bow', 'ranged'],
    description: 'Flexible ashwood strung with waxed gut. Quiet enough for forest work.'
  },
  brigandine_vest: {
    id: 'brigandine_vest', name: 'Brigandine Vest', type: 'armor', slot: 'chest', rarity: 'uncommon', basePrice: 145,
    stats: { armor: 8, maxHp: 6 }, tags: ['armor', 'medium'],
    description: 'Dark leather over riveted plates. Popular with caravan guards who expect trouble.'
  },
  field_tonic: {
    id: 'field_tonic', name: 'Field Tonic', type: 'consumable', rarity: 'common', basePrice: 28,
    effect: { heal: 28 }, tags: ['potion', 'healing'],
    description: 'Bitter red medicine brewed for wounded scouts and desperate adventurers.'
  },
  ember_oil: {
    id: 'ember_oil', name: 'Ember Oil', type: 'consumable', rarity: 'uncommon', basePrice: 46,
    effect: { addDamage: 8, damageType: 'fire', turns: 3 }, tags: ['oil', 'fire'],
    description: 'A thumb-sized vial of alchemical oil that burns blue along a weapon edge.'
  },
  thief_gloves: {
    id: 'thief_gloves', name: 'Locksplitter Gloves', type: 'accessory', slot: 'hands', rarity: 'rare', basePrice: 230,
    stats: { dexterity: 3, lockpicking: 2 }, tags: ['stealth', 'rogue'],
    description: 'Supple black gloves with silver-thread fingertips that feel for hidden pins.'
  },
  pilgrim_charm: {
    id: 'pilgrim_charm', name: 'Pilgrim\'s Ash Charm', type: 'accessory', slot: 'neck', rarity: 'uncommon', basePrice: 110,
    stats: { wisdom: 2, resistance: 1 }, tags: ['holy', 'ward'],
    description: 'A tiny bronze reliquary filled with sanctified ash from a burned chapel.'
  },
  duskglass_ring: {
    id: 'duskglass_ring', name: 'Duskglass Ring', type: 'accessory', slot: 'ring', rarity: 'epic', basePrice: 640,
    stats: { intelligence: 3, magicPower: 5 }, tags: ['arcane', 'ring'],
    description: 'Black glass catches starlight even indoors. Wearing it makes shadows lean closer.'
  }
};

export const MERCHANTS = {
  ironhold_smith: {
    id: 'ironhold_smith', name: 'Borran Hammerwake', title: 'Ironhold Blacksmith', region: 'ironhold',
    portraitHint: 'scarred dwarf smith, furnace light, soot and gold eyes',
    greeting: 'Steel tells the truth. Coin does too. What are you buying?',
    buyModifier: 1.0, sellModifier: 0.45, restockDays: 3,
    stock: ['iron_sword', 'brigandine_vest', 'field_tonic', 'ember_oil']
  },
  mire_witch: {
    id: 'mire_witch', name: 'Velka Reedbone', title: 'Mire Witch & Relic Broker', region: 'drowned_mire',
    portraitHint: 'swamp witch merchant, bone charms, candle smoke',
    greeting: 'The swamp gives gifts. Some still have teeth.',
    buyModifier: 1.15, sellModifier: 0.5, restockDays: 5,
    stock: ['field_tonic', 'ember_oil', 'pilgrim_charm', 'duskglass_ring']
  },
  road_peddler: {
    id: 'road_peddler', name: 'Cassian Vale', title: 'Road Peddler', region: 'roads',
    portraitHint: 'thin traveling merchant, patched cloak, mule cart',
    greeting: 'Found it on the road, bought it from a fool, or took it off a corpse. All legal enough.',
    buyModifier: 1.08, sellModifier: 0.4, restockDays: 2,
    stock: ['field_tonic', 'ashwood_bow', 'thief_gloves']
  }
};

export const LOOT_TABLES = {
  road_bandits: [
    { kind: 'gold', min: 18, max: 42, weight: 10 },
    { kind: 'item', itemId: 'field_tonic', weight: 6 },
    { kind: 'item', itemId: 'iron_sword', weight: 2 },
    { kind: 'item', itemId: 'thief_gloves', weight: 1 }
  ],
  drowned_ruins: [
    { kind: 'gold', min: 40, max: 95, weight: 10 },
    { kind: 'item', itemId: 'pilgrim_charm', weight: 5 },
    { kind: 'item', itemId: 'ember_oil', weight: 4 },
    { kind: 'item', itemId: 'duskglass_ring', weight: 1 }
  ],
  merchant_cache: [
    { kind: 'gold', min: 70, max: 140, weight: 10 },
    { kind: 'item', itemId: 'brigandine_vest', weight: 4 },
    { kind: 'item', itemId: 'ashwood_bow', weight: 4 },
    { kind: 'item', itemId: 'duskglass_ring', weight: 1 }
  ]
};
