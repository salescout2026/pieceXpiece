# Loot & Legends — Part 04: Combat Encounter Bridge

This module connects travel/quest events to a playable combat encounter system.

## What it provides

- `CombatEncounterBridge` system for encounter hydration, initiative, attacks, abilities, victory/defeat outcomes.
- `CombatEncounter` React component with mobile-first dark fantasy combat UI.
- Persistent combat save state through `localStorage`.
- Encounter payloads designed to receive handoff from Part 02 Travel Engine and Part 03 Quest Event Engine.
- Completion payloads that return rewards, flags, travel-resume intent, and party state.

## Integration point

When Part 02 or Part 03 emits an encounter hook like:

```js
{ type: "combat", encounterId: "blackreed_bandits" }
```

mount:

```jsx
<CombatEncounter
  encounterId={event.encounterId}
  party={gameState.party}
  onCombatComplete={handleCombatComplete}
/>
```

Then handle the returned payload:

```js
function handleCombatComplete(payload) {
  // payload.status: victory | defeat
  // payload.rewards: xp/gold/items/reputation when victory
  // payload.flags: world/quest flags to persist
  // payload.resumeTravel: whether travel should continue
  // payload.party: updated party HP/state
}
```

## Notes

This is not intended to be the final full combat engine. It is the bridge layer that makes map travel, quest events, saves, rewards, and future tactical combat communicate cleanly.
