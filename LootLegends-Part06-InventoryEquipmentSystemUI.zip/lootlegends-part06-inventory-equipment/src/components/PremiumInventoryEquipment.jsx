import React, { useMemo, useState } from "react";
import { getItem, ITEM_SLOTS, RARITIES, SLOT_LABELS } from "../data/items";
import { useInventoryEquipment } from "../hooks/useInventoryEquipment";
import "./PremiumInventoryEquipment.css";

function ItemGlyph({ icon }) {
  return <span className={`ll-glyph ll-glyph-${icon || "gem"}`} aria-hidden="true" />;
}

function RarityPill({ rarity }) {
  const r = RARITIES[rarity] || RARITIES.common;
  return <span className="ll-rarity" style={{ "--rarity": r.color }}>{r.label}</span>;
}

function EquipmentSlot({ slot, entry, selectedId, onSelect, onUnequip }) {
  const item = entry?.item;
  return (
    <button className={`ll-slot ${selectedId === entry?.stack?.instanceId ? "is-selected" : ""}`} onClick={() => entry && onSelect(entry.stack.instanceId)}>
      <span className="ll-slot-label">{SLOT_LABELS[slot]}</span>
      {item ? (
        <>
          <ItemGlyph icon={item.icon} />
          <span className="ll-slot-name">{item.name}</span>
          <span className="ll-slot-stat">{Object.entries(item.stats)[0]?.map(String).join(" +")}</span>
          <span className="ll-unequip" onClick={(e) => { e.stopPropagation(); onUnequip(slot); }}>×</span>
        </>
      ) : (
        <span className="ll-empty-slot">empty</span>
      )}
    </button>
  );
}

function InventoryRow({ stack, selected, onSelect }) {
  const item = getItem(stack);
  if (!item) return null;
  return (
    <button className={`ll-item-row ${selected ? "is-selected" : ""}`} onClick={() => onSelect(stack.instanceId)} style={{ "--rarity": RARITIES[item.rarity]?.color || "#b9a77b" }}>
      <span className="ll-item-icon"><ItemGlyph icon={item.icon} /></span>
      <span className="ll-item-main">
        <span className="ll-item-name">{item.name}</span>
        <span className="ll-item-meta">{item.slot ? SLOT_LABELS[item.slot] : item.type} · {item.weight} wt · ◈ {item.value}</span>
      </span>
      {stack.qty > 1 && <span className="ll-qty">×{stack.qty}</span>}
    </button>
  );
}

export default function PremiumInventoryEquipment({ onStatsChanged, onClose }) {
  const inv = useInventoryEquipment();
  const [filter, setFilter] = useState("all");
  const [selectedId, setSelectedId] = useState(inv.inventory[0]?.instanceId || null);

  const selectedStack = inv.inventory.find((i) => i.instanceId === selectedId) || inv.inventory[0];
  const selectedItem = getItem(selectedStack);

  const filtered = useMemo(() => inv.inventory.filter((stack) => {
    const item = getItem(stack);
    if (!item) return false;
    if (filter === "all") return true;
    if (filter === "equipment") return item.type !== "consumable";
    return item.type === filter || item.slot === filter;
  }), [inv.inventory, filter]);

  const equipSelected = () => {
    if (!selectedItem) return;
    if (selectedItem.type === "consumable") inv.useConsumable(selectedStack.instanceId);
    else inv.equip(selectedStack.instanceId);
    onStatsChanged?.(inv.totalStats);
  };

  return (
    <main className="ll-inventory-screen">
      <section className="ll-topbar">
        <div>
          <p className="ll-kicker">Loot & Legends</p>
          <h1>Inventory & Equipment</h1>
        </div>
        <div className="ll-currency">◈ {inv.gold}</div>
      </section>

      <section className="ll-hero-card">
        <div className="ll-paperdoll">
          <div className="ll-portrait-glow" />
          <svg viewBox="0 0 120 190" className="ll-hero-silhouette" aria-hidden="true">
            <path d="M60 11c18 0 32 13 32 32 0 10-4 20-12 26l10 18 21 15-7 78H16l-7-78 21-15 10-18c-8-7-12-16-12-26 0-19 14-32 32-32Z" />
            <path d="M31 93c20 10 39 10 58 0M33 126h54M43 72c13 7 24 7 35 0" />
          </svg>
        </div>
        <div className="ll-stat-grid">
          {Object.entries(inv.totalStats).filter(([,v]) => v).map(([key, value]) => (
            <div key={key} className="ll-stat"><span>{key}</span><b>+{value}</b></div>
          ))}
          {!Object.values(inv.totalStats).some(Boolean) && <div className="ll-muted">No equipment bonuses yet.</div>}
        </div>
      </section>

      <section className="ll-layout">
        <div className="ll-panel ll-equipment-panel">
          <div className="ll-panel-title">Equipped Gear</div>
          <div className="ll-slots">
            {ITEM_SLOTS.map((slot) => <EquipmentSlot key={slot} slot={slot} entry={inv.equipmentItems[slot]} selectedId={selectedId} onSelect={setSelectedId} onUnequip={inv.unequip} />)}
          </div>
        </div>

        <div className="ll-panel ll-pack-panel">
          <div className="ll-filter-bar">
            {["all", "equipment", "weapon", "armor", "accessory", "consumable"].map((f) => <button key={f} className={filter === f ? "active" : ""} onClick={() => setFilter(f)}>{f}</button>)}
          </div>
          <div className="ll-pack-list">
            {filtered.map((stack) => <InventoryRow key={stack.instanceId} stack={stack} selected={selectedId === stack.instanceId} onSelect={setSelectedId} />)}
          </div>
        </div>

        <aside className="ll-panel ll-detail-panel">
          {selectedItem ? (
            <>
              <div className="ll-detail-head" style={{ "--rarity": RARITIES[selectedItem.rarity]?.color || "#b9a77b" }}>
                <div className="ll-detail-icon"><ItemGlyph icon={selectedItem.icon} /></div>
                <div>
                  <h2>{selectedItem.name}</h2>
                  <RarityPill rarity={selectedItem.rarity} />
                </div>
              </div>
              <p className="ll-lore">{selectedItem.lore}</p>
              <div className="ll-affixes">
                {selectedItem.affixes.map((a) => <span key={a}>{a}</span>)}
              </div>
              <div className="ll-detail-actions">
                <button className="ll-primary" onClick={equipSelected}>{selectedItem.type === "consumable" ? "Use Item" : "Equip"}</button>
                <button onClick={inv.resetInventory}>Reset Demo</button>
                {onClose && <button onClick={onClose}>Close</button>}
              </div>
            </>
          ) : <p className="ll-muted">Select an item.</p>}
        </aside>
      </section>

      <section className="ll-panel ll-journal">
        <div className="ll-panel-title">Equipment Journal</div>
        {inv.journal.length ? inv.journal.map((j) => <p key={j.id}>{j.text}</p>) : <p className="ll-muted">Equipment changes and consumable use will appear here.</p>}
      </section>
    </main>
  );
}
