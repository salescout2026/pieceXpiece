export function createGameActions(saveApi) {
  const { patch } = saveApi;
  return {
    setScreen(screen, payload = null) {
      patch((save) => ({ ...save, ui: { ...save.ui, currentScreen: screen, payload } }), null, "ui:set-screen");
    },
    discoverLocation(locationId) {
      patch((save) => {
        const ids = new Set(save.atlas.discoveredLocationIds || []);
        ids.add(locationId);
        save.atlas.discoveredLocationIds = [...ids];
        return save;
      }, null, "atlas:discover-location");
    },
    startTravel(routeId, destinationId) {
      patch((save) => {
        save.travel.status = "traveling";
        save.travel.routeId = routeId;
        save.travel.progress = 0;
        save.travel.startedAt = new Date().toISOString();
        save.atlas.activeRoute = routeId;
        save.atlas.activeDestinationId = destinationId;
        return save;
      }, null, "travel:start");
    },
    completeTravel(destinationId, position) {
      patch((save) => {
        save.travel.status = "idle";
        save.travel.progress = 1;
        save.atlas.activeRoute = null;
        save.atlas.activeDestinationId = null;
        if (position) save.atlas.playerPosition = position;
        if (destinationId) {
          const ids = new Set(save.atlas.discoveredLocationIds || []);
          ids.add(destinationId);
          save.atlas.discoveredLocationIds = [...ids];
        }
        return save;
      }, null, "travel:complete");
    },
    addJournalEntry(entry) {
      patch((save) => {
        save.quests.journal = [{ id: cryptoRandomId(), createdAt: new Date().toISOString(), ...entry }, ...(save.quests.journal || [])].slice(0, 200);
        return save;
      }, null, "quest:journal");
    },
    addItem(item) {
      patch((save) => {
        save.inventory.items = [...(save.inventory.items || []), { instanceId: cryptoRandomId(), ...item }];
        return save;
      }, null, "inventory:add-item");
    },
    spendGold(amount) {
      patch((save) => {
        save.player.gold = Math.max(0, (save.player.gold || 0) - amount);
        return save;
      }, null, "economy:spend-gold");
    },
    gainGold(amount) {
      patch((save) => {
        save.player.gold = (save.player.gold || 0) + amount;
        return save;
      }, null, "economy:gain-gold");
    },
    setFlag(flag, value = true) {
      patch((save) => {
        save.player.flags = { ...(save.player.flags || {}), [flag]: value };
        return save;
      }, null, "world:set-flag");
    },
  };
}

function cryptoRandomId() {
  if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
  return `id_${Date.now()}_${Math.random().toString(36).slice(2)}`;
}
