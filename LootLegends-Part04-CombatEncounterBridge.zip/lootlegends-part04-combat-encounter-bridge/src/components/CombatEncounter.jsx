import React from "react";
import { useCombatEncounterBridge } from "../hooks/useCombatEncounterBridge";
import "./CombatEncounter.css";

function hpPct(actor) {
  return `${Math.max(0, Math.min(100, (actor.hp / actor.maxHp) * 100))}%`;
}

function ActorCard({ actor, active, targetable, selected, onClick }) {
  return (
    <button className={`actor-card ${active ? "active" : ""} ${selected ? "selected" : ""}`} onClick={onClick} disabled={!targetable}>
      <div className="actor-portrait" data-key={actor.portraitKey || actor.role || actor.name}>{(actor.name || "?").slice(0, 1)}</div>
      <div className="actor-info">
        <strong>{actor.name}</strong>
        <span>{actor.className || actor.role}</span>
        <div className="hp-row"><i style={{ width: hpPct(actor) }} /></div>
        <small>{actor.hp} / {actor.maxHp}</small>
      </div>
    </button>
  );
}

export function CombatEncounter({ encounterId = "blackreed_bandits", party, onCombatComplete }) {
  const { state, currentActor, isPlayerTurn, setTarget, attack, useAbility, reset } = useCombatEncounterBridge({ encounterId, party, onCombatComplete });
  const activeId = currentActor?.id;

  return (
    <section className="combat-shell">
      <header className="combat-header">
        <div>
          <p>{state.region}</p>
          <h1>{state.title}</h1>
        </div>
        <div className="round-pill">Round {state.round}</div>
      </header>

      <div className="combat-scene">
        <div className="rain-layer" />
        <p>{state.scene}</p>
        <div className="terrain-tags">{state.terrain.map((t) => <span key={t}>{t}</span>)}</div>
      </div>

      <div className="initiative-strip">
        {state.initiative.map((turn) => {
          const actor = turn.type === "party" ? state.party.find((p) => p.id === turn.id) : state.enemies.find((e) => e.uid === turn.id);
          if (!actor) return null;
          return <div key={`${turn.type}-${turn.id}`} className={`initiative-token ${activeId === turn.id ? "active" : ""} ${actor.hp <= 0 ? "down" : ""}`}>{actor.name.slice(0, 1)}</div>;
        })}
      </div>

      <div className="combat-grid">
        <div className="combat-panel">
          <h2>Your Party</h2>
          {state.party.map((actor) => <ActorCard key={actor.id} actor={actor} active={activeId === actor.id} />)}
        </div>
        <div className="combat-panel">
          <h2>Enemies</h2>
          {state.enemies.map((actor) => (
            <ActorCard
              key={actor.uid}
              actor={actor}
              active={activeId === actor.uid}
              targetable={isPlayerTurn && actor.hp > 0}
              selected={state.selectedTargetId === actor.uid}
              onClick={() => setTarget(actor.uid)}
            />
          ))}
        </div>
      </div>

      <div className="action-bar">
        <button onClick={attack} disabled={!isPlayerTurn}>Attack</button>
        <button onClick={() => useAbility("blessing")} disabled={!isPlayerTurn}>Ability</button>
        <button onClick={() => useAbility("field_bandage", state.party[0]?.id)} disabled={!isPlayerTurn}>Help Ally</button>
        <button onClick={() => reset(encounterId)}>Reset</button>
      </div>

      <div className="combat-log">
        {state.log.slice(-7).map((entry, index) => <p key={index} className={entry.tone}>{entry.text}</p>)}
      </div>

      {state.status !== "active" && (
        <div className="combat-result">
          <h2>{state.status === "victory" ? "Scene Cleared" : "Forced Retreat"}</h2>
          <p>{state.status === "victory" ? "+XP, gold, flags, and travel resume payload are ready for the host game." : "Defeat payload is ready for travel/quest failure handling."}</p>
        </div>
      )}
    </section>
  );
}
