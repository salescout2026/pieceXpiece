const KEY = 'loot-legends.quest.v1';
export function loadQuestState() {
  try { const raw = localStorage.getItem(KEY); return raw ? JSON.parse(raw) : null; } catch { return null; }
}
export function saveQuestState(state) {
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch {}
}
export function clearQuestState() {
  try { localStorage.removeItem(KEY); } catch {}
}
