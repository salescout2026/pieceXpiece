import { MERCHANTS, SHOP_ITEMS, ITEM_RARITY } from '../data/shopCatalog.js';

const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

export function getItemPrice(itemId, merchantId, state = {}, mode = 'buy') {
  const item = SHOP_ITEMS[itemId];
  const merchant = MERCHANTS[merchantId];
  if (!item || !merchant) return 0;
  const rarity = ITEM_RARITY[item.rarity] || ITEM_RARITY.common;
  const rep = state?.reputation?.[merchant.region] || 0;
  const repDiscount = mode === 'buy' ? 1 - clamp(rep, -50, 50) * 0.004 : 1 + clamp(rep, -50, 50) * 0.002;
  const merchantMult = mode === 'buy' ? merchant.buyModifier : merchant.sellModifier;
  return Math.max(1, Math.round(item.basePrice * rarity.priceMult * merchantMult * repDiscount));
}

export function getMerchantStock(merchantId, state = {}) {
  const merchant = MERCHANTS[merchantId];
  if (!merchant) return [];
  const purchased = state?.shops?.[merchantId]?.purchased || [];
  return merchant.stock
    .filter(id => !purchased.includes(id))
    .map(id => ({ ...SHOP_ITEMS[id], price: getItemPrice(id, merchantId, state, 'buy') }));
}

export function buyItem(inventoryState, merchantId, itemId) {
  const item = SHOP_ITEMS[itemId];
  if (!item) return { ok: false, reason: 'Item not found', state: inventoryState };
  const price = getItemPrice(itemId, merchantId, inventoryState, 'buy');
  if ((inventoryState.gold || 0) < price) return { ok: false, reason: 'Not enough gold', state: inventoryState };
  const next = structuredClone(inventoryState || {});
  next.gold = (next.gold || 0) - price;
  next.items = [...(next.items || []), { instanceId: `${itemId}_${Date.now()}`, itemId, acquiredAt: Date.now() }];
  next.shops = next.shops || {};
  next.shops[merchantId] = next.shops[merchantId] || { purchased: [] };
  next.shops[merchantId].purchased = [...new Set([...(next.shops[merchantId].purchased || []), itemId])];
  return { ok: true, price, item, state: next };
}

export function sellItem(inventoryState, merchantId, instanceId) {
  const next = structuredClone(inventoryState || {});
  const idx = (next.items || []).findIndex(i => i.instanceId === instanceId);
  if (idx < 0) return { ok: false, reason: 'Item not in inventory', state: inventoryState };
  const invItem = next.items[idx];
  const item = SHOP_ITEMS[invItem.itemId];
  const price = getItemPrice(invItem.itemId, merchantId, next, 'sell');
  next.items.splice(idx, 1);
  next.gold = (next.gold || 0) + price;
  return { ok: true, price, item, state: next };
}

export function restockMerchant(inventoryState, merchantId) {
  const next = structuredClone(inventoryState || {});
  next.shops = next.shops || {};
  next.shops[merchantId] = { purchased: [], restockedAt: Date.now() };
  return next;
}
