import { ABILITIES, ANCESTRIES, CLASSES, BACKGROUNDS, PORTRAIT_SEEDS } from '../data/characterData.js';

const SAVE_KEY = 'lootlegends.party.v1';

export function mod(score){ return Math.floor((score - 10) / 2); }
export function formatMod(score){ const m = mod(score); return m >= 0 ? `+${m}` : `${m}`; }

export function buildCharacter({ name, ancestryId, classId, backgroundId, portraitSeed }){
  const ancestry = ANCESTRIES.find(a=>a.id===ancestryId) || ANCESTRIES[0];
  const cls = CLASSES.find(c=>c.id===classId) || CLASSES[0];
  const bg = BACKGROUNDS.find(b=>b.id===backgroundId) || BACKGROUNDS[0];
  const abilities = { ...cls.base };
  for(const [k,v] of Object.entries(ancestry.bonuses || {})) abilities[k] = (abilities[k]||10)+v;
  for(const [k,v] of Object.entries(bg.bonuses || {})) abilities[k] = (abilities[k]||10)+v;
  const level = 1;
  const maxHp = cls.hitDie + mod(abilities.con) + 8;
  const character = {
    id: cryptoRandomId(),
    name: (name || 'Nameless').trim().slice(0,24),
    ancestryId: ancestry.id,
    classId: cls.id,
    backgroundId: bg.id,
    ancestryName: ancestry.name,
    className: cls.name,
    backgroundName: bg.name,
    portraitSeed: portraitSeed || PORTRAIT_SEEDS[0],
    level,
    xp:0,
    xpNext:200,
    gold: cls.startingGold,
    abilities,
    skills: unique([...(cls.proficiencies||[]), ...(bg.skills||[])]),
    traits: [...(ancestry.traits||[]), bg.feature],
    abilitiesKnown: [...(cls.abilities||[])],
    hp:maxHp,
    maxHp,
    armorClass: 10 + mod(abilities.dex),
    initiative: mod(abilities.dex),
    speed: 30,
    equipment:{ weapon:null, armor:null, accessory:null },
    inventory:[],
    notes:[bg.hook],
    createdAt: Date.now(),
  };
  return recomputeCharacter(character);
}

export function recomputeCharacter(character, equipmentBonuses = {}){
  const abilityBonuses = equipmentBonuses.abilities || {};
  const abilities = {...character.abilities};
  for(const [k,v] of Object.entries(abilityBonuses)) abilities[k] = (abilities[k]||10)+v;
  const acBonus = equipmentBonuses.ac || 0;
  const hpBonus = equipmentBonuses.hp || 0;
  return {
    ...character,
    derivedAbilities: abilities,
    armorClass: 10 + mod(abilities.dex) + acBonus,
    initiative: mod(abilities.dex),
    maxHp: Math.max(1, character.maxHp + hpBonus),
  };
}

export function createStartingParty(mainCharacter){
  return {
    activeCharacterId: mainCharacter.id,
    members:[mainCharacter],
    stash:[],
    campSupplies:3,
    partyGold: mainCharacter.gold || 0,
    reputation:{ ironhold:0, silverpine:0, thornreach:0 },
    updatedAt:Date.now(),
  };
}

export function savePartyState(party){
  localStorage.setItem(SAVE_KEY, JSON.stringify({...party, updatedAt:Date.now()}));
}

export function loadPartyState(){
  try { return JSON.parse(localStorage.getItem(SAVE_KEY)); } catch { return null; }
}

export function clearPartyState(){ localStorage.removeItem(SAVE_KEY); }

export function addPartyMember(party, character){
  const next = {...party, members:[...party.members, character], updatedAt:Date.now()};
  savePartyState(next);
  return next;
}

export function updatePartyMember(party, memberId, patch){
  const next = {
    ...party,
    members: party.members.map(m=>m.id===memberId ? recomputeCharacter({...m, ...patch}) : m),
    updatedAt:Date.now(),
  };
  savePartyState(next);
  return next;
}

export function gainXP(character, xp){
  let next = {...character, xp: character.xp + xp};
  while(next.xp >= next.xpNext){
    next.xp -= next.xpNext;
    next.level += 1;
    next.xpNext = Math.floor(next.xpNext * 1.55);
    next.maxHp += Math.max(4, Math.ceil((next.level + mod(next.abilities.con)) / 2));
    next.hp = next.maxHp;
  }
  return recomputeCharacter(next);
}

function unique(arr){ return [...new Set(arr.filter(Boolean))]; }
function cryptoRandomId(){
  if(typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return `hero_${Date.now()}_${Math.random().toString(16).slice(2)}`;
}
