# Loot & Legends — Part 08: Towns + NPC Dialogue + Services

This module adds a data-driven town hub system for Loot & Legends.

It includes:
- `data/towns.js` — towns, districts, NPCs, services, reputation, rumors.
- `src/townEngine.js` — town state, dialogue, service handling, persistence hooks.
- `src/TownHub.jsx` — premium mobile town UI component.
- `styles/townHub.css` — dark fantasy town styling.
- `demo/index.html` — standalone demo for quick preview.

## Integration order
1. Copy `data/towns.js` into your game data folder.
2. Copy `src/townEngine.js` into your engine/systems folder.
3. Copy `src/TownHub.jsx` into your UI/components folder.
4. Import `styles/townHub.css` into your app/global styles.
5. Wire `TownHub` to your route/navigation system.
6. Connect shop, inventory, quest, travel, and save callbacks.

This module is designed to replace simple town buttons with actual town locations, NPCs, dialogue, and services.
