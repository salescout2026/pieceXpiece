# Loot & Legends — Part 12: Final Integration Bundle

This bundle is not a gameplay module. It is the assembly package for Codex/GitHub.

Use it after uploading Parts 01–11 to the repository. The goal is to merge the modular systems into one clean app without stacking duplicate prototypes.

## What this includes

- `codex/CODEX_ASSEMBLY_PROMPT.md` — paste this into Codex.
- `docs/PARTS_MANIFEST.md` — list of all delivered systems.
- `docs/FINAL_APP_STRUCTURE.md` — target folder layout.
- `docs/INTEGRATION_ORDER.md` — safe merge order.
- `docs/DEFINITION_OF_DONE.md` — test checklist.
- `scripts/verify-files.md` — manual checklist for expected files.

## Important

Do not ask Codex to “make a new version from scratch.”
Ask it to integrate the modules into the existing Loot-and-legands repo.

The map engine from Part 01 must replace the old node-map system entirely.
