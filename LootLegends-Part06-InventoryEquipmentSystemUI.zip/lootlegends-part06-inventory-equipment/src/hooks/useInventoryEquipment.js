import { useEffect, useMemo, useState } from "react";
import { DEFAULT_EQUIPMENT, STARTER_INVENTORY, expandedStats, getItem } from "../data/items";

const STORAGE_KEY = "lootlegends.inventory.v1";

function clone(value) { return JSON.parse(JSON.stringify(value)); }

function hydrate() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) throw new Error("empty");
    const parsed = JSON.parse(raw);
    return {
      inventory: Array.isArray(parsed.inventory) ? parsed.inventory : clone(STARTER_INVENTORY),
      equipment: parsed.equipment && typeof parsed.equipment === "object" ? parsed.equipment : clone(DEFAULT_EQUIPMENT),
      gold: Number.isFinite(parsed.gold) ? parsed.gold : 240,
      journal: Array.isArray(parsed.journal) ? parsed.journal : [],
    };
  } catch {
    return { inventory: clone(STARTER_INVENTORY), equipment: clone(DEFAULT_EQUIPMENT), gold: 240, journal: [] };
  }
}

export function useInventoryEquipment() {
  const [state, setState] = useState(hydrate);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const equipmentItems = useMemo(() => {
    const out = {};
    Object.entries(state.equipment).forEach(([slot, instanceId]) => {
      const stack = state.inventory.find((i) => i.instanceId === instanceId);
      out[slot] = stack ? { stack, item: getItem(stack) } : null;
    });
    return out;
  }, [state.inventory, state.equipment]);

  const totalStats = useMemo(() => expandedStats(state.inventory, state.equipment), [state.inventory, state.equipment]);

  function log(text) {
    setState((s) => ({ ...s, journal: [{ id: Date.now(), text }, ...s.journal].slice(0, 12) }));
  }

  function equip(instanceId) {
    setState((s) => {
      const stack = s.inventory.find((i) => i.instanceId === instanceId);
      const item = getItem(stack);
      if (!item || !item.slot) return s;
      return { ...s, equipment: { ...s.equipment, [item.slot]: instanceId }, journal: [{ id: Date.now(), text: `Equipped ${item.name}.` }, ...s.journal].slice(0, 12) };
    });
  }

  function unequip(slot) {
    setState((s) => ({ ...s, equipment: { ...s.equipment, [slot]: null }, journal: [{ id: Date.now(), text: `Cleared ${slot}.` }, ...s.journal].slice(0, 12) }));
  }

  function useConsumable(instanceId) {
    setState((s) => {
      const stack = s.inventory.find((i) => i.instanceId === instanceId);
      const item = getItem(stack);
      if (!item || item.type !== "consumable") return s;
      const nextInventory = s.inventory.flatMap((i) => {
        if (i.instanceId !== instanceId) return [i];
        const qty = (i.qty || 1) - 1;
        return qty > 0 ? [{ ...i, qty }] : [];
      });
      return { ...s, inventory: nextInventory, journal: [{ id: Date.now(), text: `Used ${item.name}.` }, ...s.journal].slice(0, 12) };
    });
  }

  function addItem(itemId, qty = 1) {
    setState((s) => {
      const item = { instanceId: `itm_${itemId}_${Date.now()}`, itemId, qty };
      return { ...s, inventory: [...s.inventory, item] };
    });
  }

  function resetInventory() {
    setState({ inventory: clone(STARTER_INVENTORY), equipment: clone(DEFAULT_EQUIPMENT), gold: 240, journal: [] });
  }

  return {
    ...state,
    equipmentItems,
    totalStats,
    equip,
    unequip,
    useConsumable,
    addItem,
    resetInventory,
    log,
  };
}
