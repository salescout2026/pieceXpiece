import { SAVE_VERSION, createDefaultSave, normalizeSave, deepMerge } from "./saveSchema";

const migrations = {
  1: (save) => deepMerge(createDefaultSave(), save),
  2: (save) => ({ ...save, atlas: { ...createDefaultSave().atlas, ...(save.atlas || {}) } }),
  3: (save) => ({ ...save, travel: { ...createDefaultSave().travel, ...(save.travel || {}) } }),
  4: (save) => ({ ...save, quests: { ...createDefaultSave().quests, ...(save.quests || {}) } }),
  5: (save) => ({ ...save, combat: { ...createDefaultSave().combat, ...(save.combat || {}) } }),
  6: (save) => ({ ...save, inventory: { ...createDefaultSave().inventory, ...(save.inventory || {}) } }),
  7: (save) => ({ ...save, shops: { ...createDefaultSave().shops, ...(save.shops || {}) } }),
  8: (save) => ({ ...save, towns: { ...createDefaultSave().towns, ...(save.towns || {}) } }),
  9: (save) => ({ ...save, party: Array.isArray(save.party) ? save.party : [] }),
  10: (save) => ({ ...save, ui: { ...createDefaultSave().ui, ...(save.ui || {}) } }),
};

export function migrateSave(rawSave) {
  let save = rawSave && typeof rawSave === "object" ? { ...rawSave } : createDefaultSave();
  let version = Number(save.version || 1);
  while (version < SAVE_VERSION) {
    const migrate = migrations[version] || ((s) => s);
    save = migrate(save);
    version += 1;
    save.version = version;
  }
  return normalizeSave({ ...save, version: SAVE_VERSION });
}
