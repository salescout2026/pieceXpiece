# Loot & Legends — Part 05: Premium Tactical Combat UI

This part replaces the plain combat bridge display with a premium mobile tactical combat interface.

## What this adds

- `PremiumTacticalCombat.jsx` — full-screen tactical combat screen
- `PremiumTacticalCombat.css` — dark fantasy tactical UI styling
- `CombatResultRewards.jsx` — premium victory/defeat reward screen
- `CombatResultRewards.css` — reward presentation styling

## Depends on

Part 04: Combat Encounter Bridge.

This UI imports:

```js
import { useCombatEncounterBridge } from "../hooks/useCombatEncounterBridge";
```

So it should live beside the Part 04 files in your `src/components` folder.

## Integration

1. Copy `src/components/PremiumTacticalCombat.jsx` into your app.
2. Copy `src/components/PremiumTacticalCombat.css` into your app.
3. Copy `src/components/CombatResultRewards.jsx` and CSS if you want the reward screen.
4. Replace uses of the old `CombatEncounter` component with `PremiumTacticalCombat`.

Example:

```jsx
import PremiumTacticalCombat from "./components/PremiumTacticalCombat";

<PremiumTacticalCombat
  encounterId="blackreed_bandits"
  party={party}
  onCombatComplete={(payload) => resumeTravelAfterCombat(payload)}
/>
```

## Design goal

The bridge logic stays separated from presentation. This lets you improve combat art/UI without breaking encounter rules, travel handoff, save state, or quest results.
