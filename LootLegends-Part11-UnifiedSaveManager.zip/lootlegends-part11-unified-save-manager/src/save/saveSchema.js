export const SAVE_VERSION = 11;
export const SAVE_KEY = "loot_legends_save_v11";
export const BACKUP_KEY = "loot_legends_save_backup_v11";

export function createDefaultSave() {
  return {
    version: SAVE_VERSION,
    savedAt: new Date().toISOString(),
    campaign: {
      id: "emberfall-campaign",
      day: 1,
      hour: 8,
      difficulty: "normal",
      seed: "emberfall-default",
    },
    player: {
      gold: 75,
      supplies: 6,
      reputation: {},
      flags: {},
    },
    party: [],
    atlas: {
      currentRegionId: "emberfall",
      playerPosition: { x: 22, y: 62 },
      camera: { x: 0, y: 0, zoom: 1 },
      discoveredLocationIds: ["hearthglen"],
      discoveredRegionIds: ["emberfall"],
      fog: {},
      activeRoute: null,
      activeDestinationId: null,
    },
    travel: {
      status: "idle",
      routeId: null,
      progress: 0,
      startedAt: null,
      pausedAt: null,
      eventQueue: [],
      resolvedEventIds: [],
    },
    quests: {
      activeQuestIds: [],
      completedQuestIds: [],
      failedQuestIds: [],
      nodeState: {},
      journal: [],
      clues: {},
    },
    combat: {
      activeEncounter: null,
      lastResult: null,
    },
    inventory: {
      items: [],
      equipmentByCharacterId: {},
    },
    shops: {
      merchantStock: {},
      soldItems: {},
    },
    towns: {
      knownTownIds: ["hearthglen"],
      npcState: {},
      servicesUsed: {},
    },
    ui: {
      currentScreen: "title",
      payload: null,
      settings: {
        reducedMotion: false,
        textSize: "normal",
        sfx: true,
      },
    },
  };
}

export function normalizeSave(input) {
  const base = createDefaultSave();
  if (!input || typeof input !== "object") return base;
  return deepMerge(base, input, { version: SAVE_VERSION, savedAt: input.savedAt || base.savedAt });
}

export function deepMerge(target, source, forced = {}) {
  const output = Array.isArray(target) ? [...target] : { ...target };
  if (!source || typeof source !== "object") return { ...output, ...forced };
  Object.entries(source).forEach(([key, value]) => {
    if (value && typeof value === "object" && !Array.isArray(value) && target[key] && typeof target[key] === "object" && !Array.isArray(target[key])) {
      output[key] = deepMerge(target[key], value);
    } else {
      output[key] = value;
    }
  });
  return { ...output, ...forced };
}
