# Integration Order

1. Save Manager
2. App Shell
3. Party/Character Creation
4. Living Atlas
5. Travel
6. Quest Events
7. Combat Bridge
8. Combat UI
9. Inventory/Equipment
10. Shops/Loot
11. Towns/NPCs
12. Polish and remove old code
13. Android build verification
