# Loot & Legends — Part 09: Character Creation + Party Sheet

This module adds a data-driven character creation flow and a premium party sheet UI.

## Includes
- ancestry/class/background data
- character creation system
- party roster save/load
- stat/modifier/derived-stat calculations
- mobile-first premium character creation UI
- party sheet with equipment/stat hooks

## Install
Copy `src/` into your app source folder and wire `CharacterCreationScreen` and `PartySheetScreen` into your router/navigation.
