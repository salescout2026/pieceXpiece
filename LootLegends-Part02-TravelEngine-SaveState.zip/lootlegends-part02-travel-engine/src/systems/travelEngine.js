import { pathLength, pathPoint } from '../utils/geometry.js';
import { travelEventTable } from '../data/travelEvents.js';

const REVEAL_RADIUS = 135;
const CELL_SIZE = 120;

export function buildRoutePoints(atlas, routeId) {
  const route = atlas.routeOptions.find((r) => r.id === routeId) ?? atlas.routeOptions[0];
  const points = [];
  route.roadIds.forEach((roadId, roadIndex) => {
    const road = atlas.roads.find((r) => r.id === roadId);
    if (!road) return;
    road.points.forEach((point, pointIndex) => {
      if (roadIndex > 0 && pointIndex === 0) return;
      points.push(point);
    });
  });
  return points;
}

export function calculateEtaHours(route, progress = 0) {
  const remaining = Math.max(0, 1 - progress);
  return Math.max(0, +(route.hours * remaining).toFixed(2));
}

export function getPlayerPoint(routePoints, progress) {
  return pathPoint(routePoints, Math.max(0, Math.min(1, progress)));
}

export function revealedCellsForPoint(point, existing = []) {
  const cells = new Set(existing);
  const minX = Math.floor((point.x - REVEAL_RADIUS) / CELL_SIZE);
  const maxX = Math.floor((point.x + REVEAL_RADIUS) / CELL_SIZE);
  const minY = Math.floor((point.y - REVEAL_RADIUS) / CELL_SIZE);
  const maxY = Math.floor((point.y + REVEAL_RADIUS) / CELL_SIZE);
  for (let x = minX; x <= maxX; x += 1) {
    for (let y = minY; y <= maxY; y += 1) {
      cells.add(`${x}:${y}`);
    }
  }
  return Array.from(cells);
}

export function discoverLocationsNearPoint(atlas, point, discoveredLocationIds = []) {
  const discovered = new Set(discoveredLocationIds);
  atlas.locations.forEach((loc) => {
    const dx = loc.x - point.x;
    const dy = loc.y - point.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < REVEAL_RADIUS * 0.95) discovered.add(loc.id);
  });
  return Array.from(discovered);
}

export function getNextTravelEvent(save, route, progress) {
  const completed = new Set(save.atlas.completedEventIds || []);
  return travelEventTable.find((event) => progress >= event.minProgress && !completed.has(event.id) && route.eventTags?.some((tag) => event.tags.includes(tag)));
}

export function rollSkillCheck(dc, bonus = 2) {
  const die = Math.floor(Math.random() * 20) + 1;
  return { die, total: die + bonus, success: die + bonus >= dc };
}

export function applyChoiceOutcome(save, outcome = {}) {
  const next = structuredClone(save);
  next.player.gold += outcome.gold || 0;
  next.player.supplies = Math.max(0, Math.min(next.player.maxSupplies, next.player.supplies + (outcome.supplies || 0)));
  if (outcome.reputation) {
    Object.entries(outcome.reputation).forEach(([key, value]) => {
      next.player.reputation[key] = (next.player.reputation[key] || 0) + value;
    });
  }
  if (outcome.reveal && !next.atlas.discoveredLocationIds.includes(outcome.reveal)) {
    next.atlas.discoveredLocationIds.push(outcome.reveal);
  }
  if (outcome.encounter) next.atlas.activeEncounterId = outcome.encounter;
  return next;
}

export function travelTick({ atlas, save, deltaMs, speed = 0.000035 }) {
  if (save.atlas.travelStatus !== 'traveling') return { save, event: null, arrived: false };
  const route = atlas.routeOptions.find((r) => r.id === save.atlas.selectedRouteId) ?? atlas.routeOptions[0];
  const routePoints = buildRoutePoints(atlas, route.id);
  const lengthFactor = Math.max(1, pathLength(routePoints) / 1200);
  const increment = (deltaMs * speed) / lengthFactor;
  const progress = Math.min(1, save.atlas.travelProgress + increment);
  const point = getPlayerPoint(routePoints, progress);

  let next = structuredClone(save);
  next.atlas.travelProgress = +progress.toFixed(5);
  next.atlas.revealedCells = revealedCellsForPoint(point, next.atlas.revealedCells);
  next.atlas.discoveredLocationIds = discoverLocationsNearPoint(atlas, point, next.atlas.discoveredLocationIds);

  const event = getNextTravelEvent(next, route, progress);
  if (event) {
    next.atlas.travelStatus = 'event';
    next.atlas.completedEventIds = [...new Set([...(next.atlas.completedEventIds || []), event.id])];
    next.journal.unshift({ id: `${event.id}-${Date.now()}`, time: Date.now(), type: 'event', text: event.title });
    return { save: next, event, arrived: false };
  }

  if (progress >= 1) {
    next.atlas.travelStatus = 'arrived';
    next.atlas.locationId = next.atlas.destinationId;
    next.atlas.travelProgress = 1;
    next.journal.unshift({ id: `arrived-${Date.now()}`, time: Date.now(), type: 'arrival', text: `Arrived at ${route.destinationName || next.atlas.destinationId}.` });
    return { save: next, event: null, arrived: true };
  }

  return { save: next, event: null, arrived: false };
}
