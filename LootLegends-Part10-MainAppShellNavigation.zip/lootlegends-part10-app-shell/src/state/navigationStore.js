import { useCallback, useMemo, useState } from "react";

export const SCREEN_IDS = Object.freeze({
  TITLE: "title",
  MAP: "map",
  TRAVEL: "travel",
  QUESTS: "quests",
  TOWN: "town",
  COMBAT: "combat",
  INVENTORY: "inventory",
  SHOP: "shop",
  PARTY: "party",
  JOURNAL: "journal",
  SETTINGS: "settings",
});

export function useNavigationStore(initialScreen = SCREEN_IDS.TITLE) {
  const [screen, setScreen] = useState(initialScreen);
  const [history, setHistory] = useState([]);
  const [payload, setPayload] = useState(null);

  const navigate = useCallback((nextScreen, nextPayload = null) => {
    setHistory((h) => [...h.slice(-24), { screen, payload }]);
    setPayload(nextPayload);
    setScreen(nextScreen);
  }, [screen, payload]);

  const replace = useCallback((nextScreen, nextPayload = null) => {
    setPayload(nextPayload);
    setScreen(nextScreen);
  }, []);

  const back = useCallback(() => {
    setHistory((h) => {
      if (!h.length) return h;
      const prev = h[h.length - 1];
      setScreen(prev.screen);
      setPayload(prev.payload ?? null);
      return h.slice(0, -1);
    });
  }, []);

  return useMemo(() => ({ screen, payload, history, navigate, replace, back }), [screen, payload, history, navigate, replace, back]);
}
