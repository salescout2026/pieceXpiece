import { QUEST_EVENT_CHAINS } from '../data/questEvents.js';

const clone = (v) => JSON.parse(JSON.stringify(v));

export function createQuestState(chainId = 'hollowBell') {
  const chain = QUEST_EVENT_CHAINS[chainId];
  if (!chain) throw new Error(`Unknown quest chain: ${chainId}`);
  return {
    activeChainId: chainId,
    activeNodeId: chain.startNode,
    completedChains: [],
    flags: { ...chain.flags },
    clues: [],
    journal: [],
    unlockedLocations: [],
    reputation: {},
    lastOutcome: null,
    dangerDelta: 0,
    conditions: []
  };
}

export function getQuestChain(state) {
  return QUEST_EVENT_CHAINS[state.activeChainId];
}

export function getActiveQuestNode(state) {
  const chain = getQuestChain(state);
  return chain.nodes[state.activeNodeId];
}

export function getAvailableChoices(node, gameState = {}) {
  const items = new Set(gameState.inventory?.map((i) => typeof i === 'string' ? i : i.id) || []);
  const tags = new Set(gameState.partyTags || gameState.party?.flatMap((p) => [p.classId, p.role, ...(p.tags || [])]) || []);
  return (node.choices || []).filter((choice) => {
    if (choice.requiresItem && !items.has(choice.requiresItem)) return false;
    if (choice.requires?.length && !choice.requires.every((f) => gameState.quest?.flags?.[f])) return false;
    if (choice.partyTags?.length && !choice.partyTags.some((t) => tags.has(t))) return false;
    return true;
  });
}

export function rollSkillCheck(choice, party = []) {
  if (!choice.skill || !choice.dc) return { passed: true, roll: null, total: null, bestBonus: 0, actor: null };
  let best = { bonus: 0, actor: null };
  for (const member of party) {
    const bonus = member.skills?.[choice.skill] ?? member.skillMods?.[choice.skill] ?? 0;
    if (bonus >= best.bonus) best = { bonus, actor: member };
  }
  const roll = Math.floor(Math.random() * 20) + 1;
  const total = roll + best.bonus;
  return { passed: total >= choice.dc, roll, total, bestBonus: best.bonus, actor: best.actor };
}

function addUnique(arr, values = []) {
  const out = [...arr];
  for (const v of values) if (!out.includes(v)) out.push(v);
  return out;
}

export function resolveQuestChoice(state, choiceId, gameState = {}) {
  const current = getActiveQuestNode(state);
  const choice = (current.choices || []).find((c) => c.id === choiceId);
  if (!choice) throw new Error(`Choice not found: ${choiceId}`);

  const check = rollSkillCheck(choice, gameState.party || []);
  const result = check.passed ? (choice.success || {}) : (choice.failure || choice.success || {});
  const next = clone(state);

  const flagUpdates = result.flags || {};
  for (const [key, val] of Object.entries(flagUpdates)) {
    next.flags[key] = typeof val === 'number' ? (next.flags[key] || 0) + val : val;
  }

  next.clues = addUnique(next.clues, result.clues || []);
  next.unlockedLocations = addUnique(next.unlockedLocations, result.unlockLocations || []);
  if (result.condition) next.conditions = addUnique(next.conditions, [result.condition]);
  if (result.danger) next.dangerDelta = (next.dangerDelta || 0) + result.danger;
  if (result.reputation) {
    next.reputation = { ...next.reputation };
    for (const [faction, delta] of Object.entries(result.reputation)) next.reputation[faction] = (next.reputation[faction] || 0) + delta;
  }
  if (result.completeQuest && !next.completedChains.includes(result.completeQuest)) next.completedChains.push(result.completeQuest);
  if (result.next) next.activeNodeId = result.next;

  const entry = {
    id: `${Date.now()}-${choice.id}`,
    at: new Date().toISOString(),
    nodeId: current.id,
    title: current.sceneTitle,
    choice: choice.label,
    text: result.text || 'The choice is made.',
    check,
    rewards: {
      xp: result.xp || 0,
      clues: result.clues || [],
      locations: result.unlockLocations || [],
      reputation: result.reputation || {},
      combat: result.combat || null,
      event: result.spawnEvent || null
    }
  };

  next.lastOutcome = entry;
  next.journal = [entry, ...(next.journal || [])].slice(0, 40);

  return { questState: next, outcome: entry, result, check };
}

export function applyQuestOutcomeToTravel(travelState, outcome) {
  if (!travelState || !outcome) return travelState;
  return {
    ...travelState,
    discoveredLocationIds: addUnique(travelState.discoveredLocationIds || [], outcome.rewards?.locations || []),
    roadEventQueue: [
      ...(travelState.roadEventQueue || []),
      ...(outcome.rewards?.event ? [outcome.rewards.event] : [])
    ]
  };
}
