import { useEffect, useMemo, useState } from "react";
import { CombatEncounterBridge } from "../systems/combatEncounterBridge";
import { loadCombatState, saveCombatState, clearCombatState } from "../storage/combatSaveStore";

export function useCombatEncounterBridge({ encounterId = "blackreed_bandits", party, onCombatComplete } = {}) {
  const [state, setState] = useState(() => loadCombatState() || CombatEncounterBridge.hydrateEncounter(encounterId, party));
  const currentActor = useMemo(() => CombatEncounterBridge.currentInitiativeActor(state), [state]);
  const isPlayerTurn = currentActor?.type === "party" && state.status === "active";

  useEffect(() => saveCombatState(state), [state]);

  useEffect(() => {
    if (state.status === "active" && currentActor?.type === "enemy") {
      const t = setTimeout(() => setState((s) => CombatEncounterBridge.enemyAutoAct(s)), 650);
      return () => clearTimeout(t);
    }
  }, [state.status, currentActor?.id, currentActor?.type]);

  useEffect(() => {
    if (state.status === "victory" || state.status === "defeat") {
      onCombatComplete?.({
        status: state.status,
        encounterId: state.encounterId,
        rewards: state.status === "victory" ? state.rewards : null,
        flags: state.status === "victory" ? state.victoryFlags : state.defeatFlags,
        resumeTravel: state.resumeTravel,
        party: state.party,
        log: state.log
      });
    }
  }, [state.status]);

  return {
    state,
    currentActor,
    isPlayerTurn,
    setTarget: (targetId) => setState((s) => ({ ...s, selectedTargetId: targetId })),
    attack: () => setState((s) => CombatEncounterBridge.attackTarget(s, currentActor?.id, s.selectedTargetId)),
    useAbility: (abilityId, targetId) => setState((s) => CombatEncounterBridge.useAbility(s, abilityId, targetId)),
    reset: (nextEncounterId = encounterId) => {
      clearCombatState();
      setState(CombatEncounterBridge.hydrateEncounter(nextEncounterId, party));
    },
    clear: clearCombatState
  };
}
