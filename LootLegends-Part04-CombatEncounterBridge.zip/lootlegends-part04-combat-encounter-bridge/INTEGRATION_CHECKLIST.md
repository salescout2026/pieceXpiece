# Part 04 Integration Checklist

1. Copy `src/data/combatEncounters.js` into your game source.
2. Copy `src/systems/combatEncounterBridge.js` into your systems folder.
3. Copy `src/hooks/useCombatEncounterBridge.js` into hooks.
4. Copy `src/storage/combatSaveStore.js` into storage.
5. Copy `src/components/CombatEncounter.jsx` and CSS into components.
6. Wire Part 02/03 encounter handoffs to render `<CombatEncounter />`.
7. On victory, apply rewards, flags, quest progress, and resume travel when `resumeTravel` is true.
8. On defeat, update party state and trigger retreat/consequence flow.
9. Confirm combat persists if Android pauses/resumes the app.
10. Confirm the build still outputs an APK.
