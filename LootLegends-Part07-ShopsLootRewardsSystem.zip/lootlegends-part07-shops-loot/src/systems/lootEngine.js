import { LOOT_TABLES, SHOP_ITEMS } from '../data/shopCatalog.js';

const rollInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

function weightedPick(rows) {
  const total = rows.reduce((s, r) => s + r.weight, 0);
  let needle = Math.random() * total;
  for (const row of rows) {
    needle -= row.weight;
    if (needle <= 0) return row;
  }
  return rows[rows.length - 1];
}

export function rollLootReward(tableId, context = {}) {
  const table = LOOT_TABLES[tableId] || LOOT_TABLES.road_bandits;
  const rolls = context.rolls || 2;
  const reward = { id: `loot_${Date.now()}`, source: tableId, gold: 0, items: [], flags: [], generatedAt: Date.now() };
  for (let i = 0; i < rolls; i++) {
    const entry = weightedPick(table);
    if (entry.kind === 'gold') reward.gold += rollInt(entry.min, entry.max);
    if (entry.kind === 'item' && SHOP_ITEMS[entry.itemId]) {
      reward.items.push({ instanceId: `${entry.itemId}_${Date.now()}_${i}`, itemId: entry.itemId });
    }
  }
  if (context.questId) reward.flags.push(`rewarded:${context.questId}`);
  return reward;
}

export function applyLootReward(inventoryState, reward) {
  const next = structuredClone(inventoryState || {});
  next.gold = (next.gold || 0) + (reward.gold || 0);
  next.items = [...(next.items || []), ...(reward.items || [])];
  next.claimedRewards = [...new Set([...(next.claimedRewards || []), reward.id])];
  return next;
}

export function describeRewardItem(rewardItem) {
  const item = SHOP_ITEMS[rewardItem.itemId];
  return item ? { ...item, ...rewardItem } : rewardItem;
}
