import React from 'react';
import { describeRewardItem, applyLootReward } from '../systems/lootEngine.js';
import { ITEM_RARITY } from '../data/shopCatalog.js';
import '../styles/shop-loot.css';

export default function LootRewardModal({ reward, inventoryState, onClaim, onClose }) {
  if (!reward) return null;
  const items = (reward.items || []).map(describeRewardItem);
  function claim() {
    const next = applyLootReward(inventoryState, reward);
    onClaim?.(next, reward);
  }
  return (
    <div className="ll-loot-backdrop">
      <section className="ll-loot-modal">
        <button className="ll-close" onClick={onClose}>×</button>
        <p className="ll-kicker">Reward Claimed</p>
        <h1>Chest of Spoils</h1>
        <div className="ll-gold-reward"><span>Gold</span><strong>{reward.gold || 0}</strong></div>
        <div className="ll-reward-grid">
          {items.map(item => (
            <article key={item.instanceId} className="ll-reward-item" style={{ '--rarity': ITEM_RARITY[item.rarity]?.color }}>
              <div className="ll-item-seal">{item.name?.slice(0,1) || '?'}</div>
              <strong>{item.name}</strong>
              <span>{ITEM_RARITY[item.rarity]?.label}</span>
              <p>{item.description}</p>
            </article>
          ))}
        </div>
        <button className="ll-claim" onClick={claim}>Take All</button>
      </section>
    </div>
  );
}
