# Part 05 Integration Checklist

- [ ] Part 04 combat bridge files already exist.
- [ ] Add `PremiumTacticalCombat.jsx` and `PremiumTacticalCombat.css`.
- [ ] Optional: add `CombatResultRewards.jsx` and `CombatResultRewards.css`.
- [ ] Replace old combat screen import with `PremiumTacticalCombat`.
- [ ] Confirm attack, ability, help ally, target selection, enemy turns, victory, and defeat still work.
- [ ] Confirm combat state saves through Part 04 storage.
- [ ] Confirm combat completion returns payload to quest/travel system.
- [ ] Test on Android portrait screen size.
