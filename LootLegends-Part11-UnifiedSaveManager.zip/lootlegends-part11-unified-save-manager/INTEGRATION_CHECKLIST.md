# Part 11 Integration Checklist

1. Copy `src/save` and `src/styles/save-debug.css` into the project.
2. Import `useGameSave` in the root app or `AppShell` wrapper.
3. Pass `save` as `gameState` and `createGameActions(saveApi)` as `dispatch/actions` to modules.
4. Replace separate localStorage keys from earlier parts with this manager.
5. Keep only one canonical save key: `loot_legends_save_v11`.
6. Wire atlas discovery and camera state to `save.atlas`.
7. Wire travel route/progress/events to `save.travel`.
8. Wire quest journal/flags/clues to `save.quests`.
9. Wire combat handoff to `save.combat`.
10. Wire inventory/equipment to `save.inventory`.
11. Wire shops and towns to `save.shops` and `save.towns`.
12. Use `SaveDebugPanel` temporarily during assembly, then hide it for release builds.
13. Confirm Android behavior:
    - close app and reopen: state persists
    - active travel resumes
    - quest progress persists
    - inventory/equipment persists
    - town reputation persists
    - combat can resume or gracefully return to encounter result
