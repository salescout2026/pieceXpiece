import React from 'react';
import { createRoot } from 'react-dom/client';
import QuestScene from './components/QuestScene.jsx';
import QuestJournal from './components/QuestJournal.jsx';
import { useQuestEventEngine } from './hooks/useQuestEventEngine.js';
import './demo.css';

const demoParty = [
  { id:'rowan', name:'Rowan Voss', classId:'ranger', skills:{ survival:5, perception:4, athletics:2, insight:1 } },
  { id:'maela', name:'Maela Thorn', classId:'cleric', skills:{ religion:6, insight:4, persuasion:2 } },
  { id:'lyria', name:'Lyria Vale', classId:'wizard', skills:{ arcana:6, perception:2 } }
];
const demoInventory = ['bellWardSeal','reedglassLantern'];

function DemoApp(){
  const engine = useQuestEventEngine('hollowBell', { party: demoParty, inventory: demoInventory });
  return <div className="demo-shell"><QuestScene node={engine.activeNode} choices={engine.choices} questState={engine.questState} onChoose={engine.choose} party={demoParty}/><QuestJournal questState={engine.questState}/><button className="demo-reset" onClick={engine.resetQuest}>Reset Quest</button></div>;
}

createRoot(document.getElementById('root')).render(<DemoApp/>);
