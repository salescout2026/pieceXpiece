# Codex Assembly Prompt — Loot & Legends Modular Integration

You are the lead developer for Loot & Legends.

The repo contains modular ZIP parts named roughly:

- LootLegends-Part01-LivingAtlasEngine.zip
- LootLegends-Part02-TravelEngine-SaveState.zip
- LootLegends-Part03-QuestEventEngine.zip
- LootLegends-Part04-CombatEncounterBridge.zip
- LootLegends-Part05-PremiumTacticalCombatUI.zip
- LootLegends-Part06-InventoryEquipmentSystemUI.zip
- LootLegends-Part07-ShopsLootRewardsSystem.zip
- LootLegends-Part08-TownsNPCDialogueServices.zip
- LootLegends-Part09-CharacterCreationPartySheet.zip
- LootLegends-Part10-MainAppShellNavigation.zip
- LootLegends-Part11-UnifiedSaveManager.zip
- LootLegends-Part12-FinalIntegrationBundle.zip

## Mission

Integrate Parts 01–11 into one working mobile-first game app.

Do not stack prototypes. Do not leave old duplicate systems alive. Replace obsolete systems cleanly.

## Non-negotiable design goal

The map is a core feature. Replace the old node graph map with the Part 01 Living Atlas Engine.

The final game must use:

- terrain-data-driven map rendering
- roads, rivers, forests, mountains, settlements, dungeons, merchants, NPCs, and events as data objects
- zoom and pan
- live player marker
- route progress
- fog/discovery state
- quest route integration
- travel engine integration

Do not use a static JPG/PNG map as the actual gameplay map.

## Integration order

1. Create/clean target structure:
   - `src/app`
   - `src/features/atlas`
   - `src/features/travel`
   - `src/features/quests`
   - `src/features/combat`
   - `src/features/inventory`
   - `src/features/shops`
   - `src/features/towns`
   - `src/features/party`
   - `src/state`
   - `src/styles`
   - `src/data`

2. Integrate Part 11 Unified Save Manager first.
3. Integrate Part 10 Main App Shell and route all screens through it.
4. Integrate Part 09 Character Creation and Party Sheet.
5. Integrate Part 01 Living Atlas Engine and remove old map renderer.
6. Integrate Part 02 Travel Engine with the atlas route/player state.
7. Integrate Part 03 Quest Event Engine with atlas locations and travel events.
8. Integrate Parts 04 and 05 combat bridge/UI.
9. Integrate Part 06 inventory/equipment.
10. Integrate Part 07 shops/loot rewards.
11. Integrate Part 08 towns/NPC services.
12. Wire all systems through the unified save manager.
13. Remove obsolete placeholder code and duplicate demo screens.
14. Run build/test.

## Required behavior

The final app must allow this flow:

1. Launch app.
2. Create or load party.
3. Open Living Atlas map.
4. Tap destination or quest route.
5. Start travel.
6. Player marker moves along route.
7. Travel can trigger events or combat.
8. Quest event choices can update state.
9. Combat can return victory/defeat rewards.
10. Loot enters inventory.
11. Towns/shops/services use shared state.
12. Save/load restores the state.

## Android/build requirements

Keep the existing GitHub Actions APK build working.
Do not require manual desktop-only steps.
Do not introduce dependencies that break Capacitor without updating build files.

## Visual requirements

The map should look like a premium handcrafted D&D/fantasy atlas:

- parchment terrain base
- elevation shading
- layered forests, hills, mountains, rivers, roads
- integrated villages/castles/ruins/dungeons instead of giant icon nodes
- atmospheric fog/weather
- dark fantasy UI frame

## Definition of done

A feature is complete only if it exists in the running game, responds to input, saves/loads correctly, and works with the other gameplay systems.

Open a PR or commit with a summary of changed files and testing results.
