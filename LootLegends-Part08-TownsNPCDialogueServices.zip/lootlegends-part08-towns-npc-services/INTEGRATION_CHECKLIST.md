# Integration Checklist — Part 08

- [ ] Add `towns.js` to the game data bundle.
- [ ] Add `townEngine.js` to game systems.
- [ ] Add `TownHub.jsx` to UI components.
- [ ] Import `townHub.css`.
- [ ] Route map town pins to `openTown(townId)`.
- [ ] Route merchant NPCs to Part 07 shop system.
- [ ] Route healer/inn services to character state.
- [ ] Route guild NPCs to Part 03 quest engine.
- [ ] Persist town reputation, met NPCs, rumors, and completed services.
- [ ] Test on Android with touch scrolling.
