const SAVE_KEY = 'loot-legends-save-v2';
const VERSION = 2;

const defaultSave = {
  version: VERSION,
  createdAt: null,
  updatedAt: null,
  player: {
    partyName: 'Ashmoor Company',
    supplies: 45,
    maxSupplies: 45,
    gold: 120,
    reputation: { ashmoor: 0, ferrymen: 0, chapel: 0, gloom: 0 },
  },
  atlas: {
    locationId: 'ashmoor-cross',
    destinationId: 'chapel-last-ember',
    selectedRouteId: 'silver-road',
    travelStatus: 'idle',
    travelProgress: 0,
    discoveredLocationIds: ['ashmoor-cross', 'chapel-last-ember', 'mourning-reed-ferry'],
    revealedCells: [],
    completedEventIds: [],
    activeEncounterId: null,
    lastTravelStartedAt: null,
  },
  journal: [
    { id: 'start', time: Date.now(), type: 'arrival', text: 'The party gathers at Ashmoor Cross.' },
  ],
};

function safeClone(value) {
  return JSON.parse(JSON.stringify(value));
}

function mergeSave(base, incoming) {
  return {
    ...base,
    ...incoming,
    player: { ...base.player, ...(incoming?.player || {}), reputation: { ...base.player.reputation, ...(incoming?.player?.reputation || {}) } },
    atlas: { ...base.atlas, ...(incoming?.atlas || {}) },
    journal: Array.isArray(incoming?.journal) ? incoming.journal : base.journal,
  };
}

export function createDefaultSave() {
  const now = Date.now();
  return { ...safeClone(defaultSave), createdAt: now, updatedAt: now };
}

export function loadGame() {
  try {
    const raw = window.localStorage.getItem(SAVE_KEY);
    if (!raw) return createDefaultSave();
    const parsed = JSON.parse(raw);
    return mergeSave(createDefaultSave(), parsed);
  } catch (err) {
    console.warn('[Loot & Legends] Failed to load save, starting fresh.', err);
    return createDefaultSave();
  }
}

export function saveGame(save) {
  const next = { ...save, version: VERSION, updatedAt: Date.now() };
  window.localStorage.setItem(SAVE_KEY, JSON.stringify(next));
  return next;
}

export function resetGameSave() {
  window.localStorage.removeItem(SAVE_KEY);
  const fresh = createDefaultSave();
  saveGame(fresh);
  return fresh;
}

export function exportSave(save) {
  return btoa(unescape(encodeURIComponent(JSON.stringify(save))));
}

export function importSave(encoded) {
  const parsed = JSON.parse(decodeURIComponent(escape(atob(encoded))));
  const merged = mergeSave(createDefaultSave(), parsed);
  return saveGame(merged);
}
