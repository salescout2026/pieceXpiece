import React from 'react';
import { Campfire, Pause, Play, RotateCcw, ShieldAlert, Swords } from 'lucide-react';
import './TravelHud.css';

function formatEta(hours) {
  const h = Math.floor(hours);
  const m = Math.round((hours - h) * 60);
  if (h <= 0) return `${m}m`;
  return `${h}h ${m}m`;
}

export function TravelHud({ engine }) {
  const { save, selectedRoute, etaHours, activeEvent, lastRoll, startTravel, pauseTravel, resumeTravel, resolveChoice, clearEncounter, resetSave } = engine;
  const traveling = save.atlas.travelStatus === 'traveling';
  const paused = save.atlas.travelStatus === 'paused' || save.atlas.travelStatus === 'idle' || save.atlas.travelStatus === 'arrived';
  const inEncounter = save.atlas.travelStatus === 'encounter';

  return (
    <section className="travel-engine-panel">
      <div className="travel-progress-card">
        <div>
          <small>Travel Status</small>
          <strong>{save.atlas.travelStatus.replace('-', ' ')}</strong>
          <span>{selectedRoute.name} · ETA {formatEta(etaHours)}</span>
        </div>
        <div className="travel-meter">
          <i style={{ width: `${Math.round(save.atlas.travelProgress * 100)}%` }} />
        </div>
      </div>

      <div className="travel-controls">
        {traveling ? <button onClick={pauseTravel}><Pause size={18}/> Pause</button> : <button onClick={paused ? startTravel : resumeTravel}><Play size={18}/> {save.atlas.travelProgress > 0 ? 'Resume' : 'Start Travel'}</button>}
        <button onClick={resetSave}><RotateCcw size={18}/> Reset Save</button>
        <button><Campfire size={18}/> Camp</button>
      </div>

      <div className="party-resource-row">
        <span>Supplies <b>{save.player.supplies}/{save.player.maxSupplies}</b></span>
        <span>Gold <b>{save.player.gold}</b></span>
        <span>Discovered <b>{save.atlas.discoveredLocationIds.length}</b></span>
      </div>

      {lastRoll && (
        <div className={`roll-banner ${lastRoll.success ? 'success' : 'fail'}`}>
          <b>{lastRoll.skill}</b> roll: {lastRoll.die} + bonus = {lastRoll.total} vs DC {lastRoll.dc}
        </div>
      )}

      {activeEvent && (
        <div className="travel-event-modal">
          <div className="event-frame">
            <small>Road Event</small>
            <h2>{activeEvent.title}</h2>
            <p>{activeEvent.text}</p>
            <div className="choice-list">
              {activeEvent.choices.map((choice) => (
                <button key={choice.id} onClick={() => resolveChoice(choice)}>
                  <span>{choice.label}</span>
                  {choice.dc && <em>{choice.skill} DC {choice.dc}</em>}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {inEncounter && (
        <div className="travel-event-modal">
          <div className="event-frame danger">
            <small>Encounter</small>
            <h2><Swords size={22}/> Ambush on the Road</h2>
            <p>The party is stopped on the route. This hooks into the combat screen: pass <code>save.atlas.activeEncounterId</code> to your combat launcher.</p>
            <button onClick={clearEncounter}><ShieldAlert size={18}/> Resolve / Return to Travel</button>
          </div>
        </div>
      )}
    </section>
  );
}
