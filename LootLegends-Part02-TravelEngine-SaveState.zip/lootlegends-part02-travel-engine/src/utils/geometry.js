export function distance(a, b) {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  return Math.sqrt(dx * dx + dy * dy);
}

export function pathLength(points = []) {
  let total = 0;
  for (let i = 1; i < points.length; i += 1) total += distance(points[i - 1], points[i]);
  return total;
}

export function pathPoint(points = [], t = 0) {
  if (!points.length) return { x: 0, y: 0 };
  if (points.length === 1) return points[0];
  const target = pathLength(points) * Math.max(0, Math.min(1, t));
  let travelled = 0;
  for (let i = 1; i < points.length; i += 1) {
    const seg = distance(points[i - 1], points[i]);
    if (travelled + seg >= target) {
      const local = seg === 0 ? 0 : (target - travelled) / seg;
      return {
        x: points[i - 1].x + (points[i].x - points[i - 1].x) * local,
        y: points[i - 1].y + (points[i].y - points[i - 1].y) * local,
      };
    }
    travelled += seg;
  }
  return points[points.length - 1];
}
