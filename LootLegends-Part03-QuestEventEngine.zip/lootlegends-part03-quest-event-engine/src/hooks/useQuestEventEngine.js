import { useMemo, useState, useCallback } from 'react';
import { createQuestState, getActiveQuestNode, getAvailableChoices, resolveQuestChoice } from '../systems/questEventEngine.js';
import { loadQuestState, saveQuestState } from '../storage/questSaveStore.js';

export function useQuestEventEngine(initialChainId = 'hollowBell', gameState = {}) {
  const [questState, setQuestState] = useState(() => loadQuestState() || createQuestState(initialChainId));
  const activeNode = useMemo(() => getActiveQuestNode(questState), [questState]);
  const choices = useMemo(() => getAvailableChoices(activeNode, { ...gameState, quest: questState }), [activeNode, gameState, questState]);

  const choose = useCallback((choiceId) => {
    let payload;
    setQuestState((prev) => {
      payload = resolveQuestChoice(prev, choiceId, { ...gameState, quest: prev });
      saveQuestState(payload.questState);
      return payload.questState;
    });
    return payload;
  }, [gameState]);

  const resetQuest = useCallback(() => {
    const next = createQuestState(initialChainId);
    saveQuestState(next);
    setQuestState(next);
  }, [initialChainId]);

  return { questState, activeNode, choices, choose, resetQuest };
}
