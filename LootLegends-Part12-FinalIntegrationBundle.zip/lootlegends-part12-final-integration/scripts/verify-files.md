# Manual Verification Checklist

Before assembling:

- [ ] Parts 01–11 ZIPs are present in the repo or available to Codex.
- [ ] Old broken workflow files are removed.
- [ ] Working `build-apk.yml` remains.
- [ ] No old generated mockup images are used as map gameplay.

After assembling:

- [ ] Search for old map renderer and remove/disable it.
- [ ] Confirm app imports the new atlas map component.
- [ ] Confirm save manager owns all state.
- [ ] Confirm Android workflow builds an APK.
