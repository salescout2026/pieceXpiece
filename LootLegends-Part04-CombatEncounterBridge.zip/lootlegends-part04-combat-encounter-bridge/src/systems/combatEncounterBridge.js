import { COMBAT_ENCOUNTERS, DEFAULT_PARTY, ENEMY_DEFS } from "../data/combatEncounters";

const clone = (value) => JSON.parse(JSON.stringify(value));
const roll = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const rollD20 = () => roll(1, 20);
const damageRoll = ([min, max]) => roll(min, max);

function buildInitiative(party, enemies) {
  const actors = [
    ...party.map((actor) => ({ type: "party", id: actor.id, roll: rollD20() + (actor.initiative || 0) })),
    ...enemies.map((actor) => ({ type: "enemy", id: actor.uid, roll: rollD20() + (actor.initiative || 0) }))
  ];
  return actors.sort((a, b) => b.roll - a.roll);
}

function hydrateEncounter(encounterId, party = DEFAULT_PARTY) {
  const template = COMBAT_ENCOUNTERS[encounterId] || COMBAT_ENCOUNTERS.blackreed_bandits;
  const enemies = template.enemies.map((enemyId, index) => {
    const enemy = clone(ENEMY_DEFS[enemyId]);
    enemy.uid = `${enemy.id}_${index}_${Date.now()}`;
    return enemy;
  });
  const hydratedParty = clone(party);
  const initiative = buildInitiative(hydratedParty, enemies);
  return {
    encounterId: template.id,
    title: template.title,
    region: template.region,
    scene: template.scene,
    terrain: template.terrain,
    rewards: template.rewards,
    resumeTravel: template.resumeTravel,
    victoryFlags: template.victoryFlags || [],
    defeatFlags: template.defeatFlags || [],
    party: hydratedParty,
    enemies,
    initiative,
    initiativeIndex: 0,
    round: 1,
    selectedTargetId: enemies[0]?.uid || null,
    selectedActorId: initiative[0]?.id || null,
    status: "active",
    log: [
      { text: `${template.title} begins.`, tone: "gold" },
      { text: template.scene, tone: "muted" }
    ]
  };
}

function currentInitiativeActor(state) {
  return state.initiative[state.initiativeIndex];
}

function getLivingParty(state) {
  return state.party.filter((p) => p.hp > 0);
}

function getLivingEnemies(state) {
  return state.enemies.filter((e) => e.hp > 0);
}

function getActorByInitiative(state, initiativeActor) {
  if (!initiativeActor) return null;
  return initiativeActor.type === "party"
    ? state.party.find((p) => p.id === initiativeActor.id)
    : state.enemies.find((e) => e.uid === initiativeActor.id);
}

function advanceTurn(state) {
  let next = clone(state);
  for (let guard = 0; guard < next.initiative.length + 2; guard += 1) {
    next.initiativeIndex += 1;
    if (next.initiativeIndex >= next.initiative.length) {
      next.initiativeIndex = 0;
      next.round += 1;
      next.log.push({ text: `Round ${next.round} begins.`, tone: "gold" });
    }
    const actor = getActorByInitiative(next, currentInitiativeActor(next));
    if (actor && actor.hp > 0) break;
  }
  next.selectedActorId = currentInitiativeActor(next)?.id || null;
  const livingEnemies = getLivingEnemies(next);
  if (!livingEnemies.some((e) => e.uid === next.selectedTargetId)) next.selectedTargetId = livingEnemies[0]?.uid || null;
  return next;
}

function applyOutcomeIfComplete(state) {
  const partyAlive = getLivingParty(state).length > 0;
  const enemiesAlive = getLivingEnemies(state).length > 0;
  if (!enemiesAlive) {
    return { ...state, status: "victory", log: [...state.log, { text: "Scene cleared. The road opens ahead.", tone: "success" }] };
  }
  if (!partyAlive) {
    return { ...state, status: "defeat", log: [...state.log, { text: "Your party falls back bloodied and scattered.", tone: "danger" }] };
  }
  return state;
}

function attackTarget(state, attackerId, targetId) {
  let next = clone(state);
  const actorInfo = currentInitiativeActor(next);
  const attacker = getActorByInitiative(next, actorInfo) || next.party.find((p) => p.id === attackerId);
  const targetList = actorInfo?.type === "enemy" ? next.party : next.enemies;
  const target = targetList.find((t) => (t.uid || t.id) === targetId) || targetList.find((t) => t.hp > 0);
  if (!attacker || !target || attacker.hp <= 0 || target.hp <= 0) return next;

  const d20 = rollD20();
  const total = d20 + (attacker.attack?.bonus || 0);
  const critical = d20 === 20;
  const hit = critical || total >= (target.armor || 10);
  if (!hit) {
    next.log.push({ text: `${attacker.name} misses ${target.name}.`, tone: "muted" });
    return advanceTurn(applyOutcomeIfComplete(next));
  }
  let dmg = damageRoll(attacker.attack.damage);
  if (critical) dmg *= 2;
  target.hp = Math.max(0, target.hp - dmg);
  next.log.push({
    text: `${attacker.name} uses ${attacker.attack.name} on ${target.name} for ${dmg} ${attacker.attack.type} damage${critical ? " — critical hit" : ""}.`,
    tone: critical ? "critical" : "normal"
  });
  return advanceTurn(applyOutcomeIfComplete(next));
}

function useAbility(state, abilityId, targetId) {
  let next = clone(state);
  const actor = getActorByInitiative(next, currentInitiativeActor(next));
  if (!actor) return next;
  if (abilityId === "field_bandage" || abilityId === "mending_prayer") {
    const ally = next.party.find((p) => p.id === targetId) || next.party.reduce((low, p) => (p.hp / p.maxHp < low.hp / low.maxHp ? p : low), next.party[0]);
    const amount = abilityId === "mending_prayer" ? 12 : 8;
    ally.hp = Math.min(ally.maxHp, ally.hp + amount);
    next.log.push({ text: `${actor.name} restores ${amount} HP to ${ally.name}.`, tone: "success" });
    return advanceTurn(applyOutcomeIfComplete(next));
  }
  if (abilityId === "blessing" || abilityId === "hunter_mark") {
    next.log.push({ text: `${actor.name} prepares ${abilityId.replace("_", " ")}. Advantage will be applied by the host combat system.`, tone: "gold" });
    return advanceTurn(applyOutcomeIfComplete(next));
  }
  next.log.push({ text: `${actor.name} cannot use that ability here.`, tone: "muted" });
  return next;
}

function enemyAutoAct(state) {
  let next = clone(state);
  const actorInfo = currentInitiativeActor(next);
  if (!actorInfo || actorInfo.type !== "enemy" || next.status !== "active") return next;
  const enemy = getActorByInitiative(next, actorInfo);
  const livingParty = getLivingParty(next);
  if (!enemy || !livingParty.length) return applyOutcomeIfComplete(next);
  const target = livingParty.sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp)[0];
  return attackTarget(next, enemy.uid, target.id);
}

export const CombatEncounterBridge = {
  hydrateEncounter,
  currentInitiativeActor,
  getLivingEnemies,
  getLivingParty,
  attackTarget,
  useAbility,
  enemyAutoAct,
  advanceTurn,
  applyOutcomeIfComplete
};
