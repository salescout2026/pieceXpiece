import { SCREEN_IDS } from "../state/navigationStore";

function MissingScreen({ id }) {
  return (
    <section className="ll-missing-screen">
      <div className="ll-panel ll-panel--heavy">
        <h2>Module not wired</h2>
        <p>The screen <strong>{id}</strong> exists in navigation, but its module has not been registered yet.</p>
      </div>
    </section>
  );
}

export const defaultScreens = {
  [SCREEN_IDS.TITLE]: ({ nav }) => (
    <section className="ll-title-screen">
      <div className="ll-title-emblem">◆</div>
      <p className="ll-kicker">Loot & Legends</p>
      <h1>Living Realms</h1>
      <p className="ll-title-copy">A dark fantasy atlas RPG built from explorable systems, not static screens.</p>
      <button className="ll-primary-button" onClick={() => nav.replace(SCREEN_IDS.MAP)}>Enter the Realm</button>
    </section>
  ),
  [SCREEN_IDS.MAP]: (props) => <MissingScreen id="map / Part 01 Living Atlas" {...props} />,
  [SCREEN_IDS.TRAVEL]: (props) => <MissingScreen id="travel / Part 02 Travel Engine" {...props} />,
  [SCREEN_IDS.QUESTS]: (props) => <MissingScreen id="quests / Part 03 Quest Event Engine" {...props} />,
  [SCREEN_IDS.TOWN]: (props) => <MissingScreen id="town / Part 08 Towns" {...props} />,
  [SCREEN_IDS.COMBAT]: (props) => <MissingScreen id="combat / Parts 04–05" {...props} />,
  [SCREEN_IDS.INVENTORY]: (props) => <MissingScreen id="inventory / Part 06" {...props} />,
  [SCREEN_IDS.SHOP]: (props) => <MissingScreen id="shop / Part 07" {...props} />,
  [SCREEN_IDS.PARTY]: (props) => <MissingScreen id="party / Part 09" {...props} />,
  [SCREEN_IDS.JOURNAL]: (props) => <MissingScreen id="journal" {...props} />,
  [SCREEN_IDS.SETTINGS]: (props) => <MissingScreen id="settings" {...props} />,
};

export function createScreenRegistry(overrides = {}) {
  return { ...defaultScreens, ...overrides };
}
