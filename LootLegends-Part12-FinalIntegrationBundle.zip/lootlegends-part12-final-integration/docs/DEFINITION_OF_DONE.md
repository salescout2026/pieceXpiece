# Definition of Done

The integrated build is done when:

- App launches on Android build.
- Player can create/load party.
- Atlas map renders from terrain/object data.
- Map supports pan/zoom.
- Player marker moves during travel.
- Fog/discovery persists.
- Quest routes use atlas locations.
- Travel can trigger quest events and combat.
- Combat returns rewards or defeat state.
- Inventory receives loot.
- Towns, shops, and services use shared state.
- Save/load restores all important game systems.
- Old node-map renderer is removed or unused.
- No static map screenshot is used as gameplay map.
