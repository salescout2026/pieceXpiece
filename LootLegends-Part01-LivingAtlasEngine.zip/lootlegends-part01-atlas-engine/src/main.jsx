import React from 'react';
import { createRoot } from 'react-dom/client';
import { WorldAtlas } from './components/WorldAtlas.jsx';
import './components/WorldAtlas.css';

function App() {
  return <WorldAtlas />;
}

createRoot(document.getElementById('root')).render(<App />);
