import React, { useMemo, useState } from 'react';
import { ANCESTRIES, CLASSES, BACKGROUNDS, PORTRAIT_SEEDS, ABILITIES } from '../data/characterData.js';
import { buildCharacter, createStartingParty, savePartyState, formatMod } from '../systems/characterSystem.js';
import '../styles/character-party.css';

export default function CharacterCreationScreen({ onComplete }){
  const [step,setStep] = useState(0);
  const [draft,setDraft] = useState({ name:'', ancestryId:'human', classId:'fighter', backgroundId:'soldier', portraitSeed:PORTRAIT_SEEDS[0] });
  const preview = useMemo(()=>buildCharacter(draft),[draft]);
  const steps = ['Name','Ancestry','Class','Past','Confirm'];
  const complete = () => { const hero = buildCharacter(draft); const party = createStartingParty(hero); savePartyState(party); onComplete?.(party); };

  return <main className="ll-character-root">
    <h1 className="ll-title">Forge Your Legend</h1>
    <div className="ll-sub">Create the hero who will enter the living atlas.</div>
    <div className="ll-step">{steps.map((s,i)=><span key={s} className={i<=step?'on':''}/>)}</div>

    {step===0 && <section className="ll-panel">
      <div className="ll-portrait" />
      <br />
      <input className="ll-input" placeholder="Hero name" value={draft.name} onChange={e=>setDraft({...draft,name:e.target.value})}/>
      <br/><br/>
      <button className="ll-button" onClick={()=>setStep(1)}>Continue</button>
    </section>}

    {step===1 && <Picker title="Choose Ancestry" items={ANCESTRIES} value={draft.ancestryId} onPick={id=>{setDraft({...draft,ancestryId:id});setStep(2);}} />}
    {step===2 && <Picker title="Choose Class" items={CLASSES.map(c=>({...c,tagline:c.role,lore:`Primary: ${c.primary.join(', ')} · Hit Die d${c.hitDie}`}))} value={draft.classId} onPick={id=>{setDraft({...draft,classId:id});setStep(3);}} />}
    {step===3 && <Picker title="Choose Background" items={BACKGROUNDS.map(b=>({...b,tagline:b.feature,lore:b.hook}))} value={draft.backgroundId} onPick={id=>{setDraft({...draft,backgroundId:id});setStep(4);}} />}

    {step===4 && <section className="ll-panel">
      <div className="ll-portrait" />
      <h2 className="ll-title" style={{fontSize:20}}>{preview.name}</h2>
      <div className="ll-sub">{preview.ancestryName} {preview.className} · {preview.backgroundName}</div>
      {ABILITIES.map(a=><div className="ll-stat-row" key={a}><span>{a.toUpperCase()}</span><b>{preview.abilities[a]} ({formatMod(preview.abilities[a])})</b></div>)}
      <div style={{marginTop:10}}>{preview.skills.map(s=><span className="ll-pill" key={s}>{s}</span>)}</div>
      <br/><button className="ll-button" onClick={complete}>Begin Adventure</button>
      <br/><br/><button className="ll-button secondary" onClick={()=>setStep(0)}>Revise</button>
    </section>}
  </main>;
}

function Picker({title,items,value,onPick}){
  return <section className="ll-panel"><h2 className="ll-title" style={{fontSize:18}}>{title}</h2><div className="ll-grid">
    {items.map(item=><button className={`ll-card ${value===item.id?'active':''}`} key={item.id} onClick={()=>onPick(item.id)}>
      <h3>{item.name}</h3><p><b>{item.tagline}</b></p><p>{item.lore}</p>
    </button>)}
  </div></section>;
}
