import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { loadGame, saveGame, resetGameSave } from '../storage/saveStore.js';
import { applyChoiceOutcome, buildRoutePoints, calculateEtaHours, getPlayerPoint, rollSkillCheck, travelTick } from '../systems/travelEngine.js';

export function useTravelEngine(atlas) {
  const [save, setSave] = useState(() => loadGame());
  const [activeEvent, setActiveEvent] = useState(null);
  const [lastRoll, setLastRoll] = useState(null);
  const frameRef = useRef(null);
  const lastTimeRef = useRef(null);

  const selectedRoute = useMemo(() => atlas.routeOptions.find((r) => r.id === save.atlas.selectedRouteId) ?? atlas.routeOptions[0], [atlas, save.atlas.selectedRouteId]);
  const activeRoutePoints = useMemo(() => buildRoutePoints(atlas, selectedRoute.id), [atlas, selectedRoute.id]);
  const playerPoint = useMemo(() => getPlayerPoint(activeRoutePoints, save.atlas.travelProgress), [activeRoutePoints, save.atlas.travelProgress]);
  const etaHours = useMemo(() => calculateEtaHours(selectedRoute, save.atlas.travelProgress), [selectedRoute, save.atlas.travelProgress]);

  useEffect(() => {
    saveGame(save);
  }, [save]);

  useEffect(() => {
    if (save.atlas.travelStatus !== 'traveling') return undefined;
    const loop = (time) => {
      const last = lastTimeRef.current ?? time;
      const deltaMs = Math.min(64, time - last);
      lastTimeRef.current = time;
      setSave((current) => {
        const result = travelTick({ atlas, save: current, deltaMs });
        if (result.event) setActiveEvent(result.event);
        return result.save;
      });
      frameRef.current = requestAnimationFrame(loop);
    };
    frameRef.current = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(frameRef.current);
      lastTimeRef.current = null;
    };
  }, [atlas, save.atlas.travelStatus]);

  const setDestination = useCallback((locationId) => {
    setSave((current) => saveGame({
      ...current,
      atlas: { ...current.atlas, destinationId: locationId, travelProgress: 0, travelStatus: 'idle' },
    }));
  }, []);

  const setRoute = useCallback((routeId) => {
    setSave((current) => saveGame({
      ...current,
      atlas: { ...current.atlas, selectedRouteId: routeId, travelProgress: 0, travelStatus: 'idle' },
    }));
  }, []);

  const startTravel = useCallback(() => {
    setActiveEvent(null);
    setSave((current) => saveGame({
      ...current,
      atlas: { ...current.atlas, travelStatus: 'traveling', lastTravelStartedAt: Date.now() },
      journal: [{ id: `travel-${Date.now()}`, time: Date.now(), type: 'travel', text: `Set out along ${selectedRoute.name}.` }, ...current.journal],
    }));
  }, [selectedRoute.name]);

  const pauseTravel = useCallback(() => {
    setSave((current) => saveGame({ ...current, atlas: { ...current.atlas, travelStatus: 'paused' } }));
  }, []);

  const resumeTravel = useCallback(() => {
    setSave((current) => saveGame({ ...current, atlas: { ...current.atlas, travelStatus: 'traveling' } }));
  }, []);

  const resolveChoice = useCallback((choice, bonus = 2) => {
    let outcome = choice.success || {};
    let roll = null;
    if (choice.dc) {
      roll = rollSkillCheck(choice.dc, bonus);
      outcome = roll.success ? (choice.success || {}) : (choice.failure || {});
      setLastRoll({ ...roll, dc: choice.dc, skill: choice.skill, label: choice.label });
    }
    setSave((current) => {
      let next = applyChoiceOutcome(current, outcome);
      next.atlas.travelStatus = outcome.encounter ? 'encounter' : 'traveling';
      next.journal.unshift({
        id: `choice-${Date.now()}`,
        time: Date.now(),
        type: roll?.success === false ? 'setback' : 'choice',
        text: roll ? `${choice.skill} ${roll.total}/${choice.dc}: ${choice.label}` : choice.label,
      });
      return saveGame(next);
    });
    setActiveEvent(null);
  }, []);

  const clearEncounter = useCallback(() => {
    setSave((current) => saveGame({ ...current, atlas: { ...current.atlas, activeEncounterId: null, travelStatus: 'traveling' } }));
  }, []);

  const resetSave = useCallback(() => {
    const fresh = resetGameSave();
    setSave(fresh);
    setActiveEvent(null);
    setLastRoll(null);
  }, []);

  return {
    save,
    setSave,
    selectedRoute,
    activeRoutePoints,
    playerPoint,
    etaHours,
    activeEvent,
    lastRoll,
    setRoute,
    setDestination,
    startTravel,
    pauseTravel,
    resumeTravel,
    resolveChoice,
    clearEncounter,
    resetSave,
  };
}
