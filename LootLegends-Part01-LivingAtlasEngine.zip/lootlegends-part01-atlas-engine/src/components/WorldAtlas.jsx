import React, { useEffect, useMemo, useRef, useState } from 'react';
import { BookOpen, Campfire, Compass, Crosshair, MapPinned, Minus, Plus, Route, ShieldAlert } from 'lucide-react';
import { useAtlasState } from '../hooks/useAtlasState.js';
import { smoothPath } from '../utils/geometry.js';

const typeColor = {
  town: '#dec28a', quest: '#e6b64e', fort: '#d7c6a5', shrine: '#a7d37a', dungeon: '#d76b57', merchant: '#69aac7', danger: '#cc4b43', event: '#d9a84b', dock: '#76a8c3', village: '#cfb279', camp: '#d7b873'
};
const typeGlyph = { town: '⌂', quest: '◆', fort: '♜', shrine: '✚', dungeon: '☠', merchant: '⚓', danger: '!', event: '•', dock: '⚓', village: '□', camp: '△' };

function TerrainRegion({ region }) {
  return <path className={`atlas-region atlas-region-${region.type}`} d={region.points} />;
}

function Field({ f }) {
  return <g transform={`translate(${f.x} ${f.y}) rotate(${f.r})`} className="atlas-field"><rect width={f.w} height={f.h} rx="12"/><path d={`M 20 20 L ${f.w-20} ${f.h-20} M ${f.w-20} 20 L 20 ${f.h-20}`} /></g>;
}

function Tree({ t }) {
  return <g transform={`translate(${t.x} ${t.y}) scale(${t.s}) rotate(${t.r})`} className="atlas-tree"><path d="M0 -18 L-9 5 L-3 4 L-12 22 L0 14 L12 22 L3 4 L9 5Z"/><rect x="-2" y="12" width="4" height="12" rx="1"/></g>;
}

function Mountain({ m }) {
  return <g transform={`translate(${m.x} ${m.y}) scale(${m.s}) rotate(${m.r})`} className="atlas-mountain"><path d="M0 -36 L-28 34 L28 34Z"/><path d="M0 -36 L-6 -3 L7 7 L0 34 L28 34Z"/><path d="M0 -36 L-11 -8 L-3 -3 L-16 10 L-28 34 L0 -36Z"/></g>;
}

function Settlement({ loc, onSelect, active }) {
  const color = typeColor[loc.type] ?? '#d2ba82';
  const glyph = typeGlyph[loc.type] ?? '•';
  const size = loc.type === 'town' ? 76 : loc.type === 'dungeon' ? 68 : 54;
  return (
    <g className={`map-location ${active ? 'is-active' : ''}`} transform={`translate(${loc.x} ${loc.y})`} onClick={() => onSelect(loc.id)}>
      <circle r={size / 2} fill="rgba(11,7,4,.74)" stroke={color} strokeWidth="4" />
      <circle r={size / 2 + 11} fill="none" stroke={color} strokeWidth="2" opacity=".25" />
      <text y="12" textAnchor="middle" style={{ fill: color }} className="map-glyph">{glyph}</text>
      <rect x={-Math.max(72, loc.name.length * 8) / 2} y={size / 2 + 9} width={Math.max(72, loc.name.length * 8)} height="30" rx="7" className="map-label-bg" />
      <text y={size / 2 + 31} textAnchor="middle" className="map-label">{loc.name}</text>
    </g>
  );
}

function Road({ road }) {
  return <path className={`atlas-road atlas-road-${road.kind}`} d={smoothPath(road.points)} />;
}

function River({ river }) {
  return <path className="atlas-river" style={{ strokeWidth: river.width }} d={smoothPath(river.points)} />;
}

function MapSurface({ state }) {
  const { atlas, zoom, offset, setOffset, selectedLocationId, setSelectedLocationId, activeRoutePoints, playerPoint } = state;
  const start = useRef(null);
  const [dragging, setDragging] = useState(false);

  const pointerDown = (e) => {
    const p = e.touches ? e.touches[0] : e;
    start.current = { x: p.clientX, y: p.clientY, ox: offset.x, oy: offset.y };
    setDragging(true);
  };
  const pointerMove = (e) => {
    if (!dragging || !start.current) return;
    const p = e.touches ? e.touches[0] : e;
    setOffset({ x: start.current.ox + (p.clientX - start.current.x), y: start.current.oy + (p.clientY - start.current.y) });
  };
  const pointerUp = () => setDragging(false);

  return (
    <div className="atlas-viewport" onMouseDown={pointerDown} onMouseMove={pointerMove} onMouseUp={pointerUp} onMouseLeave={pointerUp} onTouchStart={pointerDown} onTouchMove={pointerMove} onTouchEnd={pointerUp}>
      <svg viewBox="0 0 1800 1260" className="atlas-svg" style={{ transform: `translate(${offset.x}px, ${offset.y}px) scale(${zoom})` }}>
        <defs>
          <filter id="paperGrain"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="4" seed="7"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="table" tableValues="0 .18"/></feComponentTransfer></filter>
          <filter id="inkWobble"><feTurbulence type="fractalNoise" baseFrequency="0.01" numOctaves="2" seed="4"/><feDisplacementMap in="SourceGraphic" scale="5"/></filter>
          <radialGradient id="mapLight" cx="44%" cy="38%" r="78%"><stop offset="0" stopColor="#f1d69a" stopOpacity=".22"/><stop offset=".55" stopColor="#c79f5f" stopOpacity=".08"/><stop offset="1" stopColor="#000" stopOpacity=".38"/></radialGradient>
          <linearGradient id="waterShade" x1="0" x2="1"><stop stopColor="#28495b"/><stop offset=".5" stopColor="#5f8fa0"/><stop offset="1" stopColor="#213847"/></linearGradient>
        </defs>
        <rect width="1800" height="1260" className="atlas-base" />
        {atlas.terrain.regions.map((region) => <TerrainRegion key={region.id} region={region} />)}
        {atlas.terrain.fields.map((f) => <Field key={f.id} f={f} />)}
        {atlas.rivers.map((r) => <River key={r.id} river={r} />)}
        {atlas.roads.map((r) => <Road key={r.id} road={r} />)}
        {atlas.forests.map((t) => <Tree key={t.id} t={t} />)}
        {atlas.mountains.map((m) => <Mountain key={m.id} m={m} />)}
        <path className="selected-route-shadow" d={smoothPath(activeRoutePoints)} />
        <path className="selected-route" d={smoothPath(activeRoutePoints)} />
        {atlas.locations.map((loc) => <Settlement key={loc.id} loc={loc} active={loc.id === selectedLocationId} onSelect={setSelectedLocationId} />)}
        <g transform={`translate(${playerPoint.x} ${playerPoint.y})`} className="player-marker">
          <circle r="35"/><circle r="18"/><path d="M0 -22 L12 18 L0 10 L-12 18Z" />
        </g>
        <text x="470" y="740" className="region-name">Greenreach</text>
        <text x="1285" y="275" className="region-name small">The Greymarch</text>
        <text x="525" y="1110" className="region-name small">The Sunken Reach</text>
        <text x="55" y="120" className="map-title-cartouche">ASHMOOR & THE GREENMARCH</text>
        <rect width="1800" height="1260" fill="url(#mapLight)" pointerEvents="none" />
        <rect width="1800" height="1260" filter="url(#paperGrain)" opacity=".55" pointerEvents="none" />
      </svg>
      <div className="weather rain" />
      <div className="atlas-vignette" />
    </div>
  );
}

function RouteCard({ route, active, onClick }) {
  return (
    <button className={`route-card ${active ? 'selected' : ''}`} onClick={onClick}>
      <div><b>{route.name}</b><span>{route.subtitle}</span></div>
      <div className="route-meta"><span>{route.hours}h</span><span>{'☠'.repeat(route.danger)}{'○'.repeat(Math.max(0, 5 - route.danger))}</span></div>
    </button>
  );
}

export function WorldAtlas() {
  const state = useAtlasState();
  const { atlas, selectedRoute, selectedRouteId, setSelectedRouteId, selectedLocation, centerOnPlayer, zoomIn, zoomOut, advanceTravel } = state;

  useEffect(() => {
    const id = window.setInterval(() => {
      document.documentElement.style.setProperty('--glowPulse', `${Math.sin(Date.now() / 700) * 0.5 + 0.5}`);
    }, 80);
    return () => clearInterval(id);
  }, []);

  return (
    <main className="ll-shell">
      <header className="ll-header">
        <div className="seal"><Compass size={28}/></div>
        <div><h1>Loot <em>&</em> Legends</h1><p>Living Travel Atlas</p></div>
        <button className="square"><BookOpen size={26}/></button>
      </header>

      <section className="status-grid">
        <div className="status-card"><small>Current Location</small><strong>{atlas.locations.find(l => l.id === atlas.current.locationId)?.name}</strong><span>The Silver Road</span></div>
        <div className="status-card"><small>Destination</small><strong>{selectedLocation.name}</strong><span>{selectedLocation.type}</span></div>
        <div className="status-card"><small>Route</small><strong>{selectedRoute.name}</strong><span>{selectedRoute.reward}</span></div>
        <div className="status-card"><small>Weather</small><strong>{atlas.current.weather}</strong><span>Visibility: Good</span></div>
      </section>

      <section className="map-panel">
        <div className="map-tools">
          <button onClick={zoomIn}><Plus/> <span>Zoom</span></button>
          <button onClick={zoomOut}><Minus/> <span>Out</span></button>
          <button onClick={centerOnPlayer}><Crosshair/> <span>Find</span></button>
        </div>
        <MapSurface state={state} />
      </section>

      <section className="legend-bar">
        <span><i className="dot blue"/> You</span><span><i className="dot gold"/> Objective</span><span><i className="line"/> Road</span><span><i className="dot red"/> Danger</span><span><i className="dot teal"/> Merchant/NPC</span>
      </section>

      <section className="lower-grid">
        <div className="route-list">
          <h2><Route size={18}/> Available Routes</h2>
          {atlas.routeOptions.map((route) => <RouteCard key={route.id} route={route} active={route.id === selectedRouteId} onClick={() => setSelectedRouteId(route.id)} />)}
        </div>
        <aside className="event-card">
          <h2><ShieldAlert size={18}/> Selected Site</h2>
          <strong>{selectedLocation.name}</strong>
          <p>{selectedLocation.description}</p>
          <button onClick={advanceTravel}><MapPinned/> Advance Travel</button>
          <button><Campfire/> Camp</button>
        </aside>
      </section>
    </main>
  );
}
