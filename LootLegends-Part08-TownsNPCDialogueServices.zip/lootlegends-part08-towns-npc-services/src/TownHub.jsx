import React, { useMemo, useState } from 'react';
import { TOWNS } from '../data/towns.js';
import { chooseDialogueTopic, getServiceCost, useTownService } from './townEngine.js';
import '../styles/townHub.css';

export default function TownHub({ townId='brackenport', townState, setTownState, gameState, setGameState, onOpenShop, onOpenQuestBoard, onReturnToMap }) {
  const town = TOWNS[townId];
  const [districtId, setDistrictId] = useState(town?.districts?.[0]?.id);
  const [npcId, setNpcId] = useState(town?.npcs?.[0]?.id);
  const [reply, setReply] = useState(null);
  const rep = townState?.townReputation?.[townId] || 0;

  const visibleNpcs = useMemo(() => town.npcs.filter(n => !districtId || n.district === districtId), [town, districtId]);
  const npc = town.npcs.find(n => n.id === npcId) || visibleNpcs[0];
  const district = town.districts.find(d => d.id === districtId) || town.districts[0];

  function selectDistrict(id) {
    setDistrictId(id); const first = town.npcs.find(n => n.district === id); if (first) setNpcId(first.id); setReply(null);
  }

  function talk(topicId) {
    const out = chooseDialogueTopic(townState, townId, npc.id, topicId);
    setTownState(out.state); setReply(out.result?.reply || null);
    if (out.result?.open === 'questBoard') onOpenQuestBoard?.(townId);
  }

  function service(serviceId) {
    const svc = town.services[serviceId];
    if (svc?.type === 'shop') { onOpenShop?.(svc.merchantId); return; }
    if (svc?.type === 'guild') { onOpenQuestBoard?.(townId); return; }
    const out = useTownService(townState, gameState, townId, serviceId);
    setTownState(out.state); setGameState?.(out.gameState); setReply(out.result.message);
  }

  if (!town) return <div className="ll-town-shell">Unknown town.</div>;

  return <main className="ll-town-shell">
    <header className="ll-town-hero">
      <button className="ll-small-btn" onClick={onReturnToMap}>← Map</button>
      <div><h1>{town.name}</h1><p>{town.region} · Reputation {rep}</p></div>
    </header>
    <section className="ll-town-scene">
      <div className="ll-skyglow"/><div className="ll-roofs"/><div className="ll-lanterns"/>
      <p>{town.description}</p>
    </section>
    <nav className="ll-districts">{town.districts.map(d => <button key={d.id} className={d.id===districtId?'active':''} onClick={()=>selectDistrict(d.id)}>{d.name}</button>)}</nav>
    <section className="ll-town-card"><h2>{district.name}</h2><p>{district.mood}</p></section>
    <section className="ll-npc-layout">
      <aside className="ll-npc-list">{visibleNpcs.map(n => <button key={n.id} className={n.id===npc?.id?'active':''} onClick={()=>{setNpcId(n.id);setReply(null);}}><b>{n.name}</b><span>{n.title}</span></button>)}</aside>
      {npc && <article className="ll-dialogue-panel">
        <div className={`ll-portrait ${npc.portrait}`}><span>{npc.name.split(' ').map(x=>x[0]).join('')}</span></div>
        <h2>{npc.name}</h2><h3>{npc.title}</h3>
        <p className="ll-speech">“{reply || npc.greeting}”</p>
        <div className="ll-topic-grid">{npc.topics.map(t => <button key={t.id} onClick={()=>talk(t.id)}>{t.label}</button>)}</div>
        <div className="ll-service-grid">{npc.services.map(id => {
          const svc = town.services[id]; const cost = getServiceCost(svc, rep);
          return <button key={id} onClick={()=>service(id)}><strong>{svc.label}</strong>{cost ? <span>{cost} gold</span> : <span>Open</span>}</button>;
        })}</div>
      </article>}
    </section>
  </main>;
}
