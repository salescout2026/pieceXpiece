import { BACKUP_KEY, SAVE_KEY, SAVE_VERSION, createDefaultSave, normalizeSave } from "./saveSchema";
import { migrateSave } from "./saveMigrations";

function safeStorage() {
  try {
    const key = "loot_legends_storage_test";
    localStorage.setItem(key, "1");
    localStorage.removeItem(key);
    return localStorage;
  } catch {
    return null;
  }
}

export class SaveManager {
  constructor({ storage = safeStorage(), saveKey = SAVE_KEY, backupKey = BACKUP_KEY } = {}) {
    this.storage = storage;
    this.saveKey = saveKey;
    this.backupKey = backupKey;
    this.listeners = new Set();
    this.current = this.load();
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  emit() {
    this.listeners.forEach((listener) => listener(this.current));
  }

  load() {
    if (!this.storage) return createDefaultSave();
    try {
      const raw = this.storage.getItem(this.saveKey);
      if (!raw) return createDefaultSave();
      return migrateSave(JSON.parse(raw));
    } catch (error) {
      console.warn("Primary save failed. Attempting backup.", error);
      return this.loadBackup();
    }
  }

  loadBackup() {
    if (!this.storage) return createDefaultSave();
    try {
      const raw = this.storage.getItem(this.backupKey);
      return raw ? migrateSave(JSON.parse(raw)) : createDefaultSave();
    } catch {
      return createDefaultSave();
    }
  }

  write(nextSave, reason = "manual") {
    const normalized = normalizeSave({ ...nextSave, version: SAVE_VERSION, savedAt: new Date().toISOString() });
    if (this.storage) {
      try {
        const oldRaw = this.storage.getItem(this.saveKey);
        if (oldRaw) this.storage.setItem(this.backupKey, oldRaw);
        this.storage.setItem(this.saveKey, JSON.stringify(normalized));
      } catch (error) {
        console.error(`Save write failed: ${reason}`, error);
      }
    }
    this.current = normalized;
    this.emit();
    return normalized;
  }

  patch(pathOrUpdater, value, reason = "patch") {
    const next = typeof pathOrUpdater === "function"
      ? pathOrUpdater(structuredCloneSafe(this.current))
      : setPath(structuredCloneSafe(this.current), pathOrUpdater, value);
    return this.write(next, reason);
  }

  reset() {
    return this.write(createDefaultSave(), "reset");
  }

  exportSave() {
    return JSON.stringify(this.current, null, 2);
  }

  importSave(text) {
    const parsed = migrateSave(JSON.parse(text));
    return this.write(parsed, "import");
  }

  clearStorage() {
    if (this.storage) {
      this.storage.removeItem(this.saveKey);
      this.storage.removeItem(this.backupKey);
    }
    this.current = createDefaultSave();
    this.emit();
    return this.current;
  }
}

export const saveManager = new SaveManager();

export function setPath(obj, path, value) {
  const keys = Array.isArray(path) ? path : String(path).split(".").filter(Boolean);
  if (!keys.length) return value;
  let cursor = obj;
  keys.slice(0, -1).forEach((key) => {
    if (!cursor[key] || typeof cursor[key] !== "object") cursor[key] = {};
    cursor = cursor[key];
  });
  cursor[keys[keys.length - 1]] = value;
  return obj;
}

export function structuredCloneSafe(value) {
  if (typeof structuredClone === "function") return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}
