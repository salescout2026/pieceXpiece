import './QuestScene.css';
import { SKILLS } from '../data/questEvents.js';

export default function QuestScene({ node, choices, questState, onChoose, party = [] }) {
  const outcome = questState?.lastOutcome;
  return (
    <section className="ll-quest-scene">
      <div className="ll-scene-hero" data-scene={node.portrait || node.type}>
        <div className="ll-hero-vignette" />
        <div className="ll-scene-kicker">{node.type?.replace(/([A-Z])/g, ' $1')}</div>
        <h2>{node.sceneTitle}</h2>
        <p>{node.weather}</p>
      </div>

      <div className="ll-story-panel">
        <h3>What You See</h3>
        {(node.body || []).map((p, idx) => <p key={idx}>{p}</p>)}
      </div>

      {node.discoveries?.length > 0 && (
        <div className="ll-discovery-grid">
          {node.discoveries.map((d) => (
            <article key={d.id} className={`ll-discovery ll-${d.kind}`}>
              <span className="ll-discovery-seal">{iconForKind(d.kind)}</span>
              <div><strong>{d.label}</strong><small>{d.text}</small></div>
            </article>
          ))}
        </div>
      )}

      {outcome && (
        <div className="ll-outcome-panel">
          <div className="ll-outcome-title">What Changed</div>
          <p>{outcome.text}</p>
          {outcome.check?.roll && <small>Rolled {outcome.check.roll} + {outcome.check.bestBonus} = {outcome.check.total}</small>}
        </div>
      )}

      <div className="ll-choice-list">
        <div className="ll-choice-header">Take Action</div>
        {choices.map((choice) => <ChoiceButton key={choice.id} choice={choice} onChoose={onChoose} party={party} />)}
      </div>
    </section>
  );
}

function ChoiceButton({ choice, onChoose }) {
  const skill = choice.skill ? SKILLS[choice.skill] : null;
  return (
    <button className="ll-choice-button" onClick={() => onChoose(choice.id)}>
      <span className="ll-choice-icon">{skill?.icon || (choice.requiresItem ? '◆' : '➤')}</span>
      <span className="ll-choice-copy">
        <strong>{choice.label}</strong>
        <small>{choice.requiresItem ? `Requires ${choice.requiresItem}` : skill ? `${skill.label} DC ${choice.dc}` : choice.routeId ? `Route: ${choice.routeId}` : 'Story action'}</small>
      </span>
      <span className="ll-choice-rewards">{choice.success?.xp ? `+${choice.success.xp} XP` : 'Continue'}</span>
    </button>
  );
}

function iconForKind(kind) {
  return { clue: '◉', trail: '⌁', site: '⌂', lock: '◇', dungeon: '☠' }[kind] || '✦';
}
