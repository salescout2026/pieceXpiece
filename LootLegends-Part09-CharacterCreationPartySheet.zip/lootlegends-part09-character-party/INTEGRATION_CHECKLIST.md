# Integration Checklist

1. Copy `src/data/characterData.js`.
2. Copy `src/systems/characterSystem.js`.
3. Copy `src/components/CharacterCreationScreen.jsx`.
4. Copy `src/components/PartySheetScreen.jsx`.
5. Copy `src/styles/character-party.css` and import it once.
6. Add routes/buttons:
   - New Game -> CharacterCreationScreen
   - Party/Profile -> PartySheetScreen
7. Save party state using `loadPartyState()` and `savePartyState()`.
8. Connect inventory equipment totals from Part 06 using the optional `equipmentBonuses` field.
