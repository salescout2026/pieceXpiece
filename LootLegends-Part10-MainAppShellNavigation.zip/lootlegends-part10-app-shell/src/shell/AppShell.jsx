import { createScreenRegistry } from "./screenRegistry";
import { SCREEN_IDS, useNavigationStore } from "../state/navigationStore";
import "../styles/shell.css";

const NAV_ITEMS = [
  { id: SCREEN_IDS.MAP, label: "Atlas", glyph: "⌖" },
  { id: SCREEN_IDS.QUESTS, label: "Quests", glyph: "✦" },
  { id: SCREEN_IDS.TOWN, label: "Town", glyph: "⌂" },
  { id: SCREEN_IDS.INVENTORY, label: "Pack", glyph: "◈" },
  { id: SCREEN_IDS.PARTY, label: "Party", glyph: "♜" },
];

export default function AppShell({ screens = {}, gameState, dispatch }) {
  const nav = useNavigationStore(SCREEN_IDS.TITLE);
  const registry = createScreenRegistry(screens);
  const Screen = registry[nav.screen] ?? registry[SCREEN_IDS.TITLE];
  const inGame = nav.screen !== SCREEN_IDS.TITLE;

  return (
    <div className="ll-app-shell">
      <div className="ll-ambient ll-ambient--one" />
      <div className="ll-ambient ll-ambient--two" />

      {inGame && <TopBar nav={nav} gameState={gameState} />}

      <main className={inGame ? "ll-screen ll-screen--with-bars" : "ll-screen"}>
        <Screen nav={nav} payload={nav.payload} gameState={gameState} dispatch={dispatch} />
      </main>

      {inGame && <BottomNav nav={nav} />}
    </div>
  );
}

function TopBar({ nav, gameState }) {
  const hero = gameState?.party?.[0];
  return (
    <header className="ll-topbar">
      <button className="ll-icon-button" onClick={nav.back} aria-label="Back">‹</button>
      <div className="ll-topbar-title">
        <span>Loot & Legends</span>
        <small>{hero ? `${hero.name} · Level ${hero.level ?? 1}` : "Living Atlas Campaign"}</small>
      </div>
      <div className="ll-currency"><span>◈</span>{gameState?.gold ?? 0}</div>
    </header>
  );
}

function BottomNav({ nav }) {
  return (
    <nav className="ll-bottomnav">
      {NAV_ITEMS.map((item) => (
        <button
          key={item.id}
          className={nav.screen === item.id ? "is-active" : ""}
          onClick={() => nav.replace(item.id)}
        >
          <span className="ll-nav-glyph">{item.glyph}</span>
          <span>{item.label}</span>
        </button>
      ))}
    </nav>
  );
}
