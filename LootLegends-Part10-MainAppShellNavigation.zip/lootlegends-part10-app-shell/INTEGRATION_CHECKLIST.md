# Part 10 Integration Checklist

1. Copy `src/shell`, `src/state`, and `src/styles/shell.css` into the project.
2. Import `shell.css` from your main entry file, usually `src/main.jsx` or `src/App.jsx`.
3. Replace the old root component with `<AppShell />`.
4. Register each module screen in `screenRegistry.js`:
   - atlas from Part 01
   - travel from Part 02
   - quests from Part 03
   - combat from Parts 04–05
   - inventory from Part 06
   - shop/loot from Part 07
   - towns from Part 08
   - party sheet from Part 09
5. Remove old duplicate navigation bars/screens after this shell is active.
6. Confirm Android safe-area spacing: top bar visible, bottom nav not hidden behind phone buttons.
