export const TOWN_SERVICE_TYPES = {
  SHOP: 'shop', INN: 'inn', HEALER: 'healer', GUILD: 'guild', BLACKSMITH: 'blacksmith', STABLE: 'stable', RUMOR: 'rumor', TRAINING: 'training'
};

export const TOWNS = {
  brackenport: {
    id: 'brackenport', name: 'Brackenport', region: 'Saltmarsh Coast', mapLocationId: 'brackenport',
    reputation: 0, danger: 2,
    description: 'A storm-bitten harbor town built from black timber, brass lanterns, and stubborn survival.',
    districts: [
      { id:'docks', name:'Lantern Docks', mood:'salt, fog, fish oil, and whispered contracts' },
      { id:'market', name:'Crowmarket', mood:'muddy stalls, shielded candles, and sharp-eyed merchants' },
      { id:'chapel', name:'Chapel of the Last Flame', mood:'warm stone, incense, and old grief' },
      { id:'guild', name:'Adventurers’ Hall', mood:'maps nailed to beams, bounty wax, and scarred veterans' }
    ],
    npcs: [
      { id:'mara', name:'Mara Veyne', title:'Harbormaster', district:'docks', portrait:'harbormaster', disposition:1,
        greeting:'Keep your blade dry and your purse drier. Brackenport eats fools whole.',
        topics:[
          { id:'work', label:'Ask about work', reply:'Ships vanish near the reef. Dockhands blame fog. I blame whatever sings underneath it.', flags:['rumor_reef_song'] },
          { id:'town', label:'Ask about the town', reply:'We survive by trade, lies, and lantern oil. Usually in that order.' }
        ], services:['stable','rumor'] },
      { id:'elric', name:'Brother Elric', title:'Flame Keeper', district:'chapel', portrait:'priest', disposition:2,
        greeting:'The road leaves marks on the soul. Sit by the flame a moment.',
        topics:[
          { id:'curse', label:'Ask about curses', reply:'A curse is a debt with teeth. Bring me relic ash and I may loosen its bite.', unlockQuest:'embers_for_the_dead' }
        ], services:['healer','inn'] },
      { id:'corvin', name:'Corvin Ash', title:'Guild Scribe', district:'guild', portrait:'scribe', disposition:0,
        greeting:'Names, contracts, witnesses. Heroes are just paperwork with better songs.',
        topics:[
          { id:'contracts', label:'Review contracts', reply:'Three sealed writs are fresh. One smells of swamp water. One smells of blood.', open:'questBoard' }
        ], services:['guild'] },
      { id:'nyssa', name:'Nyssa Blackbell', title:'Curio Merchant', district:'market', portrait:'merchant', disposition:1,
        greeting:'If it glows, whispers, bleeds, or bites, I can price it.',
        topics:[{id:'rare',label:'Ask about rare goods',reply:'Rare goods find rare people. Increase your reputation and I’ll show the locked case.'}],
        services:['shop'] }
    ],
    services: {
      shop: { type:'shop', label:'Browse Nyssa’s Curiosities', merchantId:'nyssa_blackbell', reputationDiscount:true },
      healer: { type:'healer', label:'Receive Healing', baseCost:25, effect:{ hpPercent:1, remove:['bleeding','poisoned'] } },
      inn: { type:'inn', label:'Rest at the Ember Cot', baseCost:12, effect:{ hpPercent:1, advanceTime:8 } },
      guild: { type:'guild', label:'Open Quest Board' },
      stable: { type:'stable', label:'Hire Road Guide', baseCost:20, effect:{ travelSpeedBonus:0.15, durationTravel:1 } },
      rumor: { type:'rumor', label:'Buy Dock Rumor', baseCost:5, rumorPool:['reef_song','lantern_widow','black_sail'] }
    }
  },
  thornwatch: {
    id:'thornwatch', name:'Thornwatch', region:'Old King’s Road', mapLocationId:'thornwatch', reputation:0, danger:4,
    description:'A walled frontier settlement where every roofline faces the dark forest.',
    districts:[
      {id:'gate',name:'East Gate',mood:'wet stone, arrow slits, and nervous guards'},
      {id:'forge',name:'The Red Anvil',mood:'coal smoke, iron sparks, and ringing steel'},
      {id:'green',name:'Warden’s Green',mood:'mud, horses, tents, and anxious travelers'}
    ],
    npcs:[
      {id:'brakka',name:'Brakka Redhand',title:'Master Smith',district:'forge',portrait:'smith',disposition:0,
       greeting:'Show me coin or show me monster bone. I work with both.',
       topics:[{id:'upgrade',label:'Ask about upgrades',reply:'Bring ironwood resin from the Deepmere and I can wake a blade up properly.'}], services:['blacksmith','shop']},
      {id:'warden',name:'Ser Cael Rowan',title:'Warden Captain',district:'gate',portrait:'warden',disposition:1,
       greeting:'Road is closed after dusk unless you enjoy becoming a cautionary tale.',
       topics:[{id:'forest',label:'Ask about the forest',reply:'Trees moved last night. Not branches. Trees.', flags:['forest_moved']}], services:['guild','training']}
    ],
    services:{
      blacksmith:{type:'blacksmith',label:'Upgrade Equipment', baseCost:40},
      shop:{type:'shop',label:'Browse the Red Anvil',merchantId:'red_anvil'},
      guild:{type:'guild',label:'Review Warden Contracts'},
      training:{type:'training',label:'Train with the Wardens',baseCost:35,effect:{xp:25}}
    }
  }
};
