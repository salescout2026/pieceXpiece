import React, { useMemo, useState } from 'react';
import { MERCHANTS, SHOP_ITEMS, ITEM_RARITY } from '../data/shopCatalog.js';
import { getMerchantStock, buyItem, sellItem, getItemPrice } from '../systems/shopEngine.js';
import '../styles/shop-loot.css';

export default function ShopScreen({ merchantId = 'ironhold_smith', inventoryState, onChange, onClose }) {
  const [tab, setTab] = useState('buy');
  const merchant = MERCHANTS[merchantId];
  const stock = useMemo(() => getMerchantStock(merchantId, inventoryState), [merchantId, inventoryState]);
  const invItems = (inventoryState?.items || []).map(i => ({ ...i, item: SHOP_ITEMS[i.itemId] })).filter(i => i.item);

  function handleBuy(itemId) {
    const result = buyItem(inventoryState, merchantId, itemId);
    if (result.ok) onChange?.(result.state, result);
    else alert(result.reason);
  }

  function handleSell(instanceId) {
    const result = sellItem(inventoryState, merchantId, instanceId);
    if (result.ok) onChange?.(result.state, result);
    else alert(result.reason);
  }

  return (
    <section className="ll-shop-screen">
      <header className="ll-shop-hero">
        <button className="ll-close" onClick={onClose}>×</button>
        <div className="ll-merchant-portrait"><span>{merchant?.name?.slice(0,1) || 'M'}</span></div>
        <div>
          <p className="ll-kicker">Merchant</p>
          <h1>{merchant?.name}</h1>
          <h2>{merchant?.title}</h2>
          <p className="ll-greeting">“{merchant?.greeting}”</p>
        </div>
      </header>

      <div className="ll-shop-wallet"><span>Gold</span><strong>{inventoryState?.gold || 0}</strong></div>

      <nav className="ll-shop-tabs">
        <button className={tab === 'buy' ? 'active' : ''} onClick={() => setTab('buy')}>Buy</button>
        <button className={tab === 'sell' ? 'active' : ''} onClick={() => setTab('sell')}>Sell</button>
      </nav>

      <div className="ll-shop-list">
        {tab === 'buy' && stock.map(item => (
          <article className="ll-shop-card" key={item.id} style={{ '--rarity': ITEM_RARITY[item.rarity]?.color }}>
            <div className="ll-item-seal">{item.name.slice(0,1)}</div>
            <div className="ll-item-body">
              <div className="ll-item-title"><strong>{item.name}</strong><span>{ITEM_RARITY[item.rarity]?.label}</span></div>
              <p>{item.description}</p>
              <small>{Object.entries(item.stats || {}).map(([k,v]) => `+${v} ${k}`).join(' · ') || item.tags?.join(' · ')}</small>
            </div>
            <button className="ll-buy" onClick={() => handleBuy(item.id)}>Buy {item.price}</button>
          </article>
        ))}

        {tab === 'sell' && invItems.map(({ instanceId, itemId, item }) => (
          <article className="ll-shop-card" key={instanceId} style={{ '--rarity': ITEM_RARITY[item.rarity]?.color }}>
            <div className="ll-item-seal">{item.name.slice(0,1)}</div>
            <div className="ll-item-body">
              <div className="ll-item-title"><strong>{item.name}</strong><span>{ITEM_RARITY[item.rarity]?.label}</span></div>
              <p>{item.description}</p>
            </div>
            <button className="ll-buy" onClick={() => handleSell(instanceId)}>Sell {getItemPrice(itemId, merchantId, inventoryState, 'sell')}</button>
          </article>
        ))}
      </div>
    </section>
  );
}
