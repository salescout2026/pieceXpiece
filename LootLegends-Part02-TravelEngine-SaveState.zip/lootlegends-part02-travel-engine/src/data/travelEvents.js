export const travelEventTable = [
  {
    id: 'rain-washed-tracks',
    minProgress: 0.18,
    tags: ['road', 'rain'],
    title: 'Rain-Washed Tracks',
    text: 'Fresh cart tracks cut through the mud, then vanish beneath a curtain of rain. Something heavy left the road before dawn.',
    choices: [
      { id: 'ranger-track', label: 'Ranger: follow the broken wheel marks', skill: 'Survival', dc: 11, success: { clue: 1, xp: 20 }, failure: { danger: 1 } },
      { id: 'press-on', label: 'Press on and keep formation', success: { supplies: -1 } },
    ],
  },
  {
    id: 'lantern-in-ditch',
    minProgress: 0.34,
    tags: ['road', 'mystery'],
    title: 'The Lantern in the Ditch',
    text: 'A green lantern burns cold beside the road. No hand holds it. No oil feeds it. The flame bends toward your destination.',
    choices: [
      { id: 'inspect-lantern', label: 'Inspect the lantern flame', skill: 'Arcana', dc: 12, success: { clue: 1, reveal: 'old-bell-tower' }, failure: { condition: 'Uneasy' } },
      { id: 'snuff-it', label: 'Snuff it out and move quickly', success: { danger: -1 }, failure: { danger: 1 } },
    ],
  },
  {
    id: 'pilgrim-shadow',
    minProgress: 0.58,
    tags: ['chapel', 'cult'],
    title: 'Bell-Marked Pilgrim',
    text: 'A stooped pilgrim walks the roadside ahead. The hem of his cloak is marked with white bell wax.',
    choices: [
      { id: 'question-pilgrim', label: 'Question him before he reaches the chapel', skill: 'Insight', dc: 13, success: { clue: 2, reputation: { chapel: 1 } }, failure: { encounter: 'bell-pilgrim-ambush' } },
      { id: 'tail-pilgrim', label: 'Follow at a distance', skill: 'Stealth', dc: 10, success: { reveal: 'gloom-tollhouse' }, failure: { danger: 1 } },
    ],
  },
  {
    id: 'bridge-tolls',
    minProgress: 0.76,
    tags: ['bridge', 'social'],
    title: 'The Ferryman’s Toll',
    text: 'A ferryman blocks the narrow bridge with a hooked pole. He knows your destination and names a price before you speak.',
    choices: [
      { id: 'pay-toll', label: 'Pay the toll', success: { gold: -15, danger: -1 } },
      { id: 'bargain', label: 'Bargain with the ferryman', skill: 'Persuasion', dc: 12, success: { reputation: { ferrymen: 1 } }, failure: { supplies: -2 } },
    ],
  },
];

export const encounterTable = {
  'bell-pilgrim-ambush': {
    id: 'bell-pilgrim-ambush',
    title: 'Bell Pilgrim Ambush',
    enemyIds: ['bell-acolyte', 'marsh-hound'],
    text: 'The pilgrim rings a hand bell wrapped in cloth. Shapes rise from the reeds.',
  },
};
