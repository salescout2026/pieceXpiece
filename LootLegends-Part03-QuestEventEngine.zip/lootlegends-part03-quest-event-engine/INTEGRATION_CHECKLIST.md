# Part 03 Integration Checklist

- [ ] Install Part 01 atlas first.
- [ ] Install Part 02 travel/save first.
- [ ] Add Quest Event Engine files.
- [ ] Replace old generic quest option cards with `QuestScene`.
- [ ] Make quest buttons call `choose(choice.id)`.
- [ ] Save returned `questState` with the game save.
- [ ] Apply `outcome.rewards.locations` to discovered atlas locations.
- [ ] Apply `outcome.rewards.event` to travel road event queue.
- [ ] Apply `outcome.rewards.combat` to the combat handoff.
- [ ] Add known inventory ids: `bellWardSeal`, `reedglassLantern`.
- [ ] Add party skill data so class-specific choices appear.
- [ ] Test: choice success and failure both persist after app reload.
