# Part 02 Integration Checklist

- [ ] Copy all `src/` folders into the project created by Part 01.
- [ ] Add `import './components/TravelHud.css';` if your bundler does not pick CSS imports from `TravelHud.jsx`.
- [ ] Update `WorldAtlas.jsx` to use `useTravelEngine(atlas)`.
- [ ] Remove old temporary travel progress state from `useAtlasState` if no longer needed.
- [ ] Confirm route buttons call `engine.setRoute(route.id)`.
- [ ] Confirm map pins call `engine.setDestination(locationId)`.
- [ ] Confirm Start Travel calls `engine.startTravel()`.
- [ ] Confirm player marker moves automatically while status is `traveling`.
- [ ] Confirm road events pause travel and choices resume it.
- [ ] Confirm refreshing the app preserves current location, progress, supplies, discovered locations, and journal.
