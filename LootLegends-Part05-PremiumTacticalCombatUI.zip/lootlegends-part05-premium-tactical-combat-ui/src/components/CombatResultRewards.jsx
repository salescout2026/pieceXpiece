import React from "react";
import "./CombatResultRewards.css";

export function CombatResultRewards({ result, rewards = {}, loot = [], onContinue, onInspectLoot }) {
  const victory = result !== "defeat";
  return (
    <section className="ll-reward-screen">
      <header className="ll-reward-header">
        <div className={victory ? "seal victory" : "seal defeat"}>{victory ? "✓" : "!"}</div>
        <div>
          <p>{victory ? "Scene Cleared" : "Retreat"}</p>
          <h1>{victory ? "The road opens ahead" : "The party falls back"}</h1>
        </div>
      </header>

      <div className="ll-reward-stats">
        <div><span>XP Gained</span><strong>+{rewards.xp || 0}</strong></div>
        <div><span>Gold Found</span><strong>+{rewards.gold || 0}</strong></div>
        <div><span>Reputation</span><strong>{rewards.reputation || "+0"}</strong></div>
        <div><span>Danger</span><strong>{rewards.danger || "—"}</strong></div>
      </div>

      <div className="ll-loot-list">
        <h2>Loot & Rewards</h2>
        {(loot.length ? loot : [
          { name: "Road-Worn Charm", rarity: "Common", desc: "A battered token taken from the battlefield." },
          { name: "Blackreed Note", rarity: "Clue", desc: "A note that may unlock a journal lead." }
        ]).map((item) => (
          <button key={item.name} onClick={() => onInspectLoot?.(item)}>
            <div className="loot-art">◆</div>
            <div><strong>{item.name}</strong><span>{item.rarity}</span><p>{item.desc}</p></div>
          </button>
        ))}
      </div>

      <button className="ll-continue" onClick={onContinue}>Continue Journey</button>
    </section>
  );
}

export default CombatResultRewards;
