import { makeSeeded } from '../utils/geometry.js';

const rng = makeSeeded(934211);
const scatter = (count, box, kind, jitter = 0) => Array.from({ length: count }, (_, i) => ({
  id: `${kind}-${i}`,
  kind,
  x: box.x + rng() * box.w + (rng() - 0.5) * jitter,
  y: box.y + rng() * box.h + (rng() - 0.5) * jitter,
  s: 0.55 + rng() * 0.9,
  r: -18 + rng() * 36,
}));

export const atlas = {
  id: 'ashmoor-greenreach',
  name: 'Ashmoor & the Greenmarch',
  size: { width: 1800, height: 1260 },
  startLocationId: 'ashmoor-cross',
  terrain: {
    regions: [
      { id: 'greenreach', name: 'Greenreach', type: 'grassland', points: 'M 230 180 C 510 80 830 130 1010 245 C 1160 345 1125 520 970 615 C 690 790 380 685 190 545 C 35 430 70 270 230 180 Z' },
      { id: 'greymarch', name: 'The Greymarch', type: 'moor', points: 'M 1020 60 C 1300 40 1640 105 1800 280 L 1800 720 C 1590 620 1360 575 1110 650 C 1015 530 1130 340 1020 60 Z' },
      { id: 'sunken-reach', name: 'The Sunken Reach', type: 'marsh', points: 'M 0 675 C 205 565 440 635 640 735 C 850 845 1030 795 1240 705 C 1420 630 1640 675 1800 780 L 1800 1260 L 0 1260 Z' },
      { id: 'stonefang', name: 'Stonefang Peaks', type: 'mountain', points: 'M 0 0 L 450 0 C 430 195 350 330 210 405 C 95 465 30 570 0 680 Z' },
      { id: 'widowfen', name: 'Widowfen Wood', type: 'forest', points: 'M 10 430 C 165 305 305 315 405 450 C 275 560 125 565 10 505 Z' },
    ],
    fields: [
      { id: 'fields-a', x: 505, y: 225, w: 220, h: 160, r: -8 },
      { id: 'fields-b', x: 690, y: 310, w: 270, h: 125, r: 8 },
      { id: 'fields-c', x: 390, y: 520, w: 260, h: 125, r: 4 },
      { id: 'fields-d', x: 1225, y: 250, w: 190, h: 110, r: -12 },
    ],
  },
  rivers: [
    { id: 'reedwater', width: 40, points: [{x: 1180,y:0},{x:1160,y:190},{x:1135,y:310},{x:1165,y:475},{x:1110,y:620},{x:1030,y:790},{x:930,y:975},{x:875,y:1260}]},
    { id: 'blackreed', width: 30, points: [{x:0,y:850},{x:225,y:775},{x:450,y:795},{x:615,y:870},{x:760,y:910},{x:980,y:860},{x:1210,y:815},{x:1800,y:850}]},
    { id: 'pilgrim-run', width: 22, points: [{x:620,y:0},{x:610,y:210},{x:660,y:390},{x:630,y:595},{x:555,y:770},{x:515,y:1010},{x:480,y:1260}]},
  ],
  roads: [
    { id: 'silver-road', name: 'The Silver Road', kind: 'main', points: [{x:175,y:210},{x:350,y:260},{x:520,y:365},{x:660,y:455},{x:840,y:560},{x:1035,y:675},{x:1240,y:760},{x:1510,y:840}]},
    { id: 'pilgrim-road', name: 'Pilgrim Road', kind: 'main', points: [{x:500,y:60},{x:550,y:220},{x:610,y:400},{x:690,y:580},{x:765,y:735},{x:830,y:920},{x:840,y:1190}]},
    { id: 'ferry-cut', name: "Ferryman's Cut", kind: 'path', points: [{x:730,y:875},{x:925,y:800},{x:1130,y:740},{x:1360,y:700},{x:1640,y:650}]},
    { id: 'marsh-walk', name: 'Blackreed Causeway', kind: 'path', points: [{x:285,y:830},{x:480,y:880},{x:680,y:940},{x:915,y:980},{x:1170,y:930},{x:1420,y:860}]},
    { id: 'watch-road', name: 'Old Watch Road', kind: 'main', points: [{x:955,y:350},{x:1210,y:305},{x:1435,y:275},{x:1685,y:225}]},
  ],
  routeOptions: [
    { id: 'silver-road', name: 'The Silver Road', subtitle: 'Longer, patrolled, best for supplies.', danger: 1, hours: 4.2, roadIds: ['silver-road'], reward: '+5% supply finds' },
    { id: 'ferryman-cut', name: "Ferryman's Cut", subtitle: 'Fast route by reedwater crossings.', danger: 2, hours: 2.9, roadIds: ['pilgrim-road','ferry-cut'], reward: '+1 discovery roll' },
    { id: 'blackreed-causeway', name: 'Blackreed Causeway', subtitle: 'Shortest route through haunted marsh.', danger: 4, hours: 2.2, roadIds: ['marsh-walk'], reward: '+15% rare loot' },
  ],
  locations: [
    { id: 'ashmoor-cross', name: 'Ashmoor Cross', type: 'town', x: 500, y: 480, known: true, description: 'A muddy crossroads market built around an old gallows stone.' },
    { id: 'chapel-last-ember', name: 'Chapel of the Last Ember', type: 'quest', x: 310, y: 620, known: true, description: 'Candle smoke pours from its cracked belfry.' },
    { id: 'old-watchtower', name: 'Old Watchtower', type: 'fort', x: 1540, y: 245, known: true, description: 'A ruined tower watching the Greymarch road.' },
    { id: 'greenmother-shrine', name: "Greenmother's Shrine", type: 'shrine', x: 790, y: 575, known: true, description: 'A half-buried circle of stones hidden in old oak.' },
    { id: 'hollow-belfry', name: 'Hollow Belfry', type: 'dungeon', x: 1435, y: 760, known: true, description: 'A bell tower rising from black water and reeds.' },
    { id: 'ferrymans-reach', name: "Ferryman's Reach", type: 'merchant', x: 1035, y: 1000, known: true, description: 'A lantern-lit dock where coin buys safe crossing.' },
    { id: 'sunken-crypt', name: 'Sunken Crypt', type: 'danger', x: 285, y: 1025, known: true, description: 'A flooded tomb marked with old noble seals.' },
    { id: 'greywater-bridge', name: 'Greywater Bridge', type: 'event', x: 1225, y: 650, known: true, description: 'The bridge stones are slick with strange black wax.' },
    { id: 'mourning-reed-ferry', name: 'Mourning Reed Ferry', type: 'dock', x: 1605, y: 520, known: true, description: 'A ferry point used by smugglers and pilgrims.' },
    { id: 'millers-folly', name: "Miller's Folly", type: 'village', x: 620, y: 405, known: true, description: 'The mill wheel turns even when the creek is still.' },
    { id: 'dry-hummock-camp', name: 'Dry Hummock Camp', type: 'camp', x: 790, y: 835, known: true, description: 'High ground above the marsh; safe enough for one night.' },
  ],
  forests: [
    ...scatter(170, { x: 220, y: 230, w: 470, h: 360 }, 'tree', 24),
    ...scatter(145, { x: 640, y: 430, w: 380, h: 330 }, 'tree', 32),
    ...scatter(90, { x: 40, y: 380, w: 280, h: 260 }, 'tree', 28),
    ...scatter(95, { x: 1260, y: 560, w: 360, h: 330 }, 'tree', 34),
  ],
  mountains: [
    ...scatter(42, { x: 35, y: 20, w: 365, h: 330 }, 'mountain', 36),
    ...scatter(22, { x: 1510, y: 115, w: 250, h: 250 }, 'mountain', 28),
  ],
  current: {
    locationId: 'ashmoor-cross',
    destinationId: 'chapel-last-ember',
    progress: 0.18,
    selectedRouteId: 'ferryman-cut',
    supplies: 42,
    maxSupplies: 45,
    weather: 'Drizzle',
  },
};
