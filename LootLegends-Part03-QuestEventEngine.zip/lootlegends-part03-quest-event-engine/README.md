# Loot & Legends — Part 03: Quest Event Engine

This part adds a real quest/event system to connect the Living Atlas and Travel Engine to story gameplay.

## What it includes

- `src/data/questEvents.js` — data-driven quest chain with nodes, discoveries, choices, skill checks, outcomes, flags, unlocks, combat handoffs.
- `src/systems/questEventEngine.js` — pure quest resolver: choose action -> skill check -> outcome -> persistent world changes.
- `src/hooks/useQuestEventEngine.js` — React hook for UI integration.
- `src/storage/questSaveStore.js` — localStorage persistence for quest state.
- `src/components/QuestScene.jsx` + CSS — premium dark-fantasy quest scene screen.
- `src/components/QuestJournal.jsx` + CSS — compact quest journal/state panel.

## Integration order

1. Copy `src/data/questEvents.js` into your game's data folder.
2. Copy `src/systems/questEventEngine.js` into your systems folder.
3. Copy `src/storage/questSaveStore.js` into storage.
4. Copy `src/hooks/useQuestEventEngine.js` into hooks.
5. Copy the two components and CSS files into components.
6. Wire `QuestScene` into your quest screen.
7. Pass the current party/inventory into `useQuestEventEngine` so skill/item choices unlock correctly.
8. When an outcome includes `combat`, pass that encounter id to the combat engine.
9. When an outcome includes `unlockLocations`, merge it into the atlas/travel save state.

## Design intent

This is not a static story card. It is a stateful quest engine. Choices update flags, clues, reputation, location unlocks, danger, conditions, and combat/event handoffs.
