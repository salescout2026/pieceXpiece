# Loot & Legends — Part 10: Main App Shell + Navigation

This module provides the top-level mobile app shell that stitches Parts 01–09 into one navigable game structure.

## Adds
- `AppShell.jsx` — root layout, top bar, bottom navigation, screen routing
- `screenRegistry.js` — single place to register feature modules
- `navigationStore.js` — lightweight navigation state with history
- `shell.css` — premium dark fantasy shell styling
- `INTEGRATION_CHECKLIST.md` — assembly steps for Codex/GitHub

## Purpose
Use this after Parts 01–09 are added. This is not a standalone full game; it is the frame that lets the modules become one app.
