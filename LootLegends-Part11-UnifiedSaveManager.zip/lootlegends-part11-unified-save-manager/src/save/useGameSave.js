import { useCallback, useEffect, useMemo, useSyncExternalStore } from "react";
import { saveManager } from "./saveManager";

export function useGameSave(manager = saveManager) {
  const save = useSyncExternalStore(
    (listener) => manager.subscribe(listener),
    () => manager.current,
    () => manager.current
  );

  const patch = useCallback((pathOrUpdater, value, reason) => manager.patch(pathOrUpdater, value, reason), [manager]);
  const write = useCallback((nextSave, reason) => manager.write(nextSave, reason), [manager]);
  const reset = useCallback(() => manager.reset(), [manager]);
  const exportSave = useCallback(() => manager.exportSave(), [manager]);
  const importSave = useCallback((text) => manager.importSave(text), [manager]);

  useEffect(() => {
    const onVisibility = () => {
      if (document.visibilityState === "hidden") manager.write(manager.current, "visibility-autosave");
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
  }, [manager]);

  return useMemo(() => ({ save, patch, write, reset, exportSave, importSave, manager }), [save, patch, write, reset, exportSave, importSave, manager]);
}
