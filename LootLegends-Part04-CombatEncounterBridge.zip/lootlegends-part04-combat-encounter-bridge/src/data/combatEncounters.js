export const COMBAT_ENCOUNTERS = {
  blackreed_bandits: {
    id: "blackreed_bandits",
    title: "Blackreed Causeway Skirmish",
    region: "Gallowfen Marsh",
    scene: "A rain-slick causeway cuts across black water. Shapes move behind reeds, and a cracked bell-mask flashes in the lantern light.",
    terrain: ["marsh", "broken road", "low visibility"],
    rewards: { xp: 180, gold: 64, reputation: { ferrymens_guild: 1 }, dangerDelta: -1 },
    enemies: ["marsh_hound", "bell_acolyte", "mire_bowman"],
    victoryFlags: ["blackreed_causeway_cleared", "ferryman_route_safer"],
    defeatFlags: ["party_wounded_on_causeway"],
    resumeTravel: true
  },
  sunken_crypt_guard: {
    id: "sunken_crypt_guard",
    title: "Sunken Crypt Gate",
    region: "The Sunken Reach",
    scene: "Water drips from the crypt arch. The bell-wax seal grows warm as the dead stir beneath the mud.",
    terrain: ["crypt", "standing water", "echoing stone"],
    rewards: { xp: 220, gold: 42, items: ["crypt_key_shard"], dangerDelta: -1 },
    enemies: ["drowned_dead", "drowned_dead", "crypt_wight"],
    victoryFlags: ["sunken_crypt_gate_opened"],
    defeatFlags: ["crypt_gate_failed"],
    resumeTravel: false
  },
  road_cutters: {
    id: "road_cutters",
    title: "Road Cutters Ambush",
    region: "Greenreach",
    scene: "A felled ash blocks the road. Crossbow strings creak from the hedges.",
    terrain: ["road", "hedgerow", "ambush cover"],
    rewards: { xp: 140, gold: 55, supplies: 2, dangerDelta: -1 },
    enemies: ["hedge_cutthroat", "hedge_cutthroat", "road_raider"],
    victoryFlags: ["greenreach_road_cleared"],
    defeatFlags: ["greenreach_road_toll_paid"],
    resumeTravel: true
  }
};

export const ENEMY_DEFS = {
  marsh_hound: {
    id: "marsh_hound",
    name: "Marsh Hound",
    role: "Beast",
    hp: 20,
    maxHp: 20,
    armor: 11,
    attack: { name: "Pounce", bonus: 4, damage: [4, 8], type: "piercing" },
    intent: "Pounce",
    threat: 2,
    color: "#8fb36b"
  },
  bell_acolyte: {
    id: "bell_acolyte",
    name: "Bell Acolyte",
    role: "Cultist",
    hp: 18,
    maxHp: 18,
    armor: 12,
    attack: { name: "Hex Bell", bonus: 5, damage: [3, 9], type: "necrotic" },
    intent: "Hex",
    threat: 3,
    color: "#a56ad6"
  },
  mire_bowman: {
    id: "mire_bowman",
    name: "Mire Bowman",
    role: "Skirmisher",
    hp: 12,
    maxHp: 12,
    armor: 13,
    attack: { name: "Aimed Shot", bonus: 5, damage: [5, 10], type: "piercing" },
    intent: "Aimed Shot",
    threat: 2,
    color: "#d6a35b"
  },
  drowned_dead: {
    id: "drowned_dead",
    name: "Drowned Dead",
    role: "Undead",
    hp: 16,
    maxHp: 16,
    armor: 10,
    attack: { name: "Grasp", bonus: 3, damage: [3, 7], type: "bludgeoning" },
    intent: "Drag Down",
    threat: 2,
    color: "#6aa0a4"
  },
  crypt_wight: {
    id: "crypt_wight",
    name: "Crypt Wight",
    role: "Undead Elite",
    hp: 32,
    maxHp: 32,
    armor: 14,
    attack: { name: "Grave Chill", bonus: 6, damage: [7, 13], type: "cold" },
    intent: "Drain Warmth",
    threat: 4,
    color: "#bfc7d8"
  },
  hedge_cutthroat: {
    id: "hedge_cutthroat",
    name: "Hedge Cutthroat",
    role: "Bandit",
    hp: 14,
    maxHp: 14,
    armor: 12,
    attack: { name: "Knife Work", bonus: 4, damage: [3, 8], type: "slashing" },
    intent: "Flank",
    threat: 2,
    color: "#c68154"
  },
  road_raider: {
    id: "road_raider",
    name: "Road Raider",
    role: "Bandit Bruiser",
    hp: 26,
    maxHp: 26,
    armor: 13,
    attack: { name: "Hook Axe", bonus: 5, damage: [6, 11], type: "slashing" },
    intent: "Break Guard",
    threat: 3,
    color: "#b75f45"
  }
};

export const DEFAULT_PARTY = [
  {
    id: "rowan",
    name: "Rowan Voss",
    className: "Ranger",
    level: 5,
    hp: 38,
    maxHp: 38,
    armor: 16,
    initiative: 4,
    attack: { name: "Ashwood Spear", bonus: 6, damage: [8, 14], type: "piercing" },
    abilities: ["hunter_mark", "field_bandage"],
    portraitKey: "ranger"
  },
  {
    id: "maela",
    name: "Maela Thorn",
    className: "Cleric",
    level: 5,
    hp: 34,
    maxHp: 34,
    armor: 15,
    initiative: 1,
    attack: { name: "Mace", bonus: 5, damage: [5, 10], type: "bludgeoning" },
    abilities: ["blessing", "mending_prayer"],
    portraitKey: "cleric"
  }
];
