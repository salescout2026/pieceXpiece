import { useMemo, useState } from 'react';
import { atlas } from '../data/ashmoorAtlas.js';
import { pathPoint } from '../utils/geometry.js';

function roadById(id) {
  return atlas.roads.find((r) => r.id === id);
}

export function useAtlasState() {
  const [zoom, setZoom] = useState(0.47);
  const [offset, setOffset] = useState({ x: -190, y: -115 });
  const [selectedRouteId, setSelectedRouteId] = useState(atlas.current.selectedRouteId);
  const [travelProgress, setTravelProgress] = useState(atlas.current.progress);
  const [selectedLocationId, setSelectedLocationId] = useState(atlas.current.destinationId);

  const selectedRoute = atlas.routeOptions.find((r) => r.id === selectedRouteId) ?? atlas.routeOptions[0];
  const selectedLocation = atlas.locations.find((l) => l.id === selectedLocationId) ?? atlas.locations[0];

  const activeRoutePoints = useMemo(() => {
    const points = [];
    selectedRoute.roadIds.forEach((roadId, roadIndex) => {
      const road = roadById(roadId);
      if (!road) return;
      road.points.forEach((point, pointIndex) => {
        if (roadIndex > 0 && pointIndex === 0) return;
        points.push(point);
      });
    });
    return points;
  }, [selectedRoute]);

  const playerPoint = useMemo(() => pathPoint(activeRoutePoints, travelProgress), [activeRoutePoints, travelProgress]);

  const centerOnPlayer = () => {
    setOffset({
      x: 360 - playerPoint.x * zoom,
      y: 410 - playerPoint.y * zoom,
    });
  };

  const zoomIn = () => setZoom((z) => Math.min(1.05, +(z + 0.12).toFixed(2)));
  const zoomOut = () => setZoom((z) => Math.max(0.34, +(z - 0.12).toFixed(2)));
  const advanceTravel = () => setTravelProgress((p) => (p >= 1 ? 0 : +(p + 0.08).toFixed(2)));

  return {
    atlas,
    zoom,
    offset,
    setOffset,
    selectedRoute,
    selectedRouteId,
    setSelectedRouteId,
    selectedLocation,
    selectedLocationId,
    setSelectedLocationId,
    activeRoutePoints,
    playerPoint,
    travelProgress,
    setTravelProgress,
    centerOnPlayer,
    zoomIn,
    zoomOut,
    advanceTravel,
  };
}
