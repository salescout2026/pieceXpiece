import './QuestJournal.css';

export default function QuestJournal({ questState }) {
  return (
    <aside className="ll-journal">
      <h3>Quest Journal</h3>
      <div className="ll-journal-stat"><span>Clues</span><strong>{questState.clues.length}</strong></div>
      <div className="ll-journal-stat"><span>Unlocked Sites</span><strong>{questState.unlockedLocations.length}</strong></div>
      <div className="ll-journal-stat"><span>Danger Shift</span><strong>{questState.dangerDelta || 0}</strong></div>
      <h4>Recent Events</h4>
      {(questState.journal || []).slice(0, 8).map((entry) => (
        <article key={entry.id}>
          <strong>{entry.choice}</strong>
          <p>{entry.text}</p>
        </article>
      ))}
    </aside>
  );
}
